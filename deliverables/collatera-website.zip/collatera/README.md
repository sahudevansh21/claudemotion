# COLLATERA

**Know your collateral's risk before the market does.**

COLLATERA watches DeFi loans backed by tokenized stocks and ETFs. Paste a wallet
address (view-only) and see each position's health factor, buffer to liquidation,
price-feed freshness, market-hours risk and issuer events — in plain language.
Run stress tests, get alerts by email / Telegram / web push, and preview a
repayment that **you** sign in your own wallet. COLLATERA never holds funds or keys.

## Quick start (2 minutes, no accounts needed)

Requires Node.js 20.6+.

```bash
cp .env.example .env      # defaults run fully offline in demo mode
npm install
npm run setup             # creates the SQLite DB and seeds demo data
npm run dev               # web on http://localhost:3000 + background worker
```

Then open http://localhost:3000 and click **Check a wallet → Try the demo wallet**.

- Sign in at `/login` with any email. With no email provider configured, the
  sign-in link is shown on screen (and printed in the terminal).
- Use `demo@collatera.local` to see a pre-seeded account that already watches the
  demo wallet and has alert rules.
- Production: `npm run build && npm start` (web + worker).

## What's inside

| Area | Where |
| --- | --- |
| Landing hero (WebGL glass cube, chromatic refraction) | `src/components/hero/` |
| Standalone, no-build hero (`public/hero-standalone.html`) | regenerate with `npm run hero:standalone` |
| Pages: landing, dashboard, position, stress, planner, alerts, pricing, docs, account, admin, legal | `src/app/*` |
| Risk engine (pure, unit-tested) | `src/lib/risk/engine.ts` |
| Exchange calendar (NYSE/Nasdaq hours, holidays, early closes, DST) | `src/lib/risk/calendar.ts` |
| Lending-market adapters: demo + Aave v3-compatible | `src/lib/chain/` |
| Tokenized asset registry | `src/config/assets.ts` |
| API routes (zod-validated, rate-limited) | `src/app/api/*` |
| Auth (email magic link, session cookie) | `src/lib/server/auth.ts` |
| Alert rules, de-duplication, quiet hours | `src/lib/server/alerts.ts` |
| Email (Resend), Telegram, Web Push | `src/lib/server/notify.ts` |
| Stripe Checkout / Portal / webhook | `src/lib/server/stripe.ts` |
| Background worker | `worker/index.ts` |
| Database schema | `prisma/schema.prisma` |
| Tests | `tests/*.test.ts` (`npm test`) |

```mermaid
flowchart LR
  U[Browser] -->|pages + /api| W[Next.js app]
  U -->|signs txs| WAL[User wallet]
  W --> E[Risk engine]
  W --> A[Market adapter]
  A -->|RPC multicall| C[(Lending market + oracles)]
  W --> DB[(SQLite / Postgres)]
  K[Worker] --> A
  K --> E
  K --> DB
  K --> N[Email / Telegram / Push]
```

## Risk engine

- Health factor `HF = Σ(collateral × price × LT) ÷ debt` (liquidation at 1.0)
- Buffer `= 1 − 1/HF`
- Feed freshness: fresh ≤ 1.1× heartbeat, stale above, critical > 2× or failed
- Market closed → effective buffer = buffer − gap haircut (default 8%, per asset)
- Badges: **At Risk** (HF < 1.1, effective buffer < 10%, or active issuer pause),
  **Watch** (effective buffer < 25%, stale feed, issuer event < 72h, or close within
  60 min with buffer < 30%), **Safe** otherwise
- Stress: shocks only tokenized collateral (−10%, −20%, gap-down, oracle delay, custom)
- Repay to target `T`: `debt − weighted/T`; add collateral: `(T·debt − weighted) ÷ (price·LT)`, rounded up

All thresholds live in `DEFAULTS` in `src/lib/risk/engine.ts`.

## Going live on a real market

1. In `.env` set `MARKET_MODE="aave"`, `RPC_URL`, `CHAIN_ID` and the market's
   `AAVE_POOL`, `AAVE_DATA_PROVIDER`, `AAVE_ORACLE` (any Aave v3 fork works).
2. Put the tokenized assets that market lists in `src/config/assets.ts` (token
   address, underlying, exchange, oracle heartbeat, optional `issuerContract` for
   Paused/Unpaused monitoring) — or pass them as JSON in `ASSET_REGISTRY_JSON`.
   Collateral not in the registry shows as "unsupported collateral".
3. The demo wallet keeps working in live mode.

### Add a second lending market
Implement `LendingMarketAdapter` (`src/lib/chain/types.ts`): `findPositions`,
`buildRepayTx`, `buildSupplyTx`, `simulate`. Route to it in `src/lib/chain/index.ts`.

## Optional integrations

| Feature | Env vars |
| --- | --- |
| Email (sign-in links + alerts) | `RESEND_API_KEY`, `EMAIL_FROM` |
| Telegram alerts | `TELEGRAM_BOT_TOKEN`, `TELEGRAM_BOT_USERNAME`; `TELEGRAM_MODE=poll` (worker polls) or `webhook` + `TELEGRAM_WEBHOOK_SECRET` (point the bot webhook at `/api/telegram/webhook`) |
| Web push | `npm run vapid`, then `NEXT_PUBLIC_VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY` |
| Billing | `STRIPE_SECRET_KEY`, `STRIPE_PRICE_PRO`, `STRIPE_WEBHOOK_SECRET` (webhook → `/api/stripe/webhook`) |
| Admin (log issuer events at `/admin`) | `ADMIN_EMAILS` |

Without keys, each channel logs to the console instead, so nothing breaks locally.

## B2B API

Create a key on `/account` (Pro/Team), then:

```bash
curl -H "Authorization: Bearer coll_…" "http://localhost:3000/api/v1/positions?address=0x…"
```

## Production notes

- Switch Prisma to Postgres: set `provider = "postgresql"` in `prisma/schema.prisma`
  and a `postgres://` `DATABASE_URL`, then `npx prisma db push`.
- The rate limiter and scan cache are in-memory (single instance). Swap them for
  Redis before running several web replicas.
- Run exactly one worker process.
- Set `APP_URL` to your https origin (enables secure cookies and correct links) and a
  long random `SESSION_SECRET`.
- Legal pages are placeholders and need legal review.

## Honest limits

Version one covers one lending market in read-only mode. Data can lag or fail;
COLLATERA improves risk awareness but does **not** guarantee protection from
liquidation. Automation and any token are roadmap proposals only. Not financial advice.
