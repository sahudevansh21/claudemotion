// COLLATERA service worker — web push notifications only (no offline caching).
self.addEventListener('push', (event) => {
  let data = { title: 'COLLATERA alert', body: '', url: '/alerts' };
  try { data = { ...data, ...event.data.json() }; } catch (_) {}
  event.waitUntil(self.registration.showNotification(data.title, {
    body: data.body, data: { url: data.url }, icon: '/favicon.svg', badge: '/favicon.svg', tag: data.url,
  }));
});
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) || '/alerts';
  event.waitUntil(clients.openWindow(url));
});
