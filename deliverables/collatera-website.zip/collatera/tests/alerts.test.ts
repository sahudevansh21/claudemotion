import { describe, expect, it } from 'vitest';
import type { AlertRule } from '@prisma/client';
import { evaluate } from '@/lib/server/alerts';
import { scorePosition } from '@/lib/risk/engine';
import { demoPositions, DEMO_ADDRESS } from '@/lib/chain/demo';

const OPEN = new Date('2026-10-14T18:00:00Z');
const rule = (kind: string, threshold: number | null = null): AlertRule => ({
  id: kind, userId: 'u', address: null, kind, threshold, enabled: true, createdAt: OPEN,
});

describe('alert evaluation', () => {
  const events = [
    { asset: 'QQQx', kind: 'corporate_action', description: 'distribution', active: true, occurredAt: new Date(OPEN.getTime() - 6 * 3600_000).toISOString() },
    { asset: 'TSLAx', kind: 'redemption', description: 'old change', active: true, occurredAt: new Date(OPEN.getTime() - 12 * 86_400_000).toISOString() },
  ];
  const scored = demoPositions(DEMO_ADDRESS, OPEN).map((r) => scorePosition(r, { now: OPEN, issuerEvents: events }));
  const rules = [rule('buffer_below', 0.15), rule('feed_stale'), rule('issuer_event'), rule('market_transition', 0.25)];

  it('fires the right alert per demo position', () => {
    const kinds = scored.map((p) => evaluate(rules, p, null, OPEN).map((c) => c.dedupeKey.split(':')[2]));
    expect(kinds[0]).toEqual([]); // safe; the TSLAx event is 12 days old
    expect(kinds[1]).toEqual(['feed']);
    expect(kinds[2]).toEqual(['buffer']);
    expect(kinds[3]).toEqual(['issuer']);
  });

  it('respects disabled rules and address scoping', () => {
    const off = rules.map((r) => ({ ...r, enabled: false }));
    expect(evaluate(off, scored[2], null, OPEN)).toHaveLength(0);
    const other = rules.map((r) => ({ ...r, address: '0x0000000000000000000000000000000000000009' }));
    expect(evaluate(other, scored[2], null, OPEN)).toHaveLength(0);
  });

  it('every alert explains what changed, why and what to do', () => {
    for (const c of scored.flatMap((p) => evaluate(rules, p, null, OPEN))) {
      expect(c.whatChanged.length).toBeGreaterThan(10);
      expect(c.whyItMatters.length).toBeGreaterThan(10);
      expect(c.whatToDo.length).toBeGreaterThan(10);
    }
  });
});
