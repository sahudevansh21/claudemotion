import { describe, expect, it } from 'vitest';
import {
  bufferFromHf, feedState, healthFactor, liquidationPrice, planToTarget, scorePosition, stress, weightedCollateralUsd,
} from '@/lib/risk/engine';
import type { CollateralLeg, DebtLeg, RawPosition } from '@/lib/risk/types';
import { demoPositions, DEMO_ADDRESS } from '@/lib/chain/demo';

// Wednesday 2026-10-14 14:00 New York (EDT) — market open.
const OPEN = new Date('2026-10-14T18:00:00Z');
// Saturday 2026-10-17 12:00 New York — market closed.
const CLOSED = new Date('2026-10-17T16:00:00Z');

const sec = (d: Date) => Math.floor(d.getTime() / 1000);

function leg(over: Partial<CollateralLeg> = {}, now = OPEN): CollateralLeg {
  return {
    symbol: 'TSLAx', token: '0x1', decimals: 18, amount: 10, price: 100, liquidationThreshold: 0.8,
    tokenized: true, exchange: 'XNAS', gapHaircut: 0.1,
    oracle: { feed: '0xf', updatedAt: sec(now) - 60, heartbeatSec: 3600 }, ...over,
  };
}
const usdc = (amount: number): DebtLeg => ({ symbol: 'USDC', token: '0xu', decimals: 6, amount, price: 1 });
function pos(collateral: CollateralLeg[], debt: DebtLeg[]): RawPosition {
  return { id: 'm~0x0000000000000000000000000000000000000001~0', marketId: 'm', marketName: 'M', chainId: 1, owner: '0x0000000000000000000000000000000000000001', collateral, debt, unsupported: [], demo: false };
}

describe('core maths', () => {
  it('health factor and buffer', () => {
    // 10 × 100 × 0.8 = 800 weighted, debt 400 → HF 2, buffer 50%
    expect(healthFactor(800, 400)).toBe(2);
    expect(bufferFromHf(2)).toBeCloseTo(0.5);
    expect(bufferFromHf(1.25)).toBeCloseTo(0.2);
    expect(bufferFromHf(1)).toBe(0);
    expect(bufferFromHf(0.8)).toBeCloseTo(-0.25);
  });

  it('no debt → infinite HF, full buffer, safe', () => {
    expect(healthFactor(800, 0)).toBe(Infinity);
    const s = scorePosition(pos([leg()], []), { now: OPEN });
    expect(s.healthFactor).toBe(Infinity);
    expect(s.buffer).toBe(1);
    expect(s.badge).toBe('safe');
    expect(s.explanation.headline).toMatch(/No debt/);
  });

  it('exact HF = 1 is at risk', () => {
    const s = scorePosition(pos([leg()], [usdc(800)]), { now: OPEN });
    expect(s.healthFactor).toBeCloseTo(1);
    expect(s.badge).toBe('risk');
  });

  it('multi-collateral weighting and liquidation price', () => {
    const c = [leg(), leg({ symbol: 'USDC', token: '0xu', tokenized: false, amount: 500, price: 1, liquidationThreshold: 0.78, exchange: undefined })];
    expect(weightedCollateralUsd(c)).toBeCloseTo(800 + 390);
    // Debt 1000: TSLAx liquidates when 10 × p × 0.8 + 390 = 1000 → p = 76.25
    expect(liquidationPrice(c, 0, 1000)).toBeCloseTo(76.25);
    // Stablecoin alone can't trigger it if TSLAx covers the debt
    expect(liquidationPrice(c, 1, 700)).toBeNull();
  });
});

describe('freshness', () => {
  const now = sec(OPEN);
  it('fresh / stale / critical boundaries', () => {
    expect(feedState({ feed: 'f', updatedAt: now - 3960, heartbeatSec: 3600 }, now)).toBe('fresh'); // exactly 1.1×
    expect(feedState({ feed: 'f', updatedAt: now - 3961, heartbeatSec: 3600 }, now)).toBe('stale');
    expect(feedState({ feed: 'f', updatedAt: now - 7200, heartbeatSec: 3600 }, now)).toBe('stale'); // exactly 2×
    expect(feedState({ feed: 'f', updatedAt: now - 7201, heartbeatSec: 3600 }, now)).toBe('critical');
    expect(feedState({ feed: 'f', updatedAt: null, heartbeatSec: 3600 }, now)).toBe('critical');
    expect(feedState({ feed: 'f', updatedAt: now, heartbeatSec: 3600, failed: true }, now)).toBe('critical');
  });
  it('a stale feed makes an otherwise safe position Watch', () => {
    const s = scorePosition(pos([leg({ oracle: { feed: 'f', updatedAt: now - 5000, heartbeatSec: 3600 } })], [usdc(400)]), { now: OPEN });
    expect(s.badge).toBe('watch');
    expect(s.worstFeed).toBe('stale');
  });
});

describe('badges and market hours', () => {
  it('closed market applies a weighted haircut', () => {
    const s = scorePosition(pos([leg({}, CLOSED)], [usdc(400)]), { now: CLOSED });
    expect(s.marketClosed).toBe(true);
    expect(s.buffer).toBeCloseTo(0.5);
    expect(s.effectiveBuffer).toBeCloseTo(0.4);
    expect(s.badge).toBe('safe');
  });
  it('closed market can push a Watch position to At Risk', () => {
    // HF 1.25 → buffer 20% (watch when open); closed: 20% − 10% haircut = 10% → still watch (not < 10%)…
    const open = scorePosition(pos([leg()], [usdc(640)]), { now: OPEN });
    expect(open.badge).toBe('watch');
    // HF 1.18 → buffer ≈ 15.3%; closed → ≈ 5.3% → risk
    const closed = scorePosition(pos([leg({}, CLOSED)], [usdc(678)]), { now: CLOSED });
    expect(closed.effectiveBuffer).toBeLessThan(0.1);
    expect(closed.badge).toBe('risk');
  });
  it('HF below 1.1 is At Risk', () => {
    expect(scorePosition(pos([leg()], [usdc(740)]), { now: OPEN }).badge).toBe('risk');
  });
  it('active issuer pause is At Risk; recent other event is Watch', () => {
    const paused = scorePosition(pos([leg()], [usdc(200)]), { now: OPEN, issuerEvents: [{ asset: 'TSLAx', kind: 'pause', description: 'paused', active: true, occurredAt: new Date(OPEN.getTime() - 86400_000 * 10).toISOString() }] });
    expect(paused.badge).toBe('risk');
    const recent = scorePosition(pos([leg()], [usdc(200)]), { now: OPEN, issuerEvents: [{ asset: 'TSLAx', kind: 'corporate_action', description: 'split', active: true, occurredAt: new Date(OPEN.getTime() - 3600_000).toISOString() }] });
    expect(recent.badge).toBe('watch');
    const old = scorePosition(pos([leg()], [usdc(200)]), { now: OPEN, issuerEvents: [{ asset: 'TSLAx', kind: 'corporate_action', description: 'split', active: true, occurredAt: new Date(OPEN.getTime() - 86400_000 * 5).toISOString() }] });
    expect(old.badge).toBe('safe');
  });
  it('closing soon with a thin buffer is Watch', () => {
    const nearClose = new Date('2026-10-14T19:30:00Z'); // 15:30 ET
    const s = scorePosition(pos([leg({}, nearClose)], [usdc(570)]), { now: nearClose }); // HF ≈ 1.40, buffer ≈ 28.8%
    expect(s.buffer).toBeGreaterThan(0.25);
    expect(s.badge).toBe('watch');
  });
});

describe('stress and planning', () => {
  it('drop scenario only shocks tokenized collateral', () => {
    const c = [leg(), leg({ symbol: 'USDC', token: '0xu', tokenized: false, amount: 500, price: 1, liquidationThreshold: 0.8 })];
    const r = stress(pos(c, [usdc(600)]), { kind: 'drop', shock: 0.2 });
    // before: (800 + 400) / 600 = 2; after: (640 + 400) / 600 ≈ 1.733
    expect(r.before.healthFactor).toBeCloseTo(2);
    expect(r.after.healthFactor).toBeCloseTo(1040 / 600);
    expect(r.stressedPrices.TSLAx).toBeCloseTo(80);
    expect(r.stressedPrices.USDC).toBe(1);
  });
  it('oracle delay note mentions the delay', () => {
    const r = stress(pos([leg()], [usdc(600)]), { kind: 'oracle_delay', shock: 0.05, delayMin: 45 });
    expect(r.note).toMatch(/45 minutes/);
  });
  it('repay and add amounts reach the target exactly (rounded up)', () => {
    const c = [leg()];
    const d = [usdc(700)]; // HF ≈ 1.143
    const plan = planToTarget(c, d, 1.5);
    // repay = 700 − 800/1.5 = 166.666… → 166.666667
    expect(plan.repay!.amount).toBeCloseTo(166.666667, 6);
    expect(plan.repay!.amount).toBeGreaterThanOrEqual(700 - 800 / 1.5);
    const hfAfterRepay = healthFactor(800, 700 - plan.repay!.amount);
    expect(hfAfterRepay).toBeGreaterThanOrEqual(1.5 - 1e-9);
    // add = (1.5 × 700 − 800) / (100 × 0.8) = 3.125
    expect(plan.add[0].amount).toBeCloseTo(3.125);
    expect(healthFactor(weightedCollateralUsd([leg({ amount: 10 + plan.add[0].amount })]), 700)).toBeGreaterThanOrEqual(1.5 - 1e-9);
  });
  it('no plan when already above target', () => {
    const plan = planToTarget([leg()], [usdc(100)], 1.5);
    expect(plan.repay).toBeNull();
    expect(plan.add).toHaveLength(0);
  });
  it('repay is capped at the outstanding debt asset', () => {
    // Weighted 80, debt 100 USDC + 0 others: repay to 1.5 = 100 − 53.3 = 46.7 (fits). Make it not fit with two debts.
    const plan = planToTarget([leg({ amount: 1 })], [usdc(30), { symbol: 'DAI', token: '0xd', decimals: 18, amount: 70, price: 1 }], 1.5);
    expect(plan.repay!.symbol).toBe('DAI');
    expect(plan.repay!.capped).toBe(false);
    const capped = planToTarget([leg({ amount: 0.1 })], [usdc(30), { symbol: 'DAI', token: '0xd', decimals: 18, amount: 31, price: 1 }], 1.5);
    expect(capped.repay!.capped).toBe(true);
    expect(capped.repay!.amount).toBe(31);
  });
});

describe('demo market', () => {
  it('covers safe, watch and at-risk states', () => {
    const scored = demoPositions(DEMO_ADDRESS, OPEN).map((r) => scorePosition(r, {
      now: OPEN,
      issuerEvents: [{ asset: 'QQQx', kind: 'corporate_action', description: 'distribution', active: true, occurredAt: new Date(OPEN.getTime() - 6 * 3600_000).toISOString() }],
    }));
    expect(scored.map((s) => s.badge)).toEqual(['safe', 'watch', 'risk', 'watch']);
    expect(scored[1].worstFeed).toBe('stale');
  });
});
