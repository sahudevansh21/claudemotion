import { describe, expect, it } from 'vitest';
import { marketStatus, nyToUtc, sessionFor } from '@/lib/risk/calendar';

describe('exchange calendar', () => {
  it('open on a regular weekday afternoon', () => {
    const s = marketStatus('XNYS', new Date('2026-10-14T18:00:00Z')); // Wed 14:00 EDT
    expect(s.open).toBe(true);
    expect(s.minutesToClose).toBe(120);
    expect(s.nextClose).toBe('2026-10-14T20:00:00.000Z');
  });
  it('closed before the open, opens at 09:30 the same day', () => {
    const s = marketStatus('XNAS', new Date('2026-10-14T12:00:00Z')); // 08:00 EDT
    expect(s.open).toBe(false);
    expect(s.nextOpen).toBe('2026-10-14T13:30:00.000Z');
    expect(s.minutesToOpen).toBe(90);
  });
  it('weekend rolls to Monday', () => {
    const s = marketStatus('XNYS', new Date('2026-10-17T16:00:00Z')); // Saturday
    expect(s.open).toBe(false);
    expect(s.nextOpen).toBe('2026-10-19T13:30:00.000Z');
  });
  it('holidays and early closes', () => {
    expect(sessionFor('2026-11-26')).toBeNull(); // Thanksgiving
    expect(sessionFor('2026-11-27')).toEqual({ open: 570, close: 780 }); // early close 13:00
    const s = marketStatus('XNYS', new Date('2026-11-25T22:00:00Z')); // Wed after close, Thu holiday
    expect(s.nextOpen).toBe('2026-11-27T14:30:00.000Z'); // Fri 09:30 EST
    expect(s.nextClose).toBe('2026-11-27T18:00:00.000Z'); // 13:00 EST
    expect(s.earlyClose).toBe(true);
  });
  it('handles the DST switch', () => {
    // 2026-11-01 DST ends. Fri Oct 30 opens 13:30Z (EDT); Mon Nov 2 opens 14:30Z (EST).
    expect(nyToUtc('2026-10-30', 570).toISOString()).toBe('2026-10-30T13:30:00.000Z');
    expect(nyToUtc('2026-11-02', 570).toISOString()).toBe('2026-11-02T14:30:00.000Z');
    // Spring forward 2027-03-14
    expect(nyToUtc('2027-03-12', 570).toISOString()).toBe('2027-03-12T14:30:00.000Z');
    expect(nyToUtc('2027-03-15', 570).toISOString()).toBe('2027-03-15T13:30:00.000Z');
  });
});
