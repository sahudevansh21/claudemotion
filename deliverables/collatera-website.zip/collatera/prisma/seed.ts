// Seeds demo data: issuer events, 7 days of snapshot history for the demo wallet,
// and a demo user (demo@collatera.local) with alert rules and a few past alerts.
import { PrismaClient } from '@prisma/client';
import { demoPositions, DEMO_ADDRESS } from '../src/lib/chain/demo';
import { scorePosition } from '../src/lib/risk/engine';

const db = new PrismaClient();
const INF = 1e9;
const ser = (x: unknown) => JSON.stringify(x, (_k, v) => (v === Infinity ? INF : v));

async function main() {
  const now = Date.now();
  await db.issuerEvent.deleteMany({ where: { sourceUrl: { startsWith: 'https://example.com/demo' } } });
  await db.issuerEvent.createMany({
    data: [
      { asset: 'QQQx', kind: 'corporate_action', description: 'Quarterly distribution: ex-date tomorrow, token balance will be adjusted for the dividend.', sourceUrl: 'https://example.com/demo/qqqx-distribution', active: true, occurredAt: new Date(now - 6 * 3600_000) },
      { asset: 'NVDAx', kind: 'pause', description: 'Issuer paused transfers for 40 minutes during a contract upgrade (resolved).', sourceUrl: 'https://example.com/demo/nvdax-pause', active: false, occurredAt: new Date(now - 20 * 86_400_000) },
      { asset: 'TSLAx', kind: 'redemption', description: 'Redemption window moved from T+1 to T+2 business days.', sourceUrl: 'https://example.com/demo/tslax-redemption', active: true, occurredAt: new Date(now - 12 * 86_400_000) },
    ],
  });

  const events = (await db.issuerEvent.findMany()).map((e) => ({ asset: e.asset, kind: e.kind, description: e.description, active: e.active, occurredAt: e.occurredAt.toISOString() }));

  // History: one snapshot every 30 minutes for 7 days.
  await db.positionSnapshot.deleteMany({ where: { position: { owner: DEMO_ADDRESS } } });
  const rows = [];
  for (let t = now - 7 * 86_400_000; t <= now; t += 30 * 60_000) {
    const at = new Date(t);
    for (const raw of demoPositions(DEMO_ADDRESS, at)) {
      // Make the at-risk position drift down over the week for a more telling chart.
      if (raw.id.endsWith('~2')) raw.debt[0].amount = 4400 - ((now - t) / (7 * 86_400_000)) * 900;
      const p = scorePosition(raw, { now: at, issuerEvents: events });
      rows.push({ p, at });
    }
  }
  for (const id of new Set(rows.map((r) => r.p.id))) {
    await db.position.upsert({ where: { id }, update: {}, create: { id, marketId: 'demo', owner: DEMO_ADDRESS } });
  }
  for (let i = 0; i < rows.length; i += 500) {
    await db.positionSnapshot.createMany({
      data: rows.slice(i, i + 500).map(({ p, at }) => ({
        positionId: p.id, healthFactor: Number.isFinite(p.healthFactor) ? p.healthFactor : INF, buffer: p.buffer,
        effectiveBuffer: p.effectiveBuffer, badge: p.badge, collateralUsd: p.collateralUsd, debtUsd: p.debtUsd,
        json: ser(p), createdAt: at,
      })),
    });
  }

  const user = await db.user.upsert({ where: { email: 'demo@collatera.local' }, update: {}, create: { email: 'demo@collatera.local', plan: 'pro' } });
  await db.watchedAddress.upsert({
    where: { userId_address: { userId: user.id, address: DEMO_ADDRESS } },
    update: {},
    create: { userId: user.id, address: DEMO_ADDRESS, label: 'Demo wallet' },
  });
  if (!(await db.alertRule.count({ where: { userId: user.id } }))) {
    await db.alertRule.createMany({
      data: [
        { userId: user.id, kind: 'buffer_below', threshold: 0.15 },
        { userId: user.id, kind: 'feed_stale' },
        { userId: user.id, kind: 'issuer_event' },
        { userId: user.id, kind: 'market_transition', threshold: 0.25 },
      ],
    });
  }
  console.log(`Seeded ${rows.length} snapshots, ${events.length} issuer events, demo user demo@collatera.local watching ${DEMO_ADDRESS}`);
}

main().finally(() => db.$disconnect());
