// Generates public/hero-standalone.html: the landing hero as one file
// (inline CSS + JS, three.js from jsDelivr via importmap, no build step).
// Run: node scripts/build-standalone-hero.mjs
import { readFileSync, writeFileSync } from 'node:fs';
import { transformSync } from 'esbuild';

const root = new URL('..', import.meta.url);
const read = (p) => readFileSync(new URL(p, root), 'utf8');

const scene = transformSync(read('src/components/hero/heroScene.ts'), { loader: 'ts', format: 'esm', target: 'es2020' }).code
  .replace(/(["'])three\/examples\/jsm\//g, '$1three/addons/')
  .replace(/^export /gm, '');
const css = read('src/components/hero/hero.css');
const slides = transformSync(read('src/components/hero/slides.ts'), { loader: 'ts', format: 'esm' }).code.replace(/^export /gm, '');

const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>COLLATERA — Know your collateral's risk</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root { --bg:#000; --fg:#fff; --pad-x: clamp(20px, 6.95vw, 120px) }
*, *::before, *::after { box-sizing: border-box }
html, body { height:100%; margin:0; background:#000; color:#fff; font-family:'Poppins',sans-serif; -webkit-font-smoothing:antialiased; overflow-x:hidden }
.sr-only { position:absolute; width:1px; height:1px; overflow:hidden; clip:rect(0 0 0 0); white-space:nowrap }
${css}
</style>
<script type="importmap">
{ "imports": {
  "three": "https://cdn.jsdelivr.net/npm/three@0.169.0/build/three.module.js",
  "three/addons/": "https://cdn.jsdelivr.net/npm/three@0.169.0/examples/jsm/"
} }
</script>
</head>
<body>
<section class="hero" id="hero">
  <canvas id="scene" tabindex="0" aria-label="Rotatable glass cube. Drag to rotate."></canvas>
  <div class="ui">
    <h1 class="sr-only" id="sr">Know your collateral’s risk before the market does.</h1>
    <header class="nav">
      <a href="/" class="logo"><i class="logo-mark"></i><span><b>COLL</b>ATERA</span></a>
      <ul class="nav-links"><li><a href="/dashboard">Dashboard</a></li><li><a href="/pricing">Pricing</a></li><li><a href="/docs">Docs</a></li></ul>
    </header>
    <div class="arrows">
      <button class="arrow" id="prev" aria-label="Previous slide"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M11 6l-6 6 6 6"/></svg></button>
      <button class="arrow" id="next" aria-label="Next slide"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button>
    </div>
    <nav class="dots" aria-label="Hero slides"><button class="dot active" aria-label="Slide 1" aria-current="true"></button><button class="dot" aria-label="Slide 2"></button><button class="dot" aria-label="Slide 3"></button></nav>
    <p class="tagline" id="tagline" aria-live="polite">Know your collateral’s<br>risk before the<strong>market does.</strong></p>
    <div class="cta-row">
      <a href="/#check" class="cta">Check a wallet</a>
      <span class="cta-line"></span>
      <span class="count" id="count" aria-hidden="true">01</span>
    </div>
    <div class="loader" id="loader">Loading model</div>
  </div>
</section>
<script type="module">
${scene}
${slides}
const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
const canvas = document.getElementById('scene');
const loader = document.getElementById('loader');
const tagline = document.getElementById('tagline');
const count = document.getElementById('count');
const sr = document.getElementById('sr');
const dots = [...document.querySelectorAll('.dot')];
let slide = 0, lastInteraction = 0;
const scene = webglAvailable()
  ? createHeroScene(canvas, { lines: SLIDES[0].lines, reducedMotion: reduced, onLoaded: () => loader.classList.add('done') })
  : (loader.textContent = 'WebGL is not available', null);

function goTo(next, dir, turns = 1, user = true) {
  if (user) lastInteraction = Date.now();
  const target = (next + SLIDES.length) % SLIDES.length;
  if (target === slide) return;
  slide = target;
  scene?.setLines(SLIDES[target].lines);
  scene?.spin(dir, turns);
  dots.forEach((d, i) => { d.classList.toggle('active', i === target); d.toggleAttribute('aria-current', i === target); });
  tagline.classList.add('fading'); count.classList.add('fading');
  setTimeout(() => {
    const s = SLIDES[target];
    tagline.innerHTML = s.tagline[0] + '<br>' + s.tagline[1] + '<strong>' + s.tagline[2] + '</strong>';
    count.textContent = s.count; sr.textContent = s.sr;
    tagline.classList.remove('fading'); count.classList.remove('fading');
  }, 220);
}
document.getElementById('prev').onclick = () => goTo(slide - 1, -1);
document.getElementById('next').onclick = () => goTo(slide + 1, 1);
dots.forEach((d, i) => d.onclick = () => goTo(i, i > slide ? 1 : -1, Math.abs(i - slide)));
canvas.addEventListener('pointerdown', () => { lastInteraction = Date.now(); });
document.getElementById('hero').addEventListener('keydown', (e) => {
  if (e.key === 'ArrowLeft') goTo(slide - 1, -1);
  if (e.key === 'ArrowRight') goTo(slide + 1, 1);
});
if (!reduced) setInterval(() => { if (!document.hidden && Date.now() - lastInteraction > 10000) goTo(slide + 1, 1, 1, false); }, 7000);
</script>
</body>
</html>
`;
writeFileSync(new URL('public/hero-standalone.html', root), html);
console.log('wrote public/hero-standalone.html', html.length, 'bytes');
