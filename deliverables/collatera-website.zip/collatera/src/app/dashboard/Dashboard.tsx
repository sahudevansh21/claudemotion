'use client';

import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import PositionCard from '@/components/PositionCard';
import { DataNote, Skeleton, Stat } from '@/components/ui';
import WalletCheck from '@/components/WalletCheck';
import { api, useAgo, useApi, type Me } from '@/lib/client/api';
import { fmtHf, fmtUsd } from '@/lib/risk/engine';
import type { MarketStatus } from '@/lib/risk/calendar';
import type { ScoredPosition } from '@/lib/risk/types';
import { DEMO_ADDRESS } from '@/lib/chain/demo';

interface ScanResult { address: string; market: { id: string; name: string }; positions: ScoredPosition[]; checkedAt: string }
interface Saved { addresses: { id: string; address: string; label: string | null }[]; limit: number }

const short = (a: string) => `${a.slice(0, 6)}…${a.slice(-4)}`;

export default function Dashboard() {
  const params = useSearchParams();
  const router = useRouter();
  const me = useApi<Me>('/api/me');
  const saved = useApi<Saved>(me.data?.user ? '/api/addresses' : null);
  const [address, setAddress] = useState<string | null>(params.get('address'));

  useEffect(() => {
    const q = params.get('address');
    if (q) setAddress(q.toLowerCase());
  }, [params]);
  useEffect(() => {
    if (!address && saved.data?.addresses[0]) setAddress(saved.data.addresses[0].address);
  }, [address, saved.data]);

  const scan = useApi<ScanResult>(address ? `/api/positions?address=${address}` : null, { refreshMs: 30_000 });
  const markets = useApi<{ markets: MarketStatus[] }>('/api/market-status', { refreshMs: 60_000 });
  const ago = useAgo(scan.updatedAt);
  const [saveMsg, setSaveMsg] = useState<string | null>(null);

  const positions = scan.data?.positions ?? [];
  const debtPositions = positions.filter((p) => p.debtUsd > 0);
  const lowest = debtPositions.length ? Math.min(...debtPositions.map((p) => p.healthFactor)) : null;
  const counts = { safe: 0, watch: 0, risk: 0 };
  positions.forEach((p) => counts[p.badge]++);
  const isSaved = !!saved.data?.addresses.some((a) => a.address === address);

  async function save() {
    setSaveMsg(null);
    try {
      await api('/api/addresses', { method: 'POST', json: { address, label: address === DEMO_ADDRESS ? 'Demo wallet' : undefined } });
      await saved.reload();
      setSaveMsg('Saved. The worker now monitors this address and alerts you.');
    } catch (e) {
      setSaveMsg((e as Error).message);
    }
  }

  return (
    <div className="container">
      <div className="page-head spread" style={{ alignItems: 'flex-end' }}>
        <div className="stack" style={{ gap: 8 }}>
          <span className="eyebrow">Dashboard</span>
          <h1 className="display" style={{ fontSize: 'clamp(40px, 6vw, 80px)' }}>{address ? short(address) : 'Your positions'}</h1>
          {address && (
            <span className="small muted">
              {scan.data?.market.name ?? 'Scanning…'} · Last checked {ago}
              {address === DEMO_ADDRESS && ' · Demo wallet with sample data'}
            </span>
          )}
        </div>
        <div className="row">
          {saved.data && saved.data.addresses.length > 0 && (
            <select className="select" style={{ height: 44, width: 'auto' }} value={address ?? ''} aria-label="Saved addresses"
              onChange={(e) => router.push(`/dashboard?address=${e.target.value}`)}>
              {!isSaved && address && <option value={address}>{short(address)} (unsaved)</option>}
              {saved.data.addresses.map((a) => <option key={a.id} value={a.address}>{a.label ? `${a.label} · ` : ''}{short(a.address)}</option>)}
            </select>
          )}
          {address && me.data?.user && !isSaved && <button className="btn btn-sm" onClick={save}>Save &amp; monitor</button>}
          {address && !me.data?.user && <Link className="btn btn-sm" href={`/login?next=${encodeURIComponent(`/dashboard?address=${address}`)}`}>Sign in to get alerts</Link>}
        </div>
      </div>
      {saveMsg && <p className="notice ok" style={{ marginBottom: 20 }}>{saveMsg}</p>}

      {!address && (
        <div className="card stack" style={{ gap: 20 }}>
          <h2 className="h3">Add a wallet to start</h2>
          <p className="muted">Paste any address — it’s view-only. Or try the demo wallet to see every risk state.</p>
          <WalletCheck />
        </div>
      )}

      {address && (
        <div className="stack" style={{ gap: 28 }}>
          <div className="card grid grid-4">
            <Stat label="Collateral" value={scan.data ? fmtUsd(positions.reduce((a, p) => a + p.collateralUsd, 0)) : '—'} />
            <Stat label="Debt" value={scan.data ? fmtUsd(positions.reduce((a, p) => a + p.debtUsd, 0)) : '—'} />
            <Stat label="Lowest health factor" value={lowest == null ? '—' : fmtHf(lowest)} tone={lowest == null ? undefined : lowest < 1.1 ? 'risk' : lowest < 1.34 ? 'watch' : 'safe'} />
            <Stat label="Positions" value={scan.data ? positions.length : '—'}
              sub={scan.data && <><span className="c-safe">{counts.safe} safe</span> · <span className="c-watch">{counts.watch} watch</span> · <span className="c-risk">{counts.risk} at risk</span></>} />
          </div>

          <div className="row">
            {(markets.data?.markets ?? []).map((m) => (
              <span key={m.exchange} className="chip" title={m.earlyClose ? 'Early close today' : undefined}>
                <span className={m.open ? 'c-safe' : 'c-watch'}>●</span> {m.label}
              </span>
            ))}
          </div>

          {scan.error && <p className="notice err" role="alert">{scan.error.message}</p>}
          {scan.loading && !scan.data && <div className="grid grid-2"><Skeleton h={320} /><Skeleton h={320} /></div>}
          {scan.data && positions.length === 0 && (
            <div className="card stack">
              <h2 className="h3">No open positions found</h2>
              <p className="muted">We found no collateral or debt for this address on {scan.data.market.name}. COLLATERA v1 supports one lending market.</p>
              <p className="small muted">Want to see how it works? <Link className="link" href={`/dashboard?address=${DEMO_ADDRESS}`}>Open the demo wallet</Link>.</p>
            </div>
          )}
          {positions.length > 0 && (
            <div className="grid grid-2">
              {[...positions].sort((a, b) => ({ risk: 0, watch: 1, safe: 2 }[a.badge] - { risk: 0, watch: 1, safe: 2 }[b.badge])).map((p) => <PositionCard key={p.id} p={p} />)}
            </div>
          )}
          <DataNote at={scan.data?.checkedAt} />
        </div>
      )}
    </div>
  );
}
