import { Suspense } from 'react';
import PageShell from '@/components/PageShell';
import Dashboard from './Dashboard';

export const metadata = { title: 'Dashboard — COLLATERA' };

export default function Page() {
  return (
    <PageShell>
      <Suspense>
        <Dashboard />
      </Suspense>
    </PageShell>
  );
}
