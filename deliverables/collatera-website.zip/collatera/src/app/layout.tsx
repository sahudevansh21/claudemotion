import type { Metadata, Viewport } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'COLLATERA — Know your collateral’s risk',
  description:
    'COLLATERA watches DeFi loans backed by tokenized stocks and ETFs: buffer to liquidation, oracle freshness, market hours, issuer events, stress tests and user-signed repayment plans.',
  icons: { icon: '/favicon.svg' },
};

export const viewport: Viewport = { themeColor: '#000000', width: 'device-width', initialScale: 1 };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        {/* eslint-disable-next-line @next/next/no-page-custom-font */}
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet" />
      </head>
      <body>
        <a href="#main" className="sr-only">Skip to content</a>
        {children}
      </body>
    </html>
  );
}
