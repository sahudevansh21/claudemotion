'use client';

import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { Skeleton } from '@/components/ui';
import { api, useApi, type Me } from '@/lib/client/api';

interface Addr { id: string; address: string; label: string | null }
interface Key { id: string; name: string; prefix: string; lastUsed: string | null; createdAt: string }

export default function Account() {
  const router = useRouter();
  const me = useApi<Me>('/api/me');
  const user = me.data?.user;
  const addrs = useApi<{ addresses: Addr[]; limit: number }>(user ? '/api/addresses' : null);
  const keys = useApi<{ keys: Key[] }>(user ? '/api/apikeys' : null);
  const [newAddr, setNewAddr] = useState('');
  const [newLabel, setNewLabel] = useState('');
  const [keyName, setKeyName] = useState('');
  const [freshKey, setFreshKey] = useState<string | null>(null);
  const [msg, setMsg] = useState<{ tone: 'ok' | 'err'; text: string } | null>(null);

  if (me.loading) return <div className="container page-head"><Skeleton h={240} /></div>;
  if (!user) return <div className="container page-head stack"><h1 className="h2">Account</h1><Link className="btn btn-solid" style={{ width: 'fit-content' }} href="/login?next=/account">Sign in</Link></div>;

  const run = async (fn: () => Promise<unknown>, ok?: string) => {
    try { await fn(); if (ok) setMsg({ tone: 'ok', text: ok }); } catch (e) { setMsg({ tone: 'err', text: (e as Error).message }); }
  };

  return (
    <div className="container stack" style={{ gap: 28 }}>
      <div className="page-head spread" style={{ alignItems: 'flex-end' }}>
        <div className="stack" style={{ gap: 8 }}>
          <span className="eyebrow">Account</span>
          <h1 className="display" style={{ fontSize: 'clamp(36px, 5vw, 64px)', wordBreak: 'break-all' }}>{user.email}</h1>
          <span className="small muted">Plan: <b style={{ color: '#fff', textTransform: 'capitalize' }}>{user.plan}</b>{user.admin && <> · <Link className="link" href="/admin">Admin</Link></>}</span>
        </div>
        <button className="btn btn-ghost btn-sm" onClick={() => run(async () => { await api('/api/auth/logout', { method: 'POST' }); router.push('/'); router.refresh(); })}>Sign out</button>
      </div>
      {msg && <p className={`notice ${msg.tone}`} role="status">{msg.text}</p>}

      <section className="card stack" style={{ gap: 16 }}>
        <div className="spread"><h2 className="h3">Saved addresses</h2>{addrs.data && <span className="small muted">{addrs.data.addresses.length} / {addrs.data.limit}</span>}</div>
        {addrs.data?.addresses.map((a) => (
          <div key={a.id} className="spread" style={{ borderTop: '1px solid var(--line)', paddingTop: 12 }}>
            <div className="stack" style={{ gap: 2 }}>
              <b style={{ fontWeight: 600 }}>{a.label ?? 'Unlabelled'}</b>
              <span className="small muted num" style={{ wordBreak: 'break-all' }}>{a.address}</span>
            </div>
            <div className="row">
              <Link className="btn btn-sm" href={`/dashboard?address=${a.address}`}>Open</Link>
              <button className="btn btn-sm btn-danger" onClick={() => run(async () => { await api(`/api/addresses?id=${a.id}`, { method: 'DELETE' }); await addrs.reload(); })}>Remove</button>
            </div>
          </div>
        ))}
        <form className="row" onSubmit={(e) => { e.preventDefault(); void run(async () => { await api('/api/addresses', { method: 'POST', json: { address: newAddr, label: newLabel || undefined } }); setNewAddr(''); setNewLabel(''); await addrs.reload(); }, 'Address saved.'); }}>
          <input className="input" style={{ flex: '2 1 280px' }} placeholder="0x… address" value={newAddr} onChange={(e) => setNewAddr(e.target.value)} required aria-label="Address" />
          <input className="input" style={{ flex: '1 1 160px' }} placeholder="Label (optional)" value={newLabel} onChange={(e) => setNewLabel(e.target.value)} aria-label="Label" />
          <button className="btn">Add</button>
        </form>
      </section>

      <section className="card stack" style={{ gap: 16 }}>
        <h2 className="h3">Billing</h2>
        <p className="muted small">{user.billing ? `Subscription: ${user.billing.plan} (${user.billing.status})` : 'You are on the Free plan.'}</p>
        <div className="row">
          {user.plan === 'free' && <button className="btn btn-solid" disabled={!me.data?.features?.billing} onClick={() => run(async () => { const r = await api<{ url: string }>('/api/stripe/checkout', { method: 'POST' }); window.location.href = r.url; })}>Upgrade to Pro</button>}
          {user.billing?.portal && <button className="btn" onClick={() => run(async () => { const r = await api<{ url: string }>('/api/stripe/portal', { method: 'POST' }); window.location.href = r.url; })}>Manage billing</button>}
          {!me.data?.features?.billing && <span className="small muted">Billing is not configured on this server.</span>}
        </div>
      </section>

      <section className="card stack" style={{ gap: 16 }}>
        <h2 className="h3">API keys</h2>
        <p className="small muted">For B2B access: <code>GET /api/v1/positions?address=0x…</code> with <code>Authorization: Bearer coll_…</code>. Pro and Team plans.</p>
        {freshKey && <div className="notice ok"><p>Copy this key now — it will not be shown again.</p><pre style={{ marginTop: 8 }}>{freshKey}</pre></div>}
        {keys.data?.keys.map((k) => (
          <div key={k.id} className="spread" style={{ borderTop: '1px solid var(--line)', paddingTop: 12 }}>
            <span><b style={{ fontWeight: 600 }}>{k.name}</b> <span className="small muted num">{k.prefix}… · {k.lastUsed ? `used ${new Date(k.lastUsed).toLocaleDateString()}` : 'never used'}</span></span>
            <button className="btn btn-sm btn-danger" onClick={() => run(async () => { await api(`/api/apikeys?id=${k.id}`, { method: 'DELETE' }); await keys.reload(); })}>Revoke</button>
          </div>
        ))}
        <form className="row" onSubmit={(e) => { e.preventDefault(); void run(async () => { const r = await api<{ key: string }>('/api/apikeys', { method: 'POST', json: { name: keyName } }); setFreshKey(r.key); setKeyName(''); await keys.reload(); }); }}>
          <input className="input" style={{ flex: '1 1 240px' }} placeholder="Key name, e.g. Treasury bot" value={keyName} onChange={(e) => setKeyName(e.target.value)} required aria-label="Key name" />
          <button className="btn">Create key</button>
        </form>
      </section>

      <section className="card stack" style={{ gap: 12 }}>
        <h2 className="h3">Danger zone</h2>
        <p className="small muted">Deletes your account, saved addresses, alert rules and history. Nothing on-chain is affected.</p>
        <button className="btn btn-danger btn-sm" style={{ width: 'fit-content' }} onClick={() => { if (confirm('Delete your COLLATERA account permanently?')) void run(async () => { await api('/api/me', { method: 'DELETE' }); router.push('/'); }); }}>Delete account</button>
      </section>
    </div>
  );
}
