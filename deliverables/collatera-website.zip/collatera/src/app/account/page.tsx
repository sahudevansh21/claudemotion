import PageShell from '@/components/PageShell';
import Account from './Account';

export const metadata = { title: 'Account — COLLATERA' };

export default function Page() {
  return (
    <PageShell>
      <Account />
    </PageShell>
  );
}
