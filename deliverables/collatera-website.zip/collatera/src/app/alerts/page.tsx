import PageShell from '@/components/PageShell';
import Alerts from './Alerts';

export const metadata = { title: 'Alerts — COLLATERA' };

export default function Page() {
  return (
    <PageShell>
      <Alerts />
    </PageShell>
  );
}
