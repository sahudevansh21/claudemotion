'use client';

import Link from 'next/link';
import { useState } from 'react';
import { Skeleton } from '@/components/ui';
import { api, useApi, type Me } from '@/lib/client/api';

interface Rule { id: string; kind: string; threshold: number | null; enabled: boolean; address: string | null }
interface Ev {
  id: string; severity: 'info' | 'watch' | 'risk'; title: string; whatChanged: string; whyItMatters: string; whatToDo: string; createdAt: string; positionId: string | null;
  deliveries: { channel: string; status: string; error: string | null }[];
}

const RULE_TEXT: Record<string, { title: string; body: (t: number | null) => string; threshold?: boolean }> = {
  buffer_below: { title: 'Buffer drops below', body: (t) => `Alert when the effective buffer falls below ${Math.round((t ?? 0.15) * 100)}%.`, threshold: true },
  feed_stale: { title: 'Price feed goes stale', body: () => 'Alert when a tokenized-asset oracle misses its expected update interval.' },
  issuer_event: { title: 'Issuer or contract event', body: () => 'Alert on pauses, allowlist or redemption changes and corporate actions.' },
  market_transition: { title: 'Market close / open while thin', body: (t) => `Alert near the close and at the open when the buffer is under ${Math.round((t ?? 0.25) * 100)}%.`, threshold: true },
};

function urlBase64ToUint8Array(base64: string) {
  const padding = '='.repeat((4 - (base64.length % 4)) % 4);
  const raw = atob((base64 + padding).replace(/-/g, '+').replace(/_/g, '/'));
  return Uint8Array.from(raw, (c) => c.charCodeAt(0));
}

export default function Alerts() {
  const me = useApi<Me>('/api/me');
  const signedIn = !!me.data?.user;
  const rules = useApi<{ rules: Rule[] }>(signedIn ? '/api/alerts/rules' : null);
  const events = useApi<{ events: Ev[] }>(signedIn ? '/api/alerts/events' : null, { refreshMs: 30_000 });
  const [msg, setMsg] = useState<{ tone: 'ok' | 'err'; text: string } | null>(null);
  const say = (tone: 'ok' | 'err', text: string) => setMsg({ tone, text });

  if (me.loading) return <div className="container page-head"><Skeleton h={200} /></div>;
  if (!signedIn) {
    return (
      <div className="container">
        <div className="page-head stack" style={{ gap: 14 }}>
          <span className="eyebrow">Alerts</span>
          <h1 className="display" style={{ fontSize: 'clamp(40px, 6vw, 84px)' }}>Hear about it first.</h1>
          <p className="lead">Email, Telegram and push alerts when your buffer thins, a price feed goes stale, an issuer acts, or the market is about to close while you’re exposed.</p>
        </div>
        <Link className="btn btn-solid" href="/login?next=/alerts">Sign in to set up alerts</Link>
      </div>
    );
  }
  const user = me.data!.user!;
  const features = me.data!.features!;

  async function patchRule(id: string, data: Partial<Rule>) {
    await api('/api/alerts/rules', { method: 'PATCH', json: { id, ...data } });
    await rules.reload();
  }
  async function test(channel: 'email' | 'telegram' | 'push') {
    try {
      const r = await api<{ status: string; error?: string }>('/api/notify/test', { method: 'POST', json: { channel } });
      say(r.status === 'failed' ? 'err' : 'ok', r.status === 'logged' ? `Test ${channel} logged to the server console (provider not configured).` : r.status === 'sent' ? `Test ${channel} sent.` : `Failed: ${r.error}`);
    } catch (e) { say('err', (e as Error).message); }
  }
  async function connectTelegram() {
    try {
      const r = await api<{ url: string }>('/api/telegram/link', { method: 'POST' });
      window.open(r.url, '_blank', 'noopener');
      say('ok', 'Telegram opened. Press “Start” in the bot chat, then refresh this page.');
    } catch (e) { say('err', (e as Error).message); }
  }
  async function enablePush() {
    try {
      const key = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY;
      if (!key) throw new Error('Push is not configured on this server (NEXT_PUBLIC_VAPID_PUBLIC_KEY).');
      if (!('serviceWorker' in navigator) || !('PushManager' in window)) throw new Error('This browser does not support web push.');
      const perm = await Notification.requestPermission();
      if (perm !== 'granted') throw new Error('Notification permission was not granted.');
      const reg = await navigator.serviceWorker.register('/sw.js');
      const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: urlBase64ToUint8Array(key) });
      await api('/api/notify/push', { method: 'POST', json: sub.toJSON() });
      say('ok', 'Push notifications enabled on this device.');
    } catch (e) { say('err', (e as Error).message); }
  }
  async function saveQuiet(start: string, end: string) {
    await api('/api/me', {
      method: 'PATCH',
      json: { quietStart: start === '' ? null : Number(start), quietEnd: end === '' ? null : Number(end), tzOffsetMin: -new Date().getTimezoneOffset() },
    });
    await me.reload();
    say('ok', 'Quiet hours saved. At Risk alerts still come through.');
  }

  return (
    <div className="container stack" style={{ gap: 28 }}>
      <div className="page-head">
        <span className="eyebrow">Alerts</span>
        <h1 className="display" style={{ fontSize: 'clamp(40px, 6vw, 84px)', marginTop: 8 }}>Alerts</h1>
        <p className="lead">Each alert explains what changed, why it matters and what to do. Rules apply to every address you save on the <Link className="link" href="/dashboard">dashboard</Link>.</p>
      </div>
      {msg && <p className={`notice ${msg.tone}`} role="status">{msg.text}</p>}

      <section className="grid grid-3">
        <div className="card stack">
          <h2 className="h3">Email</h2>
          <p className="small muted">{user.email}{!features.email && ' · provider not configured, alerts are logged'}</p>
          <button className="btn btn-sm" onClick={() => test('email')}>Send test</button>
        </div>
        <div className="card stack">
          <h2 className="h3">Telegram</h2>
          <p className="small muted">{user.telegramConnected ? 'Connected' : features.telegram ? 'Not connected' : 'Not configured on this server'}</p>
          <div className="row">
            {!user.telegramConnected && <button className="btn btn-sm" disabled={!features.telegram} onClick={connectTelegram}>Connect Telegram</button>}
            {user.telegramConnected && <button className="btn btn-sm" onClick={() => test('telegram')}>Send test</button>}
            {user.telegramConnected && <button className="btn btn-sm btn-ghost" onClick={async () => { await api('/api/telegram/link', { method: 'DELETE' }); await me.reload(); }}>Disconnect</button>}
          </div>
        </div>
        <div className="card stack">
          <h2 className="h3">Push</h2>
          <p className="small muted">{features.push ? 'Browser notifications on this device' : 'Not configured on this server'}</p>
          <div className="row">
            <button className="btn btn-sm" disabled={!features.push} onClick={enablePush}>Enable on this device</button>
            <button className="btn btn-sm btn-ghost" disabled={!features.push} onClick={() => test('push')}>Send test</button>
          </div>
        </div>
      </section>

      <section className="card stack" style={{ gap: 18 }}>
        <h2 className="h3">Rules</h2>
        {!rules.data && <Skeleton h={120} />}
        {rules.data?.rules.map((r) => {
          const t = RULE_TEXT[r.kind];
          return (
            <div key={r.id} className="spread" style={{ borderTop: '1px solid var(--line)', paddingTop: 16 }}>
              <div className="stack" style={{ gap: 2, flex: '1 1 320px' }}>
                <b style={{ fontWeight: 600 }}>{t?.title ?? r.kind}</b>
                <span className="small muted">{t?.body(r.threshold)}</span>
              </div>
              <div className="row">
                {t?.threshold && (
                  <label className="row small muted">%
                    <input className="input" style={{ width: 90, height: 40 }} type="number" min={1} max={90} defaultValue={Math.round((r.threshold ?? 0.15) * 100)}
                      onBlur={(e) => patchRule(r.id, { threshold: Math.min(90, Math.max(1, Number(e.target.value))) / 100 })} aria-label="Threshold percent" />
                  </label>
                )}
                <label className="check small"><input type="checkbox" checked={r.enabled} onChange={(e) => patchRule(r.id, { enabled: e.target.checked })} /> On</label>
              </div>
            </div>
          );
        })}
        <QuietHours start={user.quietStart} end={user.quietEnd} onSave={saveQuiet} />
      </section>

      <section className="stack" style={{ gap: 14 }}>
        <h2 className="h3">History</h2>
        {events.data?.events.length === 0 && <p className="muted">No alerts yet. When something changes on a saved address, it will show up here.</p>}
        {events.data?.events.map((e) => (
          <article key={e.id} className="card stack" style={{ gap: 10, borderLeft: `3px solid var(--${e.severity === 'risk' ? 'risk' : e.severity === 'watch' ? 'watch' : 'info'})` }}>
            <div className="spread"><b style={{ fontWeight: 600 }}>{e.title}</b><span className="small faint">{new Date(e.createdAt).toLocaleString()}</span></div>
            <p className="small"><span className="muted">What changed:</span> {e.whatChanged}</p>
            <p className="small"><span className="muted">Why it matters:</span> {e.whyItMatters}</p>
            <p className="small"><span className="muted">What to do:</span> {e.whatToDo}</p>
            <div className="row">
              {e.deliveries.map((d, i) => <span key={i} className={`chip ${d.status === 'failed' ? 'critical' : 'fresh'}`} title={d.error ?? ''}>{d.channel}: {d.status}</span>)}
              {e.positionId && <Link className="link small" href={`/positions/${encodeURIComponent(e.positionId)}`}>Open position →</Link>}
            </div>
          </article>
        ))}
      </section>
    </div>
  );
}

function QuietHours({ start, end, onSave }: { start: number | null; end: number | null; onSave: (s: string, e: string) => void }) {
  const [s, setS] = useState(start == null ? '' : String(start));
  const [e, setE] = useState(end == null ? '' : String(end));
  const hours = Array.from({ length: 24 }, (_, i) => i);
  return (
    <div className="spread" style={{ borderTop: '1px solid var(--line)', paddingTop: 16 }}>
      <div className="stack" style={{ gap: 2, flex: '1 1 320px' }}>
        <b style={{ fontWeight: 600 }}>Quiet hours</b>
        <span className="small muted">Hold Watch alerts during these local hours. At Risk alerts always come through.</span>
      </div>
      <div className="row">
        <select className="select" style={{ width: 110, height: 40 }} value={s} onChange={(x) => setS(x.target.value)} aria-label="Quiet hours start">
          <option value="">Off</option>{hours.map((h) => <option key={h} value={h}>{String(h).padStart(2, '0')}:00</option>)}
        </select>
        <span className="muted">to</span>
        <select className="select" style={{ width: 110, height: 40 }} value={e} onChange={(x) => setE(x.target.value)} aria-label="Quiet hours end">
          <option value="">Off</option>{hours.map((h) => <option key={h} value={h}>{String(h).padStart(2, '0')}:00</option>)}
        </select>
        <button className="btn btn-sm" onClick={() => onSave(s, e)}>Save</button>
      </div>
    </div>
  );
}
