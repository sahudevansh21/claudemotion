import { Suspense } from 'react';
import PageShell from '@/components/PageShell';
import Stress from './Stress';

export const metadata = { title: 'Stress test — COLLATERA' };

export default function Page() {
  return (
    <PageShell>
      <Suspense>
        <Stress />
      </Suspense>
    </PageShell>
  );
}
