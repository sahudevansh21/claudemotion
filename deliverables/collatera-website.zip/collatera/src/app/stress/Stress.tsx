'use client';

import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { useEffect, useMemo, useState } from 'react';
import { Badge, DataNote, Skeleton, Stat } from '@/components/ui';
import { api, useApi, type Me } from '@/lib/client/api';
import { DEMO_ADDRESS } from '@/lib/chain/demo';
import type { StressResult } from '@/lib/risk/engine';
import { fmtAmount, fmtHf, fmtUsd, pct } from '@/lib/risk/engine';
import type { ScoredPosition } from '@/lib/risk/types';

type Kind = 'drop' | 'gap' | 'oracle_delay';
const PRESETS: { id: string; label: string; kind: Kind; shock: number }[] = [
  { id: 'd10', label: '−10%', kind: 'drop', shock: 0.1 },
  { id: 'd20', label: '−20%', kind: 'drop', shock: 0.2 },
  { id: 'gap', label: 'Overnight gap-down', kind: 'gap', shock: 0.08 },
  { id: 'delay', label: 'Oracle delay', kind: 'oracle_delay', shock: 0.05 },
  { id: 'custom', label: 'Custom', kind: 'drop', shock: 0.3 },
];

export default function Stress() {
  const params = useSearchParams();
  const me = useApi<Me>('/api/me');
  const saved = useApi<{ addresses: { address: string }[] }>(me.data?.user ? '/api/addresses' : null);
  const fromParam = params.get('position');
  const address = (fromParam?.split('~')[1] ?? params.get('address') ?? saved.data?.addresses[0]?.address ?? (me.data && !me.data.user ? DEMO_ADDRESS : null))?.toLowerCase() ?? null;
  const scan = useApi<{ positions: ScoredPosition[] }>(address ? `/api/positions?address=${address}` : null);

  const [positionId, setPositionId] = useState<string>(fromParam ?? '');
  const [preset, setPreset] = useState(PRESETS[0]);
  const [shock, setShock] = useState(0.1);
  const [delayMin, setDelayMin] = useState(60);
  const [targetHf, setTargetHf] = useState(1.5);
  const [results, setResults] = useState<Record<string, StressResult>>({});
  const [err, setErr] = useState<string | null>(null);

  const positions = useMemo(() => (scan.data?.positions ?? []).filter((p) => p.debtUsd > 0), [scan.data]);
  useEffect(() => {
    if (!positionId && positions[0]) setPositionId(positions[0].id);
  }, [positions, positionId]);

  const targets = positionId === 'all' ? positions.map((p) => p.id) : positionId ? [positionId] : [];

  useEffect(() => {
    if (!targets.length) return;
    const t = window.setTimeout(async () => {
      try {
        const out: Record<string, StressResult> = {};
        await Promise.all(targets.map(async (id) => {
          const r = await api<{ result: StressResult }>('/api/stress', { method: 'POST', json: { positionId: id, scenario: preset.kind, shock, delayMin, targetHf } });
          out[id] = r.result;
        }));
        setResults(out);
        setErr(null);
      } catch (e) {
        setErr((e as Error).message);
      }
    }, 180);
    return () => window.clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [targets.join(','), preset.kind, shock, delayMin, targetHf]);

  const one = positionId !== 'all' ? results[positionId] : null;
  const pos = positions.find((p) => p.id === positionId);

  return (
    <div className="container stack" style={{ gap: 28 }}>
      <div className="page-head">
        <span className="eyebrow">Stress test</span>
        <h1 className="display" style={{ fontSize: 'clamp(40px, 6vw, 84px)', marginTop: 8 }}>What if the market moves?</h1>
        <p className="lead">Pick a scenario. We re-run the health factor and show the new buffer, the liquidation point and how much to repay or add to stay above your target.</p>
      </div>

      {!address && <p className="notice">Open a wallet on the <Link className="link" href="/dashboard">dashboard</Link> first, or <Link className="link" href={`/stress?address=${DEMO_ADDRESS}`}>use the demo wallet</Link>.</p>}
      {scan.loading && <Skeleton h={200} />}
      {scan.data && positions.length === 0 && <p className="notice">No positions with debt for this address — nothing to stress.</p>}

      {positions.length > 0 && (
        <div className="card stack" style={{ gap: 22 }}>
          <label className="field">Position
            <select className="select" value={positionId} onChange={(e) => setPositionId(e.target.value)}>
              {positions.map((p) => <option key={p.id} value={p.id}>{p.collateral.map((c) => c.symbol).join(' + ')} — HF {fmtHf(p.healthFactor)}</option>)}
              {positions.length > 1 && <option value="all">All positions</option>}
            </select>
          </label>
          <div className="stack" style={{ gap: 10 }}>
            <span className="small muted">Scenario</span>
            <div className="tabs" role="group" aria-label="Scenario">
              {PRESETS.map((p) => (
                <button key={p.id} className="tab" aria-pressed={preset.id === p.id} onClick={() => { setPreset(p); setShock(p.shock); }}>{p.label}</button>
              ))}
            </div>
          </div>
          <div className="grid grid-3">
            <label className="field">{preset.kind === 'oracle_delay' ? 'Real price move during the delay' : 'Price fall'}: <b className="num" style={{ color: '#fff' }}>{pct(shock, 0)}</b>
              <input type="range" min={0} max={0.6} step={0.01} value={shock} onChange={(e) => { setShock(Number(e.target.value)); if (preset.id !== 'custom' && preset.id !== 'gap' && preset.id !== 'delay') setPreset(PRESETS[4]); }} />
            </label>
            {preset.kind === 'oracle_delay' && (
              <label className="field">Oracle delay (minutes)
                <input className="input" type="number" min={1} max={10080} value={delayMin} onChange={(e) => setDelayMin(Math.max(1, Number(e.target.value) || 1))} />
              </label>
            )}
            <label className="field">Target health factor
              <input className="input" type="number" min={1.05} max={5} step={0.05} value={targetHf} onChange={(e) => setTargetHf(Math.min(5, Math.max(1.05, Number(e.target.value) || 1.5)))} />
            </label>
          </div>
        </div>
      )}

      {err && <p className="notice err">{err}</p>}

      {one && pos && (
        <div className="stack" style={{ gap: 20 }}>
          <div className="card stack" style={{ gap: 20 }}>
            <div className="spread"><h2 className="h3">{one.label}</h2><Badge badge={one.after.badge} /></div>
            <p className="muted small">{one.note}</p>
            <div className="grid grid-4">
              <Stat label="Health factor" value={<>{fmtHf(one.before.healthFactor)} → <span className={`c-${one.after.badge}`}>{fmtHf(one.after.healthFactor)}</span></>} />
              <Stat label="Buffer" value={<>{pct(Math.max(one.before.buffer, 0), 0)} → <span className={`c-${one.after.badge}`}>{pct(Math.max(one.after.buffer, 0), 0)}</span></>} />
              {pos.collateral.filter((c) => c.tokenized).slice(0, 1).map((c) => (
                <Stat key={c.symbol} label={`${c.symbol} price`} value={fmtUsd(one.stressedPrices[c.symbol])} sub={`Liquidation at ${one.liquidationPrices[c.symbol] ? fmtUsd(one.liquidationPrices[c.symbol]!) : '—'}`} />
              ))}
              <Stat label="Status" value={one.after.healthFactor < 1 ? 'Liquidatable' : one.after.badge === 'safe' ? 'OK' : 'Thin'} tone={one.after.healthFactor < 1 ? 'risk' : one.after.badge} />
            </div>
          </div>
          <div className="card stack">
            <h2 className="h3">To stay at HF {targetHf} in this scenario</h2>
            {!one.plan.repay && one.plan.add.length === 0 ? (
              <p className="c-safe">No action needed — the position stays above your target.</p>
            ) : (
              <div className="grid grid-2">
                {one.plan.repay && (
                  <div className="stack" style={{ gap: 6 }}>
                    <span className="eyebrow">Repay</span>
                    <span className="h3 num">{fmtAmount(one.plan.repay.amount, one.plan.repay.symbol)}</span>
                    <span className="small muted">≈ {fmtUsd(one.plan.repay.usd)}{one.plan.repay.capped ? ' — repaying all debt in this asset is not enough on its own' : ''}</span>
                  </div>
                )}
                {one.plan.add[0] && (
                  <div className="stack" style={{ gap: 6 }}>
                    <span className="eyebrow">or add collateral</span>
                    <span className="h3 num">{fmtAmount(one.plan.add[0].amount, one.plan.add[0].symbol)}</span>
                    <span className="small muted">≈ {fmtUsd(one.plan.add[0].usd)} at the stressed price</span>
                  </div>
                )}
              </div>
            )}
            <div className="row"><Link className="btn" href={`/plan/${encodeURIComponent(pos.id)}?targetHf=${targetHf}`}>Open the repayment planner</Link></div>
          </div>
        </div>
      )}

      {positionId === 'all' && Object.keys(results).length > 0 && (
        <div className="card table-wrap">
          <table className="table">
            <thead><tr><th>Position</th><th>HF now</th><th>HF after</th><th>Buffer after</th><th>Status</th><th>Repay to {targetHf}</th></tr></thead>
            <tbody>
              {positions.map((p) => {
                const r = results[p.id];
                if (!r) return null;
                return (
                  <tr key={p.id}>
                    <td>{p.collateral.map((c) => c.symbol).join(' + ')}</td>
                    <td>{fmtHf(r.before.healthFactor)}</td>
                    <td className={`c-${r.after.badge}`}>{fmtHf(r.after.healthFactor)}</td>
                    <td>{pct(Math.max(r.after.buffer, 0), 0)}</td>
                    <td><Badge badge={r.after.badge} /></td>
                    <td>{r.plan.repay ? fmtAmount(r.plan.repay.amount, r.plan.repay.symbol) : '—'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
      <DataNote />
    </div>
  );
}
