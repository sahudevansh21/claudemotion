import { z } from 'zod';
import { normalize } from 'viem/ens';
import { publicClient } from '@/lib/chain/aave';
import { env } from '@/lib/server/env';
import { HttpError, json, parseBody, rejectSecrets, route } from '@/lib/server/http';
import { addressSchema } from '@/lib/server/validators';

const body = z.object({ query: z.string().trim().min(3).max(200) });

/** Resolves an address or ENS name to a lowercase address. */
export const POST = route(async (req: Request) => {
  const { query } = await parseBody(req, body);
  rejectSecrets(query);
  if (query.toLowerCase().endsWith('.eth')) {
    if (env().CHAIN_ID !== 1 || !env().RPC_URL) throw new HttpError('ENS names need a mainnet RPC. Paste the 0x address instead.', 422);
    const address = await publicClient().getEnsAddress({ name: normalize(query) });
    if (!address) throw new HttpError(`${query} does not resolve to an address.`, 404);
    return json({ address: address.toLowerCase(), ens: query });
  }
  return json({ address: addressSchema.parse(query) });
}, { limit: 30 });
