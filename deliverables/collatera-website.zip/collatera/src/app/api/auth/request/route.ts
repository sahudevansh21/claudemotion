import { z } from 'zod';
import { requestLogin } from '@/lib/server/auth';
import { json, parseBody, route } from '@/lib/server/http';

const body = z.object({ email: z.string().trim().email().max(200), next: z.string().max(200).optional() });

export const POST = route(async (req: Request) => {
  const { email, next } = await parseBody(req, body);
  const r = await requestLogin(email, next);
  return json({ ok: true, ...r });
}, { limit: 5 });
