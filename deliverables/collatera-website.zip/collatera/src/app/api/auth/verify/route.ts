import { NextResponse } from 'next/server';
import { sessionCookie, verifyLogin } from '@/lib/server/auth';
import { env } from '@/lib/server/env';

export const dynamic = 'force-dynamic';

export async function GET(req: Request) {
  const url = new URL(req.url);
  const token = url.searchParams.get('token') ?? '';
  const next = url.searchParams.get('next') ?? '/dashboard';
  const safeNext = next.startsWith('/') && !next.startsWith('//') ? next : '/dashboard';
  try {
    const session = await verifyLogin(token);
    const res = NextResponse.redirect(new URL(safeNext, env().APP_URL));
    res.cookies.set(sessionCookie(session));
    return res;
  } catch {
    return NextResponse.redirect(new URL('/login?error=expired', env().APP_URL));
  }
}
