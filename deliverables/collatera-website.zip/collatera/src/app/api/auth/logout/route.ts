import { SESSION_COOKIE, logout, requireSameOrigin } from '@/lib/server/auth';
import { json, route } from '@/lib/server/http';

export const POST = route(async (req: Request) => {
  requireSameOrigin(req);
  await logout();
  const res = json({ ok: true });
  res.cookies.delete(SESSION_COOKIE);
  return res;
});
