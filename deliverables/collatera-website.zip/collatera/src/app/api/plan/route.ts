import { z } from 'zod';
import { bufferFromHf, debtUsd, healthFactor, weightedCollateralUsd } from '@/lib/risk/engine';
import { adapterForPositionId } from '@/lib/chain';
import type { Address } from '@/lib/chain/types';
import { HttpError, json, parseBody, route } from '@/lib/server/http';
import { getPosition, serialize } from '@/lib/server/positions';
import { targetHfSchema } from '@/lib/server/validators';

const body = z.object({
  positionId: z.string().min(5),
  kind: z.enum(['repay', 'add']),
  targetHf: targetHfSchema,
  /** for "add": which collateral token to top up */
  token: z.string().optional(),
});

export const POST = route(async (req: Request) => {
  const b = await parseBody(req, body);
  const p = await getPosition(b.positionId, { fresh: true, targetHf: b.targetHf });
  if (!p) throw new HttpError('Position not found', 404);
  const adapter = adapterForPositionId(p.id);
  const owner = p.owner as Address;

  if (b.kind === 'repay') {
    const r = p.plan.repay;
    if (!r) throw new HttpError(`Health factor is already at or above ${b.targetHf} — nothing to repay.`, 409);
    const leg = p.debt.find((d) => d.token === r.token)!;
    const txs = await adapter.buildRepayTx({ owner, token: r.token as Address, amount: r.amount, decimals: leg.decimals, symbol: r.symbol });
    const debtAfter = p.debt.map((d) => (d.token === r.token ? { ...d, amount: d.amount - r.amount } : d));
    const hfAfter = healthFactor(weightedCollateralUsd(p.collateral), debtUsd(debtAfter));
    const simulation = await adapter.simulate({ owner, token: r.token as Address, amount: r.amount, decimals: leg.decimals, txs });
    return json(serialize({
      kind: 'repay', demo: p.demo, chainId: p.chainId, owner, amount: r.amount, symbol: r.symbol, usd: r.usd, capped: r.capped,
      before: { healthFactor: p.healthFactor, buffer: p.buffer }, after: { healthFactor: hfAfter, buffer: bufferFromHf(hfAfter) },
      txs, simulation,
    }));
  }

  const add = (b.token ? p.plan.add.find((a) => a.token === b.token) : p.plan.add[0]);
  if (!add) throw new HttpError(`Health factor is already at or above ${b.targetHf} — nothing to add.`, 409);
  const leg = p.collateral.find((c) => c.token === add.token)!;
  const txs = await adapter.buildSupplyTx({ owner, token: add.token as Address, amount: add.amount, decimals: leg.decimals, symbol: add.symbol });
  const collAfter = p.collateral.map((c) => (c.token === add.token ? { ...c, amount: c.amount + add.amount } : c));
  const hfAfter = healthFactor(weightedCollateralUsd(collAfter), p.debtUsd);
  const simulation = await adapter.simulate({ owner, token: add.token as Address, amount: add.amount, decimals: leg.decimals, txs });
  return json(serialize({
    kind: 'add', demo: p.demo, chainId: p.chainId, owner, amount: add.amount, symbol: add.symbol, usd: add.usd, capped: false,
    before: { healthFactor: p.healthFactor, buffer: p.buffer }, after: { healthFactor: hfAfter, buffer: bufferFromHf(hfAfter) },
    txs, simulation,
  }));
}, { limit: 30 });
