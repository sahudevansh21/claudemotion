import { sha256 } from '@/lib/server/crypto';
import { db } from '@/lib/server/db';
import { error, json, route } from '@/lib/server/http';
import { scanAddress, serialize } from '@/lib/server/positions';
import { addressSchema } from '@/lib/server/validators';

export const dynamic = 'force-dynamic';

/** B2B API: GET /api/v1/positions?address=0x… with `Authorization: Bearer coll_…`. */
export const GET = route(async (req: Request) => {
  const auth = req.headers.get('authorization') ?? '';
  const key = auth.startsWith('Bearer ') ? auth.slice(7).trim() : '';
  const row = key ? await db.apiKey.findUnique({ where: { hash: sha256(key) } }) : null;
  if (!row) return error('Invalid API key', 401);
  await db.apiKey.update({ where: { id: row.id }, data: { lastUsed: new Date() } });
  const address = addressSchema.parse(new URL(req.url).searchParams.get('address') ?? '');
  const positions = await scanAddress(address);
  return json(serialize({
    address,
    positions: positions.map((p) => ({
      id: p.id, market: p.marketName, badge: p.badge, healthFactor: p.healthFactor, buffer: p.buffer,
      effectiveBuffer: p.effectiveBuffer, collateralUsd: p.collateralUsd, debtUsd: p.debtUsd, worstFeed: p.worstFeed,
      marketClosed: p.marketClosed, reasons: p.reasons, explanation: p.explanation, scoredAt: p.scoredAt,
    })),
  }));
}, { limit: 120 });
