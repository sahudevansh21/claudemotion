import { z } from 'zod';
import { requireSameOrigin, requireUser } from '@/lib/server/auth';
import { db } from '@/lib/server/db';
import { HttpError, json, parseBody, rejectSecrets, route } from '@/lib/server/http';
import { addressSchema } from '@/lib/server/validators';

export const dynamic = 'force-dynamic';

const LIMITS: Record<string, number> = { free: 1, pro: 10, team: 500 };

export const GET = route(async () => {
  const user = await requireUser();
  return json({ addresses: await db.watchedAddress.findMany({ where: { userId: user.id }, orderBy: { createdAt: 'asc' } }), limit: LIMITS[user.plan] ?? 1 });
});

const body = z.object({ address: z.string(), label: z.string().trim().max(60).optional() });

export const POST = route(async (req: Request) => {
  requireSameOrigin(req);
  const user = await requireUser();
  const b = await parseBody(req, body);
  rejectSecrets(b.address);
  const address = addressSchema.parse(b.address);
  const count = await db.watchedAddress.count({ where: { userId: user.id } });
  const limit = LIMITS[user.plan] ?? 1;
  const exists = await db.watchedAddress.findUnique({ where: { userId_address: { userId: user.id, address } } });
  if (!exists && count >= limit) throw new HttpError(`Your ${user.plan} plan monitors up to ${limit} address${limit === 1 ? '' : 'es'}. Upgrade on the Pricing page to add more.`, 402);
  const row = await db.watchedAddress.upsert({
    where: { userId_address: { userId: user.id, address } },
    update: { label: b.label },
    create: { userId: user.id, address, label: b.label },
  });
  return json({ address: row });
});

export const DELETE = route(async (req: Request) => {
  requireSameOrigin(req);
  const user = await requireUser();
  const id = new URL(req.url).searchParams.get('id') ?? '';
  await db.watchedAddress.deleteMany({ where: { id, userId: user.id } });
  return json({ ok: true });
});
