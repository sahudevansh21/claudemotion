import { marketStatus } from '@/lib/risk/calendar';
import { json, route } from '@/lib/server/http';

export const dynamic = 'force-dynamic';

export const GET = route(async () => json({ markets: [marketStatus('XNYS'), marketStatus('XNAS')], at: new Date().toISOString() }));
