import { db } from '@/lib/server/db';
import { json, route } from '@/lib/server/http';

export const dynamic = 'force-dynamic';

export const GET = route(async () => json({ feeds: await db.feedStatus.findMany({ orderBy: { asset: 'asc' } }) }));
