import { requireSameOrigin, requireUser } from '@/lib/server/auth';
import { db } from '@/lib/server/db';
import { json, route } from '@/lib/server/http';
import { createCheckout } from '@/lib/server/stripe';

export const POST = route(async (req: Request) => {
  requireSameOrigin(req);
  const user = await requireUser();
  const sub = await db.subscription.findUnique({ where: { userId: user.id } });
  const s = await createCheckout(user, sub?.stripeCustomerId);
  return json({ url: s.url });
});
