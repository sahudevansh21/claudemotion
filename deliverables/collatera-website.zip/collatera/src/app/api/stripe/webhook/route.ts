import { db } from '@/lib/server/db';
import { error, json } from '@/lib/server/http';
import { verifyWebhook } from '@/lib/server/stripe';

interface StripeEvent { type: string; data: { object: Record<string, unknown> } }

export async function POST(req: Request) {
  const payload = await req.text();
  if (!verifyWebhook(payload, req.headers.get('stripe-signature'))) return error('Bad signature', 400);
  const event = JSON.parse(payload) as StripeEvent;
  const o = event.data.object;

  if (event.type === 'checkout.session.completed' && o.client_reference_id) {
    const userId = String(o.client_reference_id);
    await db.subscription.upsert({
      where: { userId },
      update: { stripeCustomerId: String(o.customer), stripeSubId: String(o.subscription), plan: 'pro', status: 'active' },
      create: { userId, stripeCustomerId: String(o.customer), stripeSubId: String(o.subscription), plan: 'pro', status: 'active' },
    });
    await db.user.update({ where: { id: userId }, data: { plan: 'pro' } });
  }

  if (event.type === 'customer.subscription.updated' || event.type === 'customer.subscription.deleted') {
    const sub = await db.subscription.findFirst({ where: { stripeSubId: String(o.id) } });
    if (sub) {
      const status = String(o.status);
      const active = event.type === 'customer.subscription.updated' && (status === 'active' || status === 'trialing');
      await db.subscription.update({ where: { id: sub.id }, data: { status } });
      await db.user.update({ where: { id: sub.userId }, data: { plan: active ? 'pro' : 'free' } });
    }
  }
  return json({ received: true });
}
