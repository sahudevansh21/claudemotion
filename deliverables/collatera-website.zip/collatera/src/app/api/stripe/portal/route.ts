import { requireSameOrigin, requireUser } from '@/lib/server/auth';
import { db } from '@/lib/server/db';
import { HttpError, json, route } from '@/lib/server/http';
import { createPortal } from '@/lib/server/stripe';

export const POST = route(async (req: Request) => {
  requireSameOrigin(req);
  const user = await requireUser();
  const sub = await db.subscription.findUnique({ where: { userId: user.id } });
  if (!sub?.stripeCustomerId) throw new HttpError('No billing account yet.', 404);
  return json({ url: (await createPortal(sub.stripeCustomerId)).url });
});
