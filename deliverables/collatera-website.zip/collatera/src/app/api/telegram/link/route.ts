import { requireSameOrigin, requireUser } from '@/lib/server/auth';
import { randomToken } from '@/lib/server/crypto';
import { db } from '@/lib/server/db';
import { env } from '@/lib/server/env';
import { HttpError, json, route } from '@/lib/server/http';

export const POST = route(async (req: Request) => {
  requireSameOrigin(req);
  const user = await requireUser();
  const bot = env().TELEGRAM_BOT_USERNAME;
  if (!env().TELEGRAM_BOT_TOKEN || !bot) throw new HttpError('Telegram is not configured on this server (set TELEGRAM_BOT_TOKEN and TELEGRAM_BOT_USERNAME).', 501);
  const code = randomToken(12);
  await db.user.update({ where: { id: user.id }, data: { telegramCode: code } });
  return json({ url: `https://t.me/${bot}?start=${code}`, code });
});

export const DELETE = route(async (req: Request) => {
  requireSameOrigin(req);
  const user = await requireUser();
  await db.user.update({ where: { id: user.id }, data: { telegramChatId: null, telegramCode: null } });
  return json({ ok: true });
});
