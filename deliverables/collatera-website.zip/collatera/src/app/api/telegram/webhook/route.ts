import { safeEqual } from '@/lib/server/crypto';
import { env } from '@/lib/server/env';
import { error, json } from '@/lib/server/http';
import { handleTelegramUpdate } from '@/lib/server/telegram';

export async function POST(req: Request) {
  const secret = env().TELEGRAM_WEBHOOK_SECRET;
  const got = req.headers.get('x-telegram-bot-api-secret-token') ?? '';
  if (!secret || !safeEqual(got, secret)) return error('Forbidden', 403);
  await handleTelegramUpdate(await req.json());
  return json({ ok: true });
}
