import { z } from 'zod';
import { db } from '@/lib/server/db';
import { env } from '@/lib/server/env';
import { json, parseBody, route } from '@/lib/server/http';
import { sendEmail } from '@/lib/server/notify';

const body = z.object({
  name: z.string().trim().min(1).max(100),
  email: z.string().trim().email(),
  company: z.string().trim().max(120).optional(),
  message: z.string().trim().min(10).max(4000),
});

export const POST = route(async (req: Request) => {
  const b = await parseBody(req, body);
  await db.contactRequest.create({ data: b });
  const admins = env().ADMIN_EMAILS.split(',').map((s) => s.trim()).filter(Boolean);
  for (const a of admins) await sendEmail(a, `[COLLATERA] B2B enquiry from ${b.name}`, `${b.name} <${b.email}> ${b.company ?? ''}\n\n${b.message}`);
  return json({ ok: true });
}, { limit: 5 });
