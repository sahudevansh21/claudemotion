import { z } from 'zod';
import { stress, type StressScenario } from '@/lib/risk/engine';
import { HttpError, json, parseBody, route } from '@/lib/server/http';
import { getPosition, serialize } from '@/lib/server/positions';
import { targetHfSchema } from '@/lib/server/validators';

const body = z.object({
  positionId: z.string().min(5),
  scenario: z.enum(['drop', 'gap', 'oracle_delay']),
  shock: z.number().min(0).max(0.9),
  delayMin: z.number().int().min(1).max(10_080).default(60),
  targetHf: targetHfSchema,
});

export const POST = route(async (req: Request) => {
  const b = await parseBody(req, body);
  const p = await getPosition(b.positionId);
  if (!p) throw new HttpError('Position not found', 404);
  const scenario: StressScenario = b.scenario === 'oracle_delay'
    ? { kind: 'oracle_delay', shock: b.shock, delayMin: b.delayMin }
    : { kind: b.scenario, shock: b.shock };
  return json(serialize({ position: { id: p.id, collateral: p.collateral, debt: p.debt }, result: stress(p, scenario, b.targetHf) }));
}, { limit: 60 });
