import { HttpError, json, route } from '@/lib/server/http';
import { getPosition, history, serialize } from '@/lib/server/positions';
import { targetHfSchema } from '@/lib/server/validators';

export const dynamic = 'force-dynamic';

export const GET = route(async (req: Request, { params }: { params: { id: string } }) => {
  const id = decodeURIComponent(params.id);
  const targetHf = targetHfSchema.parse(new URL(req.url).searchParams.get('targetHf') ?? undefined);
  const position = await getPosition(id, { targetHf });
  if (!position) throw new HttpError('Position not found. It may have been closed.', 404);
  return json(serialize({ position, history: await history(id) }));
}, { limit: 60 });
