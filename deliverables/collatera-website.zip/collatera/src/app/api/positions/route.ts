import { z } from 'zod';
import { json, rejectSecrets, route } from '@/lib/server/http';
import { scanAddress, serialize } from '@/lib/server/positions';
import { addressSchema, targetHfSchema } from '@/lib/server/validators';
import { adapterFor } from '@/lib/chain';

export const dynamic = 'force-dynamic';

export const GET = route(async (req: Request) => {
  const url = new URL(req.url);
  const raw = url.searchParams.get('address') ?? '';
  rejectSecrets(raw);
  const address = addressSchema.parse(raw);
  const targetHf = targetHfSchema.parse(url.searchParams.get('targetHf') ?? undefined);
  const fresh = z.coerce.boolean().parse(url.searchParams.get('fresh') ?? false);
  const adapter = adapterFor(address);
  const positions = await scanAddress(address, { targetHf, fresh });
  return json(serialize({ address, market: { id: adapter.id, name: adapter.name, chainId: adapter.chainId }, positions, checkedAt: new Date().toISOString() }));
}, { limit: 30 });
