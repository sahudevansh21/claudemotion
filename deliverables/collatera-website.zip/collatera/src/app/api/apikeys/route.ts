import { z } from 'zod';
import { requireSameOrigin, requireUser } from '@/lib/server/auth';
import { randomToken, sha256 } from '@/lib/server/crypto';
import { db } from '@/lib/server/db';
import { HttpError, json, parseBody, route } from '@/lib/server/http';

export const dynamic = 'force-dynamic';

export const GET = route(async () => {
  const user = await requireUser();
  const keys = await db.apiKey.findMany({ where: { userId: user.id }, select: { id: true, name: true, prefix: true, lastUsed: true, createdAt: true } });
  return json({ keys });
});

export const POST = route(async (req: Request) => {
  requireSameOrigin(req);
  const user = await requireUser();
  if (user.plan === 'free') throw new HttpError('API keys are available on Pro and Team plans.', 402);
  const { name } = await parseBody(req, z.object({ name: z.string().trim().min(1).max(60) }));
  const key = `coll_${randomToken(24)}`;
  await db.apiKey.create({ data: { userId: user.id, name, hash: sha256(key), prefix: key.slice(0, 10) } });
  return json({ key }); // shown once
});

export const DELETE = route(async (req: Request) => {
  requireSameOrigin(req);
  const user = await requireUser();
  await db.apiKey.deleteMany({ where: { id: new URL(req.url).searchParams.get('id') ?? '', userId: user.id } });
  return json({ ok: true });
});
