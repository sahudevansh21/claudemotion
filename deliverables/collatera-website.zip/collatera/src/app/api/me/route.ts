import { z } from 'zod';
import { currentUser, requireSameOrigin, requireUser } from '@/lib/server/auth';
import { db } from '@/lib/server/db';
import { env, isAdmin } from '@/lib/server/env';
import { json, parseBody, route } from '@/lib/server/http';

export const dynamic = 'force-dynamic';

export const GET = route(async () => {
  const user = await currentUser();
  if (!user) return json({ user: null });
  const sub = await db.subscription.findUnique({ where: { userId: user.id } });
  return json({
    user: {
      id: user.id, email: user.email, plan: user.plan,
      quietStart: user.quietStart, quietEnd: user.quietEnd, tzOffsetMin: user.tzOffsetMin,
      telegramConnected: !!user.telegramChatId, admin: isAdmin(user.email),
      billing: sub ? { plan: sub.plan, status: sub.status, portal: !!sub.stripeCustomerId } : null,
    },
    features: {
      telegram: !!env().TELEGRAM_BOT_TOKEN, telegramBot: env().TELEGRAM_BOT_USERNAME ?? null,
      push: !!env().NEXT_PUBLIC_VAPID_PUBLIC_KEY, email: !!env().RESEND_API_KEY, billing: !!env().STRIPE_SECRET_KEY,
    },
  });
});

const patch = z.object({
  quietStart: z.number().int().min(0).max(23).nullable().optional(),
  quietEnd: z.number().int().min(0).max(23).nullable().optional(),
  tzOffsetMin: z.number().int().min(-840).max(840).optional(),
});

export const PATCH = route(async (req: Request) => {
  requireSameOrigin(req);
  const user = await requireUser();
  const data = await parseBody(req, patch);
  await db.user.update({ where: { id: user.id }, data });
  return json({ ok: true });
});

export const DELETE = route(async (req: Request) => {
  requireSameOrigin(req);
  const user = await requireUser();
  await db.user.delete({ where: { id: user.id } });
  const res = json({ ok: true });
  res.cookies.delete('coll_session');
  return res;
});
