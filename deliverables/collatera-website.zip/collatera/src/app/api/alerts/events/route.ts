import { requireUser } from '@/lib/server/auth';
import { db } from '@/lib/server/db';
import { json, route } from '@/lib/server/http';

export const dynamic = 'force-dynamic';

export const GET = route(async () => {
  const user = await requireUser();
  const events = await db.alertEvent.findMany({
    where: { rule: { userId: user.id } },
    orderBy: { createdAt: 'desc' },
    take: 100,
    include: { deliveries: { select: { channel: true, status: true, error: true } } },
  });
  return json({ events });
});
