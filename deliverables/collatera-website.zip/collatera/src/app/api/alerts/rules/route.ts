import { z } from 'zod';
import { requireSameOrigin, requireUser } from '@/lib/server/auth';
import { db } from '@/lib/server/db';
import { json, parseBody, route } from '@/lib/server/http';
import { addressSchema } from '@/lib/server/validators';

export const dynamic = 'force-dynamic';

export const GET = route(async () => {
  const user = await requireUser();
  return json({ rules: await db.alertRule.findMany({ where: { userId: user.id }, orderBy: { createdAt: 'asc' } }) });
});

const kinds = z.enum(['buffer_below', 'feed_stale', 'issuer_event', 'market_transition']);
const create = z.object({
  kind: kinds,
  threshold: z.number().min(0.01).max(0.9).nullable().optional(),
  address: addressSchema.nullable().optional(),
});

export const POST = route(async (req: Request) => {
  requireSameOrigin(req);
  const user = await requireUser();
  const b = await parseBody(req, create);
  const rule = await db.alertRule.create({ data: { userId: user.id, kind: b.kind, threshold: b.threshold ?? null, address: b.address ?? null } });
  return json({ rule });
});

const update = z.object({ id: z.string(), enabled: z.boolean().optional(), threshold: z.number().min(0.01).max(0.9).nullable().optional() });

export const PATCH = route(async (req: Request) => {
  requireSameOrigin(req);
  const user = await requireUser();
  const { id, ...data } = await parseBody(req, update);
  await db.alertRule.updateMany({ where: { id, userId: user.id }, data });
  return json({ ok: true });
});

export const DELETE = route(async (req: Request) => {
  requireSameOrigin(req);
  const user = await requireUser();
  await db.alertRule.deleteMany({ where: { id: new URL(req.url).searchParams.get('id') ?? '', userId: user.id } });
  return json({ ok: true });
});
