import { z } from 'zod';
import { requireSameOrigin, requireUser } from '@/lib/server/auth';
import { db } from '@/lib/server/db';
import { json, parseBody, route } from '@/lib/server/http';

const body = z.object({ endpoint: z.string().url(), keys: z.object({ p256dh: z.string(), auth: z.string() }) });

export const POST = route(async (req: Request) => {
  requireSameOrigin(req);
  const user = await requireUser();
  const s = await parseBody(req, body);
  await db.pushSubscription.upsert({
    where: { endpoint: s.endpoint },
    update: { userId: user.id, p256dh: s.keys.p256dh, auth: s.keys.auth },
    create: { userId: user.id, endpoint: s.endpoint, p256dh: s.keys.p256dh, auth: s.keys.auth },
  });
  return json({ ok: true });
});

export const DELETE = route(async (req: Request) => {
  requireSameOrigin(req);
  const user = await requireUser();
  await db.pushSubscription.deleteMany({ where: { userId: user.id } });
  return json({ ok: true });
});
