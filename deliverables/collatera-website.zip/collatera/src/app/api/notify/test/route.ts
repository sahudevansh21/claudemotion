import { z } from 'zod';
import { requireSameOrigin, requireUser } from '@/lib/server/auth';
import { env } from '@/lib/server/env';
import { HttpError, json, parseBody, route } from '@/lib/server/http';
import { sendEmail, sendPush, sendTelegram } from '@/lib/server/notify';

const body = z.object({ channel: z.enum(['email', 'telegram', 'push']) });

export const POST = route(async (req: Request) => {
  requireSameOrigin(req);
  const user = await requireUser();
  const { channel } = await parseBody(req, body);
  const msg = 'Test alert from COLLATERA. If you can read this, the channel works.';
  let r;
  if (channel === 'email') r = await sendEmail(user.email, '[COLLATERA] Test alert', msg);
  else if (channel === 'telegram') {
    if (!user.telegramChatId) throw new HttpError('Connect Telegram first.', 409);
    r = await sendTelegram(user.telegramChatId, msg);
  } else r = await sendPush(user.id, { title: 'COLLATERA test alert', body: msg, url: `${env().APP_URL}/alerts` });
  return json(r);
}, { limit: 10 });
