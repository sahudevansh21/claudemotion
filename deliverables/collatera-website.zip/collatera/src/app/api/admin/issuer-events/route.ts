import { z } from 'zod';
import { requireSameOrigin, requireUser } from '@/lib/server/auth';
import { db } from '@/lib/server/db';
import { isAdmin } from '@/lib/server/env';
import { HttpError, json, parseBody, route } from '@/lib/server/http';

export const dynamic = 'force-dynamic';

export const GET = route(async () => json({ events: await db.issuerEvent.findMany({ orderBy: { occurredAt: 'desc' }, take: 100 }) }));

const body = z.object({
  asset: z.string().trim().min(1).max(20),
  kind: z.enum(['pause', 'unpause', 'allowlist', 'redemption', 'corporate_action', 'other']),
  description: z.string().trim().min(5).max(500),
  sourceUrl: z.string().url().optional(),
  occurredAt: z.string().datetime().optional(),
  active: z.boolean().default(true),
});

async function requireAdmin() {
  const user = await requireUser();
  if (!isAdmin(user.email)) throw new HttpError('Admins only (ADMIN_EMAILS).', 403);
}

export const POST = route(async (req: Request) => {
  requireSameOrigin(req);
  await requireAdmin();
  const b = await parseBody(req, body);
  const ev = await db.issuerEvent.create({ data: { ...b, occurredAt: b.occurredAt ? new Date(b.occurredAt) : new Date() } });
  return json({ event: ev });
});

export const PATCH = route(async (req: Request) => {
  requireSameOrigin(req);
  await requireAdmin();
  const { id, active } = await parseBody(req, z.object({ id: z.string(), active: z.boolean() }));
  await db.issuerEvent.update({ where: { id }, data: { active } });
  return json({ ok: true });
});
