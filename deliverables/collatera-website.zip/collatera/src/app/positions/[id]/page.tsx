import PageShell from '@/components/PageShell';
import PositionDetail from './PositionDetail';

export const metadata = { title: 'Position — COLLATERA' };

export default function Page({ params }: { params: { id: string } }) {
  return (
    <PageShell>
      <PositionDetail id={decodeURIComponent(params.id)} />
    </PageShell>
  );
}
