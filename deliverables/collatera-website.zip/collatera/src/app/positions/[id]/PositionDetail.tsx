'use client';

import Link from 'next/link';
import HfChart from '@/components/HfChart';
import { Badge, BufferBar, DataNote, FeedChip, Skeleton, Stat } from '@/components/ui';
import { useAgo, useApi } from '@/lib/client/api';
import { fmtAmount, fmtHf, fmtUsd, pct } from '@/lib/risk/engine';
import type { ScoredPosition } from '@/lib/risk/types';

interface Detail { position: ScoredPosition; history: { createdAt: string; healthFactor: number; buffer: number }[] }

export default function PositionDetail({ id }: { id: string }) {
  const { data, error, loading, updatedAt } = useApi<Detail>(`/api/positions/${encodeURIComponent(id)}`, { refreshMs: 30_000 });
  const ago = useAgo(updatedAt);
  const enc = encodeURIComponent(id);

  if (error) return <div className="container page-head"><p className="notice err">{error.message}</p></div>;
  if (loading || !data) return <div className="container page-head stack"><Skeleton h={80} /><Skeleton h={300} /></div>;

  const p = data.position;
  const noDebt = p.debtUsd <= 0;

  return (
    <div className="container stack" style={{ gap: 28 }}>
      <div className="page-head stack" style={{ gap: 14, paddingBottom: 0 }}>
        <Link href={`/dashboard?address=${p.owner}`} className="link small muted" style={{ width: 'fit-content' }}>← All positions for {p.owner.slice(0, 6)}…{p.owner.slice(-4)}</Link>
        <div className="spread">
          <h1 className="display" style={{ fontSize: 'clamp(40px, 6vw, 84px)' }}>{p.collateral.map((c) => c.symbol).join(' + ')}</h1>
          <Badge badge={p.badge} />
        </div>
        <span className="small muted">{p.marketName} · updated {ago}{p.demo ? ' · demo data' : ''}</span>
      </div>

      <div className="card grid grid-4">
        <Stat label="Health factor" value={noDebt ? '∞' : fmtHf(p.healthFactor)} tone={p.badge} sub={p.protocolHealthFactor ? `Protocol reports ${p.protocolHealthFactor.toFixed(3)}` : undefined} />
        <Stat label="Buffer" value={noDebt ? '100%' : pct(Math.max(p.buffer, 0))} sub={p.marketClosed ? `Effective ${pct(Math.max(p.effectiveBuffer, 0))} while closed` : 'Before liquidation'} />
        <Stat label="Collateral" value={fmtUsd(p.collateralUsd)} sub={`Weighted ${fmtUsd(p.weightedCollateralUsd)}`} />
        <Stat label="Debt" value={fmtUsd(p.debtUsd)} sub={p.debt.map((d) => fmtAmount(d.amount, d.symbol)).join(', ') || 'None'} />
      </div>
      {!noDebt && <BufferBar buffer={p.buffer} effective={p.effectiveBuffer} />}

      <section className="card stack" style={{ gap: 16 }}>
        <h2 className="h3">What this means</h2>
        <p style={{ fontSize: 18 }}>{p.explanation.headline}</p>
        <dl className="stack" style={{ gap: 12, margin: 0 }}>
          <div><dt className="eyebrow">What changed</dt><dd style={{ margin: '4px 0 0' }}>{p.explanation.whatChanged}</dd></div>
          <div><dt className="eyebrow">Why it matters</dt><dd style={{ margin: '4px 0 0' }}>{p.explanation.whyItMatters}</dd></div>
          <div><dt className="eyebrow">What to do</dt><dd style={{ margin: '4px 0 0' }}>{p.explanation.whatToDo}</dd></div>
        </dl>
        <div className="row">
          {!noDebt && <Link className="btn btn-solid" href={`/plan/${enc}`}>Plan a repayment</Link>}
          <Link className="btn" href={`/stress?position=${enc}`}>Run a stress test</Link>
          <Link className="btn btn-ghost" href="/alerts">Set alerts</Link>
        </div>
      </section>

      <section className="card stack">
        <h2 className="h3">Health factor — last 7 days</h2>
        <HfChart points={data.history} target={p.plan.targetHf} />
      </section>

      <section className="card stack">
        <h2 className="h3">Collateral breakdown</h2>
        <div className="table-wrap">
          <table className="table">
            <thead><tr><th>Asset</th><th>Amount</th><th>Oracle price</th><th>Value</th><th>Liq. threshold</th><th>Share</th><th>Liquidation price</th><th>Feed</th></tr></thead>
            <tbody>
              {p.collateral.map((c) => {
                const f = p.feeds.find((x) => x.symbol === c.symbol);
                const lp = p.liquidationPrices[c.symbol];
                return (
                  <tr key={c.token}>
                    <td><b style={{ fontWeight: 600 }}>{c.symbol}</b>{c.underlying && <div className="small muted">{c.underlying} · {c.issuer}</div>}{!c.tokenized && <div className="small muted">not a tokenized stock</div>}</td>
                    <td>{c.amount.toLocaleString('en-US', { maximumFractionDigits: 4 })}</td>
                    <td>{fmtUsd(c.price)}</td>
                    <td>{fmtUsd(c.amount * c.price)}</td>
                    <td>{pct(c.liquidationThreshold, 0)}</td>
                    <td>{pct((c.amount * c.price) / p.collateralUsd, 0)}</td>
                    <td>{lp && c.tokenized ? <>{fmtUsd(lp)} <span className="small muted">({pct(1 - lp / c.price, 0)} away)</span></> : '—'}</td>
                    <td>{f ? <FeedChip state={f.state} ageSec={f.ageSec} /> : <span className="small muted">n/a</span>}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>

      <div className="grid grid-2">
        <section className="card stack">
          <h2 className="h3">Price feeds</h2>
          {p.feeds.length === 0 && <p className="muted small">No tokenized collateral feeds on this position.</p>}
          {p.feeds.map((f) => (
            <dl className="kv" key={f.symbol}>
              <dt>{f.symbol}</dt><dd><FeedChip state={f.state} ageSec={f.ageSec} /></dd>
              <dt>Last update</dt><dd>{f.ageSec == null ? 'unknown' : `${Math.round(f.ageSec / 60)} min ago`}</dd>
              <dt>Expected every</dt><dd>{Math.round(f.heartbeatSec / 60)} min</dd>
              <dt>Feed</dt><dd className="small" style={{ wordBreak: 'break-all' }}>{f.feed ?? '—'}</dd>
            </dl>
          ))}
        </section>
        <section className="card stack">
          <h2 className="h3">Market hours</h2>
          {p.markets.length === 0 && <p className="muted small">No exchange-linked collateral.</p>}
          {p.markets.map((m) => (
            <dl className="kv" key={m.exchange}>
              <dt>{m.name}</dt><dd className={m.open ? 'c-safe' : 'c-watch'}>{m.open ? 'Open' : 'Closed'}{m.earlyClose ? ' · early close' : ''}</dd>
              <dt>{m.open ? 'Closes' : 'Opens'}</dt><dd>{new Date(m.open ? m.nextClose : m.nextOpen).toLocaleString()}</dd>
            </dl>
          ))}
          {p.marketClosed && <p className="notice warn">While the exchange is closed we subtract a gap haircut from your buffer: liquidity is thin and the price can jump at the open.</p>}
        </section>
      </div>

      <section className="card stack">
        <h2 className="h3">Issuer events</h2>
        {p.issuerEvents.length === 0 && <p className="muted small">No issuer or contract events in the last 30 days.</p>}
        <ol className="stack" style={{ listStyle: 'none', padding: 0, margin: 0, gap: 14 }}>
          {p.issuerEvents.map((e) => (
            <li key={e.occurredAt + e.kind} className="spread" style={{ alignItems: 'flex-start' }}>
              <div className="stack" style={{ gap: 2 }}>
                <span><b style={{ fontWeight: 600 }}>{e.asset}</b> · {e.kind.replace('_', ' ')}{e.kind === 'pause' && (e.active ? <span className="c-risk"> · active</span> : <span className="muted"> · resolved</span>)}</span>
                <span className="small muted">{e.description}</span>
              </div>
              <span className="small faint num">{new Date(e.occurredAt).toLocaleDateString()}</span>
            </li>
          ))}
        </ol>
      </section>

      <DataNote at={p.scoredAt} />
    </div>
  );
}
