import Link from 'next/link';
import PageShell from '@/components/PageShell';

export default function NotFound() {
  return (
    <PageShell>
      <div className="container page-head stack" style={{ gap: 20 }}>
        <h1 className="outline-title">404</h1>
        <p className="lead">This page doesn’t exist.</p>
        <Link className="btn" href="/" style={{ width: 'fit-content' }}>Back home</Link>
      </div>
    </PageShell>
  );
}
