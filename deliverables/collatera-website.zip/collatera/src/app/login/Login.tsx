'use client';

import { useSearchParams } from 'next/navigation';
import { useState } from 'react';
import { api } from '@/lib/client/api';

export default function Login() {
  const params = useSearchParams();
  const next = params.get('next') ?? '/dashboard';
  const [email, setEmail] = useState('');
  const [state, setState] = useState<'idle' | 'busy' | 'sent'>('idle');
  const [err, setErr] = useState<string | null>(params.get('error') === 'expired' ? 'That sign-in link has expired or was already used. Request a new one.' : null);
  const [devLink, setDevLink] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setState('busy');
    setErr(null);
    try {
      const r = await api<{ devLink?: string }>('/api/auth/request', { method: 'POST', json: { email, next } });
      setDevLink(r.devLink ?? null);
      setState('sent');
    } catch (e2) {
      setErr((e2 as Error).message);
      setState('idle');
    }
  }

  return (
    <div className="container" style={{ maxWidth: 640 }}>
      <div className="page-head stack" style={{ gap: 14 }}>
        <span className="eyebrow">Account</span>
        <h1 className="display" style={{ fontSize: 'clamp(40px, 6vw, 72px)' }}>Sign in</h1>
        <p className="lead">No password. We email you a one-time link. An account is only needed to save addresses and receive alerts — the dashboard works without one.</p>
      </div>
      {state === 'sent' ? (
        <div className="card stack">
          <h2 className="h3">Check your inbox</h2>
          <p className="muted">We sent a sign-in link to <b style={{ color: '#fff' }}>{email}</b>. It works once and expires in 15 minutes.</p>
          {devLink && (
            <p className="notice warn small">Development mode (no email provider configured): <a className="link" href={devLink}>open the sign-in link</a>.</p>
          )}
        </div>
      ) : (
        <form className="card stack" onSubmit={submit}>
          <label className="field">Email
            <input className="input" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" />
          </label>
          <button className="btn btn-solid" disabled={state === 'busy'}>{state === 'busy' ? 'Sending…' : 'Email me a sign-in link'}</button>
          {err && <p className="notice err" role="alert">{err}</p>}
        </form>
      )}
    </div>
  );
}
