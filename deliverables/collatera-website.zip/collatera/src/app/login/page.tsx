import { Suspense } from 'react';
import PageShell from '@/components/PageShell';
import Login from './Login';

export const metadata = { title: 'Sign in — COLLATERA' };

export default function Page() {
  return (
    <PageShell>
      <Suspense>
        <Login />
      </Suspense>
    </PageShell>
  );
}
