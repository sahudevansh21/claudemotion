'use client';

import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { useEffect, useState } from 'react';
import { formatEther } from 'viem';
import { useAccount, useConnect, useDisconnect, usePublicClient, useSendTransaction, useSwitchChain } from 'wagmi';
import { Badge, DataNote, Skeleton, Stat } from '@/components/ui';
import { api, useApi } from '@/lib/client/api';
import { WalletProviders } from '@/lib/client/wagmi';
import type { Simulation, TxRequest } from '@/lib/chain/types';
import { fmtAmount, fmtHf, fmtUsd, pct } from '@/lib/risk/engine';
import type { ScoredPosition } from '@/lib/risk/types';

interface PlanResponse {
  kind: 'repay' | 'add'; demo: boolean; chainId: number; owner: string; amount: number; symbol: string; usd: number; capped: boolean;
  before: { healthFactor: number; buffer: number }; after: { healthFactor: number; buffer: number };
  txs: TxRequest[]; simulation: Simulation;
}

export default function Planner({ id }: { id: string }) {
  return (
    <WalletProviders>
      <PlannerInner id={id} />
    </WalletProviders>
  );
}

function PlannerInner({ id }: { id: string }) {
  const params = useSearchParams();
  const [targetHf, setTargetHf] = useState(Number(params.get('targetHf')) || 1.5);
  const [kind, setKind] = useState<'repay' | 'add'>('repay');
  const [token, setToken] = useState<string | undefined>();
  const pos = useApi<{ position: ScoredPosition }>(`/api/positions/${encodeURIComponent(id)}`);
  const [plan, setPlan] = useState<PlanResponse | null>(null);
  const [planErr, setPlanErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let live = true;
    setBusy(true);
    const t = window.setTimeout(() => {
      api<PlanResponse>('/api/plan', { method: 'POST', json: { positionId: id, kind, targetHf, token } })
        .then((r) => { if (live) { setPlan(r); setPlanErr(null); } })
        .catch((e) => { if (live) { setPlan(null); setPlanErr((e as Error).message); } })
        .finally(() => live && setBusy(false));
    }, 200);
    return () => { live = false; window.clearTimeout(t); };
  }, [id, kind, targetHf, token]);

  const p = pos.data?.position;

  return (
    <div className="container stack" style={{ gap: 28 }}>
      <div className="page-head">
        <Link href={`/positions/${encodeURIComponent(id)}`} className="link small muted">← Back to position</Link>
        <h1 className="display" style={{ fontSize: 'clamp(40px, 6vw, 84px)', marginTop: 14 }}>Repayment planner</h1>
        <p className="lead">We prepare the exact transactions. You review them and sign in your own wallet. Nothing executes without your confirmation.</p>
      </div>

      {pos.error && <p className="notice err">{pos.error.message}</p>}
      {!p && !pos.error && <Skeleton h={160} />}

      {p && (
        <div className="card stack" style={{ gap: 20 }}>
          <div className="spread">
            <div className="stack" style={{ gap: 2 }}>
              <h2 className="h3">{p.collateral.map((c) => c.symbol).join(' + ')}</h2>
              <span className="small muted">HF {fmtHf(p.healthFactor)} · buffer {pct(Math.max(p.buffer, 0))} · {p.marketName}</span>
            </div>
            <Badge badge={p.badge} />
          </div>
          <div className="grid grid-3">
            <div className="stack" style={{ gap: 10 }}>
              <span className="small muted">Action</span>
              <div className="tabs" role="group" aria-label="Action">
                <button className="tab" aria-pressed={kind === 'repay'} onClick={() => setKind('repay')}>Repay debt</button>
                <button className="tab" aria-pressed={kind === 'add'} onClick={() => setKind('add')}>Add collateral</button>
              </div>
            </div>
            {kind === 'add' && (
              <label className="field">Collateral to add
                <select className="select" value={token ?? p.collateral[0]?.token} onChange={(e) => setToken(e.target.value)}>
                  {p.collateral.map((c) => <option key={c.token} value={c.token}>{c.symbol}</option>)}
                </select>
              </label>
            )}
            <label className="field">Target health factor
              <input className="input" type="number" min={1.05} max={5} step={0.05} value={targetHf}
                onChange={(e) => setTargetHf(Math.min(5, Math.max(1.05, Number(e.target.value) || 1.5)))} />
            </label>
          </div>
        </div>
      )}

      {planErr && <p className="notice warn">{planErr}</p>}
      {busy && !plan && p && <Skeleton h={200} />}

      {plan && (
        <>
          <div className="card stack" style={{ gap: 20, opacity: busy ? 0.6 : 1 }}>
            <h2 className="h3">{plan.kind === 'repay' ? 'Repay' : 'Add'} {fmtAmount(plan.amount, plan.symbol)} <span className="muted" style={{ fontWeight: 400 }}>≈ {fmtUsd(plan.usd)}</span></h2>
            {plan.capped && <p className="notice warn">Repaying all of this debt asset still does not reach HF {targetHf}. Consider adding collateral as well.</p>}
            <div className="grid grid-4">
              <Stat label="Health factor" value={<>{fmtHf(plan.before.healthFactor)} → <span className="c-safe">{fmtHf(plan.after.healthFactor)}</span></>} />
              <Stat label="Buffer" value={<>{pct(Math.max(plan.before.buffer, 0), 0)} → <span className="c-safe">{pct(Math.max(plan.after.buffer, 0), 0)}</span></>} />
              <Stat label="Approvals" value={plan.simulation.allowance != null && plan.simulation.allowance >= plan.amount ? 'None' : '1 token'} sub={`${plan.symbol} → lending pool`} />
              <Stat label="Simulation" value={plan.simulation.ok ? 'Passed' : 'Check'} tone={plan.simulation.ok ? 'safe' : 'watch'} />
            </div>
            <p className={`notice ${plan.simulation.ok ? 'ok' : 'warn'}`}>{plan.simulation.message}{plan.simulation.balance != null ? ` Wallet balance: ${fmtAmount(plan.simulation.balance, plan.symbol)}.` : ''}</p>
          </div>

          <div className="card stack" style={{ gap: 18 }}>
            <h2 className="h3">Exact transactions</h2>
            {plan.txs.map((t, i) => (
              <details key={i} className="stack" open={i === plan.txs.length - 1}>
                <summary style={{ cursor: 'pointer' }}><b style={{ fontWeight: 600 }}>{i + 1}. {t.description}</b></summary>
                <dl className="kv" style={{ marginTop: 12 }}>
                  <dt>To</dt><dd style={{ wordBreak: 'break-all' }}>{t.to}</dd>
                  <dt>Function</dt><dd>{t.functionName}({t.args.join(', ')})</dd>
                  <dt>Value</dt><dd>{t.value} ETH</dd>
                </dl>
                <pre style={{ marginTop: 10 }}>{t.data}</pre>
              </details>
            ))}
          </div>

          <SignPanel plan={plan} onDone={() => { void pos.reload(); setTargetHf((x) => x); }} />
        </>
      )}
      <DataNote at={p?.scoredAt} />
    </div>
  );
}

function SignPanel({ plan, onDone }: { plan: PlanResponse; onDone: () => void }) {
  const { address, chainId, isConnected } = useAccount();
  const { connect, connectors, isPending: connecting, error: connectErr } = useConnect();
  const { disconnect } = useDisconnect();
  const { switchChainAsync } = useSwitchChain();
  const { sendTransactionAsync } = useSendTransaction();
  const client = usePublicClient({ chainId: plan.chainId || undefined });
  const [status, setStatus] = useState<string[]>([]);
  const [running, setRunning] = useState(false);
  const [fee, setFee] = useState<string | null>(null);
  const [confirmed, setConfirmed] = useState(false);

  const ownerMatches = !!address && address.toLowerCase() === plan.owner.toLowerCase();
  const skipApprove = plan.simulation.allowance != null && plan.simulation.allowance >= plan.amount;
  const txs = skipApprove ? plan.txs.slice(1) : plan.txs;

  useEffect(() => {
    setFee(null);
    if (!client || !ownerMatches || plan.demo) return;
    (async () => {
      try {
        const [gas, price] = await Promise.all([
          client.estimateGas({ account: address!, to: txs[0].to, data: txs[0].data }),
          client.getGasPrice(),
        ]);
        // The second step usually costs ~2-3× an approve; show a conservative total.
        const total = gas * price * (txs.length > 1 ? 4n : 1n);
        setFee(`~${Number(formatEther(total)).toFixed(5)} ETH (network fee estimate)`);
      } catch {
        setFee('Your wallet will show the exact network fee.');
      }
    })();
  }, [client, ownerMatches, plan, address, txs]);

  async function run() {
    setRunning(true);
    setStatus([]);
    try {
      if (plan.chainId && chainId !== plan.chainId) {
        setStatus((s) => [...s, 'Switching network…']);
        await switchChainAsync({ chainId: plan.chainId });
      }
      for (const t of txs) {
        setStatus((s) => [...s, `Waiting for your signature: ${t.description}`]);
        const hash = await sendTransactionAsync({ to: t.to, data: t.data, value: 0n, chainId: plan.chainId });
        setStatus((s) => [...s, `Submitted ${hash.slice(0, 10)}… waiting for confirmation`]);
        const receipt = await client!.waitForTransactionReceipt({ hash });
        if (receipt.status !== 'success') throw new Error(`Transaction ${hash} reverted.`);
        setStatus((s) => [...s, `Confirmed in block ${receipt.blockNumber}.`]);
      }
      setStatus((s) => [...s, 'Done. Re-scoring your position…']);
      onDone();
    } catch (e) {
      setStatus((s) => [...s, `Stopped: ${(e as Error).message.split('\n')[0]}`]);
    } finally {
      setRunning(false);
    }
  }

  if (plan.demo) {
    return <div className="card"><p className="notice">This is the demo wallet — transactions are illustrative and cannot be signed. Open your own address to plan a real repayment.</p></div>;
  }

  return (
    <div className="card stack" style={{ gap: 16 }}>
      <h2 className="h3">Sign in your wallet</h2>
      {!isConnected ? (
        <div className="row">
          {connectors.map((c) => (
            <button key={c.uid} className="btn btn-solid" disabled={connecting} onClick={() => connect({ connector: c })}>
              {connecting ? 'Connecting…' : `Connect ${c.name === 'Injected' ? 'browser wallet' : c.name}`}
            </button>
          ))}
          {connectErr && <p className="notice err">{connectErr.message.includes('Provider not found') ? 'No browser wallet found. Install MetaMask, Rabby or similar.' : connectErr.message}</p>}
        </div>
      ) : (
        <>
          <div className="spread small">
            <span>Connected: <span className="num">{address}</span></span>
            <button className="link" style={{ background: 'none', border: 0, cursor: 'pointer', padding: 0 }} onClick={() => disconnect()}>Disconnect</button>
          </div>
          {!ownerMatches && <p className="notice err">This wallet is not the position owner ({plan.owner}). Connect the owner wallet to continue.</p>}
          {ownerMatches && (
            <>
              {fee && <p className="small muted">{fee}</p>}
              <label className="check small"><input type="checkbox" checked={confirmed} onChange={(e) => setConfirmed(e.target.checked)} />
                I reviewed the transactions above. I understand COLLATERA only prepares them and that market prices can change before they confirm.</label>
              <div className="row">
                <button className="btn btn-solid" disabled={!confirmed || running} onClick={run}>
                  {running ? 'Working…' : `Sign ${txs.length} transaction${txs.length > 1 ? 's' : ''}`}
                </button>
              </div>
            </>
          )}
        </>
      )}
      {status.length > 0 && <ol className="small muted" style={{ margin: 0, paddingLeft: 18 }}>{status.map((s, i) => <li key={i}>{s}</li>)}</ol>}
    </div>
  );
}
