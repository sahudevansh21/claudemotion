import { Suspense } from 'react';
import PageShell from '@/components/PageShell';
import Planner from './Planner';

export const metadata = { title: 'Repayment planner — COLLATERA' };

export default function Page({ params }: { params: { id: string } }) {
  return (
    <PageShell>
      <Suspense>
        <Planner id={decodeURIComponent(params.id)} />
      </Suspense>
    </PageShell>
  );
}
