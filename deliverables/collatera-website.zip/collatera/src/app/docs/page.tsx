import PageShell from '@/components/PageShell';
import { registry } from '@/config/assets';
import { DEFAULTS } from '@/lib/risk/engine';
import { EXCHANGE_NAMES } from '@/lib/risk/calendar';
import { env } from '@/lib/server/env';

export const metadata = { title: 'Docs & risk notes — COLLATERA' };
export const dynamic = 'force-dynamic';

const TOC = [
  ['getting-started', 'Getting started'],
  ['risk-score', 'How the risk score works'],
  ['freshness', 'Price freshness'],
  ['market-hours', 'Market hours'],
  ['issuer-events', 'Issuer events'],
  ['stress', 'Stress tests'],
  ['planner', 'Repayment planner safety'],
  ['supported', 'Supported market & assets'],
  ['limits', 'Risk notes & honest limits'],
  ['faq', 'FAQ'],
  ['roadmap', 'Roadmap'],
];

export default function Docs() {
  const e = env();
  const p = (x: number) => `${Math.round(x * 100)}%`;
  return (
    <PageShell>
      <div className="container">
        <div className="page-head">
          <span className="eyebrow">Docs</span>
          <h1 className="outline-title" style={{ marginTop: 12 }}>Docs</h1>
          <p className="lead">How COLLATERA scores a position, what each signal means, and what it cannot do.</p>
        </div>
        <div className="docs-layout">
          <nav className="docs-toc" aria-label="Docs sections">{TOC.map(([id, t]) => <a key={id} href={`#${id}`}>{t}</a>)}</nav>
          <article className="prose">
            <h2 id="getting-started" style={{ marginTop: 0 }}>Getting started</h2>
            <p>Paste a wallet address on the home page or dashboard. COLLATERA scans the supported lending market for that address and shows every open position with a <b>Safe</b>, <b>Watch</b> or <b>At Risk</b> badge. No wallet connection is needed to look.</p>
            <p>To receive alerts, sign in with your email (magic link, no password), save the address, and choose channels on the Alerts page. A wallet is only connected later, in the repayment planner, to sign a transaction you have reviewed.</p>

            <h2 id="risk-score">How the risk score works</h2>
            <h3>Health factor</h3>
            <pre>HF = Σ(collateral amount × oracle price × liquidation threshold) ÷ debt value</pre>
            <p>Liquidation becomes possible when HF falls to 1.0. With no debt, HF is infinite and the position cannot be liquidated.</p>
            <h3>Buffer to liquidation</h3>
            <pre>buffer = 1 − 1 ÷ HF</pre>
            <p>The share by which all collateral prices can fall (debt held constant) before HF hits 1.0. A health factor of 1.25 is a 20% buffer; 2.0 is 50%.</p>
            <h3>Liquidation price</h3>
            <pre>p* = (debt − weighted value of other collateral) ÷ (amount × liquidation threshold)</pre>
            <h3>Badges</h3>
            <ul>
              <li><b>At Risk</b> — HF below {DEFAULTS.riskHf}, effective buffer below {p(DEFAULTS.riskBuffer)}, or an issuer pause in force.</li>
              <li><b>Watch</b> — effective buffer below {p(DEFAULTS.watchBuffer)}, a stale or critical price feed, an issuer event in the last {DEFAULTS.issuerEventFreshHours} hours, or the market closes within {DEFAULTS.closingSoonMin} minutes while the buffer is under {p(DEFAULTS.closingSoonBuffer)}.</li>
              <li><b>Safe</b> — none of the above.</li>
            </ul>

            <h2 id="freshness">Price freshness</h2>
            <p>Each tokenized asset has an expected oracle update interval (heartbeat). We compare the feed’s last update time with it:</p>
            <ul>
              <li><b>Fresh</b> — age ≤ {DEFAULTS.staleTolerance}× the interval.</li>
              <li><b>Stale</b> — older than that.</li>
              <li><b>Critical</b> — older than {DEFAULTS.criticalMultiple}× the interval, or the feed call failed.</li>
            </ul>
            <p>A stale feed means the on-chain price may not match the real market. Your true buffer could be smaller than displayed.</p>

            <h2 id="market-hours">Market hours</h2>
            <p>Tokenized stocks track shares listed on {Object.values(EXCHANGE_NAMES).join(' and ')}: regular hours 09:30–16:00 New York time, 13:00 on early-close days, closed on weekends and exchange holidays. While the underlying is closed, liquidity is thin and prices can gap at the open, so we subtract a gap haircut (default {p(DEFAULTS.gapHaircut)}, configurable per asset) from your buffer, weighted by how much of your collateral is affected. That is the <b>effective buffer</b>.</p>

            <h2 id="issuer-events">Issuer events</h2>
            <p>The worker watches issuer token contracts for <code>Paused</code>/<code>Unpaused</code> events. Corporate actions (splits, distributions, delistings), redemption-window and allowlist changes are logged by the COLLATERA team with a source link. An active pause marks the position At Risk; other recent events mark it Watch.</p>

            <h2 id="stress">Stress tests</h2>
            <p>Scenarios shock the price of tokenized collateral only (stablecoin collateral and debt are held constant):</p>
            <pre>HF′ = (Σ tokenized × price × (1 − d) × LT + Σ other × price × LT) ÷ debt</pre>
            <ul>
              <li><b>−10% / −20% / custom</b> — an immediate fall.</li>
              <li><b>Overnight gap-down</b> — the underlying opens lower; the tokenized price jumps with no chance to react.</li>
              <li><b>Oracle delay</b> — the real price moves while the oracle is stale. On-chain HF looks unchanged until the update lands, then drops at once.</li>
            </ul>
            <h3>Amount to reach a target HF (default {DEFAULTS.targetHf})</h3>
            <pre>{`repay      = max(0, debt − weighted collateral ÷ target)
add (asset a) = max(0, (target × debt − weighted collateral) ÷ (price_a × LT_a))`}</pre>
            <p>Amounts are rounded up so you land at or above the target.</p>

            <h2 id="planner">Repayment planner safety</h2>
            <ul>
              <li>COLLATERA’s servers have no signing keys and cannot move funds.</li>
              <li>The planner builds standard <code>approve</code> + <code>repay</code> / <code>supply</code> calls on the lending pool and shows the decoded arguments and raw calldata.</li>
              <li>We simulate with <code>eth_call</code> from your address and check balance and allowance first.</li>
              <li>The connected wallet must be the position owner. You sign each step yourself.</li>
            </ul>

            <h2 id="supported">Supported market &amp; assets</h2>
            <p>This deployment is configured for: <b>{e.MARKET_MODE === 'demo' ? 'Demo market (sample data)' : e.AAVE_MARKET_NAME}</b>{e.MARKET_MODE === 'aave' ? `, chain id ${e.CHAIN_ID}` : ''}.</p>
            <ul>
              {registry().map((a) => <li key={a.symbol}><b>{a.symbol}</b> — {a.name} ({a.underlying}, {EXCHANGE_NAMES[a.exchange]}), oracle every {Math.round(a.heartbeatSec / 60)} min, gap haircut {p(a.gapHaircut ?? DEFAULTS.gapHaircut)}</li>)}
            </ul>
            <p>Positions whose collateral is not on this list are shown as “unsupported collateral” — we still compute the health factor, but skip freshness and market-hours checks.</p>

            <h2 id="limits">Risk notes &amp; honest limits</h2>
            <ul>
              <li>Version one covers <b>one lending market</b>, in <b>read-only</b> mode.</li>
              <li>Data can lag or fail: RPC providers, oracles and our worker can all be delayed. Every page shows when its data was read.</li>
              <li>COLLATERA improves risk awareness. It <b>does not guarantee protection from liquidation</b>.</li>
              <li>Liquidation thresholds and oracle sources are read from the protocol and can be changed by its governance at any time.</li>
              <li>Nothing here is financial, legal or tax advice.</li>
            </ul>

            <h2 id="faq">FAQ</h2>
            <h3>Do you need my private key?</h3><p>Never. Only a public address. If you paste something that looks like a key or seed phrase, we refuse it.</p>
            <h3>Why does my effective buffer differ from the protocol’s?</h3><p>When the underlying exchange is closed we deliberately treat your buffer as smaller, because tokenized shares can gap at the open.</p>
            <h3>How often do you check?</h3><p>Every hour on Free, every minute on Pro and Team. The dashboard refreshes every 30 seconds while open.</p>

            <h2 id="roadmap">Roadmap</h2>
            <ul>
              <li><b>Now:</b> read-only monitoring, alerts, stress tests and user-signed plans on one market.</li>
              <li><b>Next:</b> more lending markets via the adapter interface; webhooks for B2B.</li>
              <li><b>Later (proposal):</b> bonded independent operators executing jobs users pre-authorize with strict limits (maximum amount, allowed actions, expiry), earning service fees. Requires funding, legal review and independent security audits first.</li>
              <li><b>Token (proposal only):</b> considered only after paid usage and a demonstrated network need. Stablecoin bonds will be compared first, since they avoid price-volatility problems. Tokens do not guarantee returns or a market cap.</li>
            </ul>
          </article>
        </div>
      </div>
    </PageShell>
  );
}
