'use client';

import { useState } from 'react';
import { api, useApi, type Me } from '@/lib/client/api';

interface Ev { id: string; asset: string; kind: string; description: string; active: boolean; occurredAt: string; sourceUrl: string | null }

export default function Admin() {
  const me = useApi<Me>('/api/me');
  const list = useApi<{ events: Ev[] }>('/api/admin/issuer-events');
  const [form, setForm] = useState({ asset: '', kind: 'corporate_action', description: '', sourceUrl: '' });
  const [msg, setMsg] = useState<string | null>(null);

  if (me.data && !me.data.user?.admin) return <div className="container page-head"><p className="notice err">Admins only. Add your email to ADMIN_EMAILS.</p></div>;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api('/api/admin/issuer-events', { method: 'POST', json: { ...form, sourceUrl: form.sourceUrl || undefined } });
      setForm({ asset: '', kind: 'corporate_action', description: '', sourceUrl: '' });
      setMsg('Event logged. Positions holding this asset will show it and alerts will fire on the next scan.');
      await list.reload();
    } catch (err) { setMsg((err as Error).message); }
  }

  return (
    <div className="container stack" style={{ gap: 28 }}>
      <div className="page-head">
        <span className="eyebrow">Admin</span>
        <h1 className="h2" style={{ marginTop: 8 }}>Issuer events</h1>
        <p className="lead">Log off-chain corporate actions (splits, distributions, delistings, redemption changes). On-chain Paused/Unpaused events are ingested automatically by the worker.</p>
      </div>
      {msg && <p className="notice">{msg}</p>}
      <form className="card grid grid-2" onSubmit={submit}>
        <label className="field">Asset symbol<input className="input" required value={form.asset} onChange={(e) => setForm({ ...form, asset: e.target.value })} placeholder="TSLAx" /></label>
        <label className="field">Kind
          <select className="select" value={form.kind} onChange={(e) => setForm({ ...form, kind: e.target.value })}>
            {['corporate_action', 'redemption', 'allowlist', 'pause', 'unpause', 'other'].map((k) => <option key={k} value={k}>{k.replace('_', ' ')}</option>)}
          </select>
        </label>
        <label className="field" style={{ gridColumn: '1 / -1' }}>Description<textarea className="textarea" required minLength={5} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></label>
        <label className="field">Source URL<input className="input" type="url" value={form.sourceUrl} onChange={(e) => setForm({ ...form, sourceUrl: e.target.value })} /></label>
        <div className="row" style={{ alignItems: 'flex-end' }}><button className="btn btn-solid">Log event</button></div>
      </form>
      <div className="card table-wrap">
        <table className="table">
          <thead><tr><th>When</th><th>Asset</th><th>Kind</th><th>Description</th><th>Active</th></tr></thead>
          <tbody>
            {list.data?.events.map((e) => (
              <tr key={e.id}>
                <td className="small">{new Date(e.occurredAt).toLocaleString()}</td>
                <td>{e.asset}</td>
                <td>{e.kind}</td>
                <td className="small">{e.description}{e.sourceUrl && <> · <a className="link" href={e.sourceUrl} target="_blank" rel="noreferrer">source</a></>}</td>
                <td><label className="check"><input type="checkbox" checked={e.active} onChange={async (x) => { await api('/api/admin/issuer-events', { method: 'PATCH', json: { id: e.id, active: x.target.checked } }); await list.reload(); }} /></label></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
