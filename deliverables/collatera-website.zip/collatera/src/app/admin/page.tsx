import PageShell from '@/components/PageShell';
import Admin from './Admin';

export const metadata = { title: 'Admin — COLLATERA' };

export default function Page() {
  return (
    <PageShell>
      <Admin />
    </PageShell>
  );
}
