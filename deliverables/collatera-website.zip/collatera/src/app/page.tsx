import Link from 'next/link';
import GlassHero from '@/components/hero/GlassHero';
import SiteFooter from '@/components/SiteFooter';
import WalletCheck from '@/components/WalletCheck';
import { BufferMock, FeedMock, StressMock } from '@/components/LandingMocks';

const STEPS = [
  ['Connect', 'Paste a wallet address. View-only — no keys, no funds.'],
  ['Detect', 'We scan the supported lending market for open positions.'],
  ['Fetch', 'Collateral, debt, liquidation thresholds and oracle prices, read on-chain.'],
  ['Score', 'Health factor, buffer, price freshness, market hours, issuer events.'],
  ['Display', 'Each position with a plain-language explanation and a badge.'],
  ['Monitor', 'A background worker re-checks and alerts you by email, Telegram or push.'],
  ['Act', 'Preview a repayment and sign it in your own wallet. Nothing runs without you.'],
];

export default function Home() {
  return (
    <div className="page">
      <GlassHero />
      <main id="main">
        <section id="check" className="section" style={{ borderTop: 0 }}>
          <div className="container stack" style={{ gap: 28 }}>
            <span className="eyebrow">Check a wallet</span>
            <h2 className="h2" style={{ maxWidth: 900 }}>See how far your tokenized-stock collateral can fall before liquidation.</h2>
            <WalletCheck />
          </div>
        </section>

        <section className="section">
          <div className="container stack" style={{ gap: 40 }}>
            <div className="stack">
              <span className="eyebrow">Why it matters</span>
              <h2 className="h2">Tokenized stocks don’t behave like ETH.</h2>
            </div>
            <div className="grid grid-3">
              <article className="card stack">
                <h3 className="h3">Thin buffers</h3>
                <p className="muted">A health factor of 1.25 means only a 20% fall stands between you and a liquidation penalty.</p>
              </article>
              <article className="card stack">
                <h3 className="h3">Stale prices</h3>
                <p className="muted">When an oracle lags the real stock, the on-chain number looks safer than your position really is.</p>
              </article>
              <article className="card stack">
                <h3 className="h3">Closed markets &amp; issuer events</h3>
                <p className="muted">Nights, weekends and holidays mean thin liquidity and gaps at the open. Issuers can pause or change redemptions.</p>
              </article>
            </div>
          </div>
        </section>

        <section className="section">
          <div className="container stack" style={{ gap: 48 }}>
            <div className="stack">
              <span className="eyebrow">How it works</span>
              <h2 className="h2">Seven steps. You stay in control of every one.</h2>
            </div>
            <ol className="steps" style={{ listStyle: 'none', padding: 0, margin: 0 }}>
              {STEPS.map(([t, d], i) => (
                <li className="step" key={t}>
                  <span className="n" aria-hidden="true">{String(i + 1).padStart(2, '0')}</span>
                  <h3>{t}</h3>
                  <p>{d}</p>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section className="section">
          <div className="container stack" style={{ gap: 40 }}>
            <div className="stack">
              <span className="eyebrow">Features</span>
              <h2 className="h2">Everything you need to act before the market does.</h2>
            </div>
            <div className="grid grid-3">
              <article className="card stack" style={{ gap: 18 }}>
                <h3 className="h3">Position dashboard</h3>
                <p className="muted small">Every position with a Safe / Watch / At Risk badge and its buffer to liquidation.</p>
                <BufferMock />
              </article>
              <article className="card stack" style={{ gap: 18 }}>
                <h3 className="h3">Price-freshness checks</h3>
                <p className="muted small">Oracle age versus its expected interval, flagged the moment it slips.</p>
                <FeedMock />
              </article>
              <article className="card stack" style={{ gap: 18 }}>
                <h3 className="h3">Stress scenarios</h3>
                <p className="muted small">−10%, −20%, overnight gap-downs and oracle delays — with the amount to repay to stay safe.</p>
                <StressMock />
              </article>
              <article className="card stack" style={{ gap: 18 }}>
                <h3 className="h3">Alerts that explain</h3>
                <p className="muted small">Email, Telegram and push. Each alert says what changed, why it matters and what to do.</p>
                <p className="notice warn small">SPYx position: buffer down to 8% — NYSE closed until Mon 09:30 ET.</p>
              </article>
              <article className="card stack" style={{ gap: 18 }}>
                <h3 className="h3">Repayment planner</h3>
                <p className="muted small">“Repay 820 USDC to restore a 1.5 health factor.” Before/after, fees and the exact transaction.</p>
                <p className="small"><span className="c-safe">You sign.</span> <span className="muted">Nothing executes without your confirmation.</span></p>
              </article>
              <article className="card stack" style={{ gap: 18 }}>
                <h3 className="h3">Market-hours aware</h3>
                <p className="muted small">When the underlying exchange is shut, COLLATERA applies a more cautious buffer automatically.</p>
              </article>
            </div>
          </div>
        </section>

        <section className="section">
          <div className="container grid grid-2" style={{ alignItems: 'center' }}>
            <div className="stack">
              <span className="eyebrow">Who it’s for</span>
              <h2 className="h2">Borrowers, lending platforms, DAOs and treasuries.</h2>
              <p className="lead">Individuals watch their own loans. Teams monitor many addresses through the API and webhooks.</p>
            </div>
            <div className="row" style={{ justifyContent: 'flex-end' }}>
              <Link href="/pricing" className="btn">See pricing</Link>
              <Link href={`/dashboard`} className="btn btn-solid">Open dashboard</Link>
            </div>
          </div>
        </section>

        <section className="section" id="limits">
          <div className="container stack" style={{ gap: 28 }}>
            <span className="eyebrow">Honest limits</span>
            <h2 className="h2">What COLLATERA does not do.</h2>
            <div className="grid grid-2">
              <ul className="list-check card">
                <li>Version one covers one lending market, in read-only mode.</li>
                <li>COLLATERA never holds funds or keys and never executes anything for you.</li>
                <li>Data can lag or fail. We improve risk awareness; we do not guarantee protection from liquidation.</li>
              </ul>
              <ul className="list-check card">
                <li>Automation (bonded operators running jobs you pre-authorize) is a later phase that needs funding, legal review and independent audits.</li>
                <li>Any token role is a proposal only. Tokens do not guarantee returns or a market cap.</li>
                <li>Nothing here is financial advice.</li>
              </ul>
            </div>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  );
}
