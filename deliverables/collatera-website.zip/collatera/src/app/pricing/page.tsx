import Link from 'next/link';
import PageShell from '@/components/PageShell';
import ContactForm from './ContactForm';

export const metadata = { title: 'Pricing — COLLATERA' };

const PLANS = [
  { name: 'Free', price: '$0', per: '', cta: { href: '/dashboard', label: 'Open dashboard' }, items: ['1 saved address', 'Dashboard, detail and stress tests', 'Email alerts', 'Re-checked every hour'] },
  { name: 'Pro', price: '$19', per: '/month', highlight: true, cta: { href: '/account', label: 'Upgrade' }, items: ['10 saved addresses', 'Email, Telegram and push alerts', 'Re-checked every minute', '7-day snapshot history', 'API key access'] },
  { name: 'Team', price: 'Custom', per: '', cta: { href: '#contact', label: 'Talk to us' }, items: ['Hundreds of addresses', 'B2B API + webhooks', 'For lending platforms, DAOs and treasuries', 'Shared alert routing', 'Priority support'] },
];

export default function Pricing() {
  return (
    <PageShell>
      <div className="container stack" style={{ gap: 40 }}>
        <div className="page-head">
          <span className="eyebrow">Pricing &amp; B2B</span>
          <h1 className="outline-title" style={{ marginTop: 12 }}>Pricing</h1>
          <p className="lead">Monitoring subscriptions for individuals, accounts for platforms and treasuries. Prices are placeholders while COLLATERA is in early access.</p>
        </div>
        <div className="grid grid-3">
          {PLANS.map((p) => (
            <article key={p.name} className={`card stack ${p.highlight ? 'card-hi' : ''}`} style={{ gap: 20, borderColor: p.highlight ? 'rgba(255,255,255,.5)' : undefined }}>
              <div className="spread"><h2 className="h3">{p.name}</h2>{p.highlight && <span className="chip">Most popular</span>}</div>
              <div className="price">{p.price}<small>{p.per}</small></div>
              <ul className="list-check">{p.items.map((i) => <li key={i}>{i}</li>)}</ul>
              <Link href={p.cta.href} className={`btn ${p.highlight ? 'btn-solid' : ''}`} style={{ marginTop: 'auto' }}>{p.cta.label}</Link>
            </article>
          ))}
        </div>
        <article className="card stack" style={{ borderStyle: 'dashed' }}>
          <div className="spread"><h2 className="h3">Automation</h2><span className="chip">Not available — roadmap</span></div>
          <p className="muted">A later phase may let bonded independent operators run jobs you pre-authorize — with a maximum amount, allowed actions and an expiry — for a service fee. It needs funding, legal review and independent security audits first. Today, COLLATERA never executes anything for you.</p>
        </article>
        <section id="contact" className="grid grid-2" style={{ alignItems: 'start', scrollMarginTop: 100 }}>
          <div className="stack">
            <span className="eyebrow">B2B</span>
            <h2 className="h2">Run a lending market, DAO or treasury?</h2>
            <p className="lead">Monitor every borrower or vault address, pipe alerts into your own systems, and show users plain-language risk.</p>
          </div>
          <ContactForm />
        </section>
      </div>
    </PageShell>
  );
}
