'use client';

import { useState } from 'react';
import { api } from '@/lib/client/api';

export default function ContactForm() {
  const [f, setF] = useState({ name: '', email: '', company: '', message: '' });
  const [state, setState] = useState<'idle' | 'busy' | 'done'>('idle');
  const [err, setErr] = useState<string | null>(null);

  if (state === 'done') return <div className="card"><p className="c-safe">Thanks — we’ll reply within two business days.</p></div>;

  return (
    <form className="card stack" onSubmit={async (e) => {
      e.preventDefault();
      setState('busy');
      try { await api('/api/contact', { method: 'POST', json: { ...f, company: f.company || undefined } }); setState('done'); }
      catch (e2) { setErr((e2 as Error).message); setState('idle'); }
    }}>
      <div className="grid grid-2" style={{ gap: 14 }}>
        <label className="field">Name<input className="input" required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></label>
        <label className="field">Work email<input className="input" type="email" required value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></label>
      </div>
      <label className="field">Company / DAO<input className="input" value={f.company} onChange={(e) => setF({ ...f, company: e.target.value })} /></label>
      <label className="field">What do you need to monitor?<textarea className="textarea" required minLength={10} value={f.message} onChange={(e) => setF({ ...f, message: e.target.value })} /></label>
      <button className="btn btn-solid" disabled={state === 'busy'}>{state === 'busy' ? 'Sending…' : 'Send'}</button>
      {err && <p className="notice err">{err}</p>}
    </form>
  );
}
