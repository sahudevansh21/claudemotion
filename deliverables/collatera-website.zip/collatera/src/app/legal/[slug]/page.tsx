import { notFound } from 'next/navigation';
import PageShell from '@/components/PageShell';

const PAGES: Record<string, { title: string; body: string[] }> = {
  terms: {
    title: 'Terms of use',
    body: [
      'COLLATERA provides read-only information about DeFi lending positions. It does not hold funds, custody keys, or execute transactions on your behalf.',
      'Information is provided “as is”. Data from blockchains, oracles and third-party providers can be delayed, incomplete or wrong.',
      'You are solely responsible for any transaction you sign, including those prepared by the repayment planner.',
    ],
  },
  privacy: {
    title: 'Privacy',
    body: [
      'We store your email address, the public wallet addresses you save, your alert settings, and alert history. Wallet addresses are public blockchain data.',
      'We use your email and optional Telegram chat or push subscription only to send alerts and sign-in links. We do not sell personal data.',
      'You can delete your account and all associated data at any time from the Account page.',
    ],
  },
  risk: {
    title: 'Risk disclosure',
    body: [
      'Borrowing against tokenized stocks and ETFs carries the risk of liquidation, which sells collateral at a penalty.',
      'Tokenized assets can trade thinly or gap when the underlying exchange is closed. Issuers can pause contracts or change redemption terms.',
      'COLLATERA improves risk awareness but does not guarantee protection from liquidation. Nothing on this site is financial advice.',
    ],
  },
};

export function generateStaticParams() {
  return Object.keys(PAGES).map((slug) => ({ slug }));
}

export default function Legal({ params }: { params: { slug: string } }) {
  const page = PAGES[params.slug];
  if (!page) notFound();
  return (
    <PageShell>
      <div className="container prose">
        <div className="page-head">
          <span className="eyebrow">Legal</span>
          <h1 className="h2" style={{ marginTop: 8 }}>{page.title}</h1>
        </div>
        <p className="notice warn">Placeholder text — requires legal review before launch.</p>
        {page.body.map((b) => <p key={b} style={{ marginTop: 16 }}>{b}</p>)}
      </div>
    </PageShell>
  );
}
