import Link from 'next/link';
import { fmtHf, fmtUsd } from '@/lib/risk/engine';
import type { ScoredPosition } from '@/lib/risk/types';
import { Badge, BufferBar, FeedChip } from './ui';

export default function PositionCard({ p }: { p: ScoredPosition }) {
  const id = encodeURIComponent(p.id);
  const noDebt = p.debtUsd <= 0;
  const supported = p.collateral.some((c) => c.tokenized);
  return (
    <article className="card stack" style={{ gap: 18 }}>
      <div className="spread">
        <div className="stack" style={{ gap: 2 }}>
          <h3 className="h3">{p.collateral.map((c) => c.symbol).join(' + ') || 'No collateral'}</h3>
          <span className="small muted">{p.marketName} · debt in {p.debt.map((d) => d.symbol).join(', ') || '—'}</span>
        </div>
        <Badge badge={p.badge} />
      </div>

      <div className="grid grid-4" style={{ gap: 14 }}>
        <div className="stat"><span className="label">Collateral</span><span className="num" style={{ fontSize: 20, fontWeight: 600 }}>{fmtUsd(p.collateralUsd)}</span></div>
        <div className="stat"><span className="label">Debt</span><span className="num" style={{ fontSize: 20, fontWeight: 600 }}>{fmtUsd(p.debtUsd)}</span></div>
        <div className="stat"><span className="label">Health factor</span><span className={`num c-${p.badge}`} style={{ fontSize: 20, fontWeight: 600 }}>{noDebt ? '∞' : fmtHf(p.healthFactor)}</span></div>
        <div className="stat"><span className="label">Liq. price</span><span className="num" style={{ fontSize: 20, fontWeight: 600 }}>
          {(() => { const m = p.collateral.find((c) => c.tokenized); const lp = m ? p.liquidationPrices[m.symbol] : null; return lp ? fmtUsd(lp) : '—'; })()}
        </span></div>
      </div>

      {!noDebt && <BufferBar buffer={p.buffer} effective={p.effectiveBuffer} />}

      <div className="row" style={{ gap: 8 }}>
        {p.feeds.map((f) => <FeedChip key={f.symbol} state={f.state} ageSec={f.ageSec} />)}
        {p.markets.map((m) => <span key={m.exchange} className="chip">{m.open ? `${m.name} open` : `${m.name} closed`}</span>)}
        {p.issuerEvents.slice(0, 1).map((e) => <span key={e.occurredAt} className={`chip ${e.kind === 'pause' && e.active ? 'critical' : 'stale'}`}>Issuer: {e.kind.replace('_', ' ')}{e.kind === 'pause' && !e.active ? ' (resolved)' : ''}</span>)}
        {!supported && <span className="chip">Unsupported collateral</span>}
      </div>

      <p style={{ fontSize: 15 }}>{p.explanation.headline}</p>
      {p.reasons.length > 0 && <p className="small muted">{p.reasons.join(' · ')}</p>}

      <div className="row">
        <Link className="btn btn-sm" href={`/positions/${id}`}>Details</Link>
        <Link className="btn btn-sm btn-ghost" href={`/stress?position=${id}`}>Stress test</Link>
        {!noDebt && <Link className="btn btn-sm btn-ghost" href={`/plan/${id}`}>Plan repayment</Link>}
      </div>
    </article>
  );
}
