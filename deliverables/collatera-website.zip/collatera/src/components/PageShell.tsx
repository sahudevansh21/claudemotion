import SiteFooter from './SiteFooter';
import SiteHeader from './SiteHeader';

export default function PageShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="page">
      <SiteHeader />
      <main id="main">{children}</main>
      <SiteFooter />
    </div>
  );
}
