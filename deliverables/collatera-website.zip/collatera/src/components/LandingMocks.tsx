'use client';

import { useEffect, useState } from 'react';
import { BufferBar } from './ui';

function useTick(ms = 1000) {
  const [t, setT] = useState(0);
  useEffect(() => {
    const id = window.setInterval(() => setT((x) => x + 1), ms);
    return () => window.clearInterval(id);
  }, [ms]);
  return t;
}

export function BufferMock() {
  const t = useTick(1200);
  const b = 0.22 + 0.06 * Math.sin(t / 3);
  return <BufferBar buffer={b} threshold={0.15} />;
}

export function FeedMock() {
  const t = useTick(1000);
  const rows = [
    { s: 'TSLAx', age: 312 + t, hb: 3600 },
    { s: 'SPYx', age: 1210 + t, hb: 3600 },
    { s: 'NVDAx', age: 4020 + t, hb: 3600 },
  ];
  return (
    <div className="mini-feed stack" style={{ gap: 6 }}>
      {rows.map((r) => {
        const state = r.age > r.hb * 2 ? 'critical' : r.age > r.hb * 1.1 ? 'stale' : 'fresh';
        return (
          <div key={r.s} className="spread">
            <span>{r.s}</span>
            <span className={`c-${state === 'fresh' ? 'safe' : state === 'stale' ? 'watch' : 'risk'}`}>{Math.floor(r.age / 60)}m {String(r.age % 60).padStart(2, '0')}s · {state}</span>
          </div>
        );
      })}
    </div>
  );
}

export function StressMock() {
  const rows = [['−10%', 1.38, 'safe'], ['−20%', 1.23, 'watch'], ['Gap −8%', 1.41, 'safe'], ['−30%', 1.07, 'risk']] as const;
  return (
    <div className="stack" style={{ gap: 6 }}>
      {rows.map(([l, hf, b]) => (
        <div key={l} className="spread small num"><span className="muted">{l}</span><span className={`c-${b}`}>HF {hf.toFixed(2)}</span></div>
      ))}
    </div>
  );
}
