export interface HeroSlide {
  lines: [string, string, string];
  tagline: [string, string, string];
  count: string;
  sr: string;
}

export const SLIDES: HeroSlide[] = [
  { lines: ['Know', 'Your', 'Risk'], tagline: ['Know your collateral’s', 'risk before the', 'market does.'], count: '01', sr: 'Know your collateral’s risk before the market does.' },
  { lines: ['Fresh', 'Price', 'Feeds'], tagline: ['Catch stale oracles', 'before they', 'catch you.'], count: '02', sr: 'Catch stale oracles before they catch you.' },
  { lines: ['Stress', 'Every', 'Gap'], tagline: ['See the overnight gap', 'before the', 'opening bell.'], count: '03', sr: 'See the overnight gap before the opening bell.' },
];
