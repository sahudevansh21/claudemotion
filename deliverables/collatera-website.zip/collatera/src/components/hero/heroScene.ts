// WebGL scene for the landing hero: a rotatable glass cuboid that refracts a
// headline drawn on a 2D canvas, with 6-band chromatic dispersion.
// Kept framework-free so the same code powers public/hero-standalone.html.

import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { mergeGeometries, mergeVertices } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';

export const MODEL_URL =
  'https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260929_212926_92423081-b0e4-4f5a-b650-14af6c05c058.glb';

export interface HeroSceneOptions {
  lines: string[];
  reducedMotion: boolean;
  onLoaded?: () => void;
}

export interface HeroScene {
  setLines(lines: string[]): void;
  spin(direction: -1 | 1, quarterTurns?: number): void;
  dispose(): void;
}

const VERT = /* glsl */ `
varying vec3 vNormal;
varying vec3 vEye;
void main() {
  vec4 worldPos = modelMatrix * vec4(position, 1.0);
  vec4 mvPos = viewMatrix * worldPos;
  gl_Position = projectionMatrix * mvPos;
  vNormal = normalize(normalMatrix * normal);
  vEye = normalize(mvPos.xyz);
}`;

const FRAG = /* glsl */ `
uniform sampler2D uTexture;
uniform vec2 uResolution;
uniform float uIorR, uIorY, uIorG, uIorC, uIorB, uIorP;
uniform float uRefractPower, uChromatic, uSaturation, uShininess, uDiffuseness, uFresnelPower, uBackside;
uniform vec3 uLight;
varying vec3 vNormal;
varying vec3 vEye;
#define LOOP 16

vec3 sat(vec3 rgb, float amount) {
  float l = dot(rgb, vec3(0.2125, 0.7154, 0.0721));
  return mix(vec3(l), rgb, amount);
}

float specular(vec3 light, float shininess, float diffuseness, vec3 n, vec3 eye) {
  vec3 lightVec = normalize(-light);
  vec3 halfVec = normalize(-eye + lightVec);
  float kDiffuse = max(0.0, dot(n, lightVec));
  float kSpecular = pow(max(dot(n, halfVec), 0.0), shininess);
  return kSpecular + kDiffuse * diffuseness;
}

void main() {
  vec2 uv = gl_FragCoord.xy / uResolution;
  vec3 n = normalize(vNormal);
  if (uBackside > 0.5) n = -n;
  vec3 eye = normalize(vEye);
  vec3 color = vec3(0.0);

  vec3 rR = refract(eye, n, 1.0 / uIorR);
  vec3 rY = refract(eye, n, 1.0 / uIorY);
  vec3 rG = refract(eye, n, 1.0 / uIorG);
  vec3 rC = refract(eye, n, 1.0 / uIorC);
  vec3 rB = refract(eye, n, 1.0 / uIorB);
  vec3 rP = refract(eye, n, 1.0 / uIorP);

  for (int i = 0; i < LOOP; i++) {
    float slide = float(i) / float(LOOP) * 0.045;
    float r = texture2D(uTexture, uv + rR.xy * (uRefractPower + slide * 1.0) * uChromatic).x * 0.5;
    vec3 tY = texture2D(uTexture, uv + rY.xy * (uRefractPower + slide * 1.0) * uChromatic).rgb;
    float y = (tY.x * 2.0 + tY.y * 2.0 - tY.z) / 6.0;
    float g = texture2D(uTexture, uv + rG.xy * (uRefractPower + slide * 2.0) * uChromatic).y * 0.5;
    vec3 tC = texture2D(uTexture, uv + rC.xy * (uRefractPower + slide * 2.5) * uChromatic).rgb;
    float c = (tC.y * 2.0 + tC.z * 2.0 - tC.x) / 6.0;
    float b = texture2D(uTexture, uv + rB.xy * (uRefractPower + slide * 3.0) * uChromatic).z * 0.5;
    vec3 tP = texture2D(uTexture, uv + rP.xy * (uRefractPower + slide * 1.0) * uChromatic).rgb;
    float p = (tP.z * 2.0 + tP.x * 2.0 - tP.y) / 6.0;

    float R = r + (2.0 * p + 2.0 * y - c) / 3.0;
    float G = g + (2.0 * y + 2.0 * c - p) / 3.0;
    float B = b + (2.0 * c + 2.0 * p - y) / 3.0;
    color += vec3(R, G, B);
  }
  color /= float(LOOP);
  color = sat(color, uSaturation);

  float spec = specular(uLight, uShininess, uDiffuseness, n, eye)
             + 0.6 * specular(vec3(1.0, 1.0, -1.0), uShininess * 0.6, uDiffuseness * 0.5, n, eye);
  color += spec * (uBackside > 0.5 ? 0.35 : 1.0);

  float f = clamp(pow(1.0 + dot(eye, n), uFresnelPower), 0.0, 1.0);
  color = mix(color, vec3(1.0), f * (uBackside > 0.5 ? 0.25 : 0.55));
  color += vec3(0.004, 0.005, 0.007);
  gl_FragColor = vec4(color, 1.0);
#include <colorspace_fragment>
}`;

const BG_VERT = /* glsl */ `
varying vec2 vUv;
void main() {
  vUv = uv;
  gl_Position = vec4(position.xy, 0.0, 1.0);
}`;

const BG_FRAG = /* glsl */ `
uniform sampler2D uTex;
varying vec2 vUv;
void main() {
  gl_FragColor = texture2D(uTex, vUv);
#include <colorspace_fragment>
}`;

export function webglAvailable(): boolean {
  try {
    const c = document.createElement('canvas');
    return !!(c.getContext('webgl2') || c.getContext('webgl'));
  } catch {
    return false;
  }
}

export function createHeroScene(canvas: HTMLCanvasElement, opts: HeroSceneOptions): HeroScene {
  const FOV = 30;
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
  renderer.setClearColor(0x000000, 1);
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  const camera = new THREE.PerspectiveCamera(FOV, 1, 0.1, 100);
  camera.position.set(0, 0, 10);
  camera.lookAt(0, 0, 0);

  // ---- background headline -------------------------------------------------
  const textCanvas = document.createElement('canvas');
  const ctx = textCanvas.getContext('2d')!;
  const textTex = new THREE.CanvasTexture(textCanvas);
  textTex.colorSpace = THREE.SRGBColorSpace;
  textTex.minFilter = THREE.LinearFilter;
  textTex.magFilter = THREE.LinearFilter;
  textTex.generateMipmaps = false;

  const bgScene = new THREE.Scene();
  const bgCam = new THREE.Camera();
  const bgMat = new THREE.ShaderMaterial({
    vertexShader: BG_VERT, fragmentShader: BG_FRAG,
    uniforms: { uTex: { value: textTex } }, depthTest: false, depthWrite: false,
  });
  const bgQuad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), bgMat);
  bgQuad.frustumCulled = false;
  bgScene.add(bgQuad);

  let W = 1, H = 1, DPR = 1, mobile = false;
  let fromLines: string[] = [];
  let toLines: string[] = opts.lines;
  let fadeStart = -1;
  const FADE_MS = opts.reducedMotion ? 1 : 600;

  function headlineMetrics(lines: string[]) {
    let fs = Math.min(H * 0.21, W * (mobile ? 0.21 : 0.118));
    ctx.font = `800 ${fs * DPR}px Poppins`;
    const widest = Math.max(...lines.map((l) => ctx.measureText(l).width / DPR));
    const maxW = W * (mobile ? 0.9 : 0.5);
    if (widest > maxW) fs *= maxW / widest;
    return fs;
  }

  function drawLines(lines: string[], alpha: number, offsetY: number) {
    if (alpha <= 0) return;
    const fs = headlineMetrics(lines);
    const cx = W * (mobile ? 0.5 : 0.505);
    const cy = H * (mobile ? 0.45 : 0.468);
    const gap = fs * 1.07;
    const cap = fs * 0.7;
    ctx.font = `800 ${fs * DPR}px Poppins`;
    ctx.fillStyle = '#e9e9e9';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'alphabetic';
    ctx.globalAlpha = alpha;
    lines.forEach((line, i) => {
      ctx.fillText(line, cx * DPR, (cy + cap / 2 + (i - 1) * gap + offsetY) * DPR);
    });
    ctx.globalAlpha = 1;
  }

  function drawHeadline(now: number) {
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, textCanvas.width, textCanvas.height);
    const fs = Math.min(H * 0.21, W * (mobile ? 0.21 : 0.118));
    if (fadeStart < 0) {
      drawLines(toLines, 1, 0);
    } else {
      const lin = Math.min(1, (now - fadeStart) / FADE_MS);
      const t = lin < 0.5 ? 2 * lin * lin : 1 - (-2 * lin + 2) ** 2 / 2; // easeInOutQuad
      drawLines(fromLines, 1 - t, -fs * 0.12 * t);
      drawLines(toLines, t, fs * 0.12 * (1 - t));
      if (lin >= 1) fadeStart = -1;
    }
    textTex.needsUpdate = true;
  }

  // ---- glass cube ----------------------------------------------------------
  const scene = new THREE.Scene();
  const pivot = new THREE.Group();
  const spinner = new THREE.Group();
  spinner.rotation.set(-0.42, 0.62, 0.18);
  pivot.add(spinner);
  scene.add(pivot);

  const rtOpts = { type: THREE.HalfFloatType, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter };
  const rtBack = new THREE.WebGLRenderTarget(1, 1, rtOpts);
  const rtFront = new THREE.WebGLRenderTarget(1, 1, rtOpts);

  const common = () => ({
    uTexture: { value: null as THREE.Texture | null },
    uResolution: { value: new THREE.Vector2(1, 1) },
    uIorR: { value: 1.15 }, uIorY: { value: 1.16 }, uIorG: { value: 1.18 },
    uIorC: { value: 1.22 }, uIorB: { value: 1.22 }, uIorP: { value: 1.22 },
    uRefractPower: { value: 0.3 }, uChromatic: { value: 0.5 }, uSaturation: { value: 1.08 },
    uShininess: { value: 90 }, uDiffuseness: { value: 0.02 }, uFresnelPower: { value: 5.0 },
    uLight: { value: new THREE.Vector3(-1, 1, 1) }, uBackside: { value: 0 },
  });
  const frontMat = new THREE.ShaderMaterial({ vertexShader: VERT, fragmentShader: FRAG, uniforms: common(), side: THREE.FrontSide });
  const backMat = new THREE.ShaderMaterial({ vertexShader: VERT, fragmentShader: FRAG, uniforms: common(), side: THREE.BackSide });
  backMat.uniforms.uRefractPower.value = 0.22;
  backMat.uniforms.uBackside.value = 1;
  backMat.uniforms.uTexture.value = rtBack.texture;
  frontMat.uniforms.uTexture.value = rtFront.texture;

  let mesh: THREE.Mesh | null = null;
  let geometry: THREE.BufferGeometry | null = null;

  function useGeometry(g: THREE.BufferGeometry) {
    g.computeBoundingBox();
    const box = g.boundingBox!;
    const center = box.getCenter(new THREE.Vector3());
    const size = box.getSize(new THREE.Vector3());
    g.translate(-center.x, -center.y, -center.z);
    const s = 1 / Math.max(size.x, size.y, size.z);
    g.scale(s, s, s);
    geometry = g;
    mesh = new THREE.Mesh(g, frontMat);
    spinner.add(mesh);
    opts.onLoaded?.();
  }

  let disposed = false;
  new GLTFLoader().load(
    MODEL_URL,
    (gltf) => {
      if (disposed) return;
      gltf.scene.updateMatrixWorld(true);
      const parts: THREE.BufferGeometry[] = [];
      gltf.scene.traverse((o) => {
        const m = o as THREE.Mesh;
        if (!m.isMesh) return;
        let g = m.geometry.clone();
        g.deleteAttribute('uv');
        g.deleteAttribute('color');
        g.deleteAttribute('tangent');
        for (const name of Object.keys(g.attributes)) if (name !== 'position' && name !== 'normal') g.deleteAttribute(name);
        g = mergeVertices(g, 1e-4);
        g.computeVertexNormals();
        g.applyMatrix4(m.matrixWorld);
        parts.push(g);
      });
      const merged = parts.length ? mergeGeometries(parts) : null;
      useGeometry(merged ?? new RoundedBoxGeometry(1, 1, 1, 8, 0.12));
    },
    undefined,
    () => {
      if (!disposed) useGeometry(new RoundedBoxGeometry(1, 1, 1, 8, 0.12));
    },
  );

  // ---- layout --------------------------------------------------------------
  function layout() {
    W = window.innerWidth;
    H = canvas.parentElement?.clientHeight || window.innerHeight;
    DPR = Math.min(window.devicePixelRatio || 1, 2);
    mobile = W < 768 || W / H < 1;

    renderer.setPixelRatio(DPR);
    renderer.setSize(W, H, false);
    camera.aspect = W / H;
    camera.updateProjectionMatrix();

    const bw = Math.round(W * DPR);
    const bh = Math.round(H * DPR);
    rtBack.setSize(bw, bh);
    rtFront.setSize(bw, bh);
    frontMat.uniforms.uResolution.value.set(bw, bh);
    backMat.uniforms.uResolution.value.set(bw, bh);

    textCanvas.width = bw;
    textCanvas.height = bh;
    textTex.dispose(); // reallocate at the new size
    drawHeadline(performance.now());

    const visH = 2 * Math.tan(THREE.MathUtils.degToRad(FOV / 2)) * 10;
    const visW = visH * camera.aspect;
    const sx = mobile ? 0.5 : 0.517;
    const sy = mobile ? 0.45 : 0.488;
    pivot.position.set((sx - 0.5) * visW, (0.5 - sy) * visH, 0);
    const px = Math.min(H * 0.44, W * (mobile ? 0.45 : 0.29));
    pivot.scale.setScalar((px / H) * visH);
  }

  // ---- interaction -----------------------------------------------------------
  const AX_X = new THREE.Vector3(1, 0, 0);
  const AX_Y = new THREE.Vector3(0, 1, 0);
  const qTmp = new THREE.Quaternion();
  function rotateWorld(dx: number, dy: number) {
    spinner.quaternion.premultiply(qTmp.setFromAxisAngle(AX_Y, dx));
    spinner.quaternion.premultiply(qTmp.setFromAxisAngle(AX_X, dy));
  }

  let dragging = false;
  let lastX = 0, lastY = 0, lastT = 0;
  let vx = 0, vy = 0;
  let releasedAt = -Infinity;
  let idleBlend = opts.reducedMotion ? 0 : 1;
  let spinRemaining = 0;

  function onDown(e: PointerEvent) {
    dragging = true;
    spinRemaining = 0;
    vx = vy = 0;
    lastX = e.clientX; lastY = e.clientY; lastT = performance.now();
    canvas.setPointerCapture(e.pointerId);
    canvas.classList.add('dragging');
    idleBlend = 0;
  }
  function onMove(e: PointerEvent) {
    if (!dragging) return;
    const now = performance.now();
    const dx = (e.clientX - lastX) * 0.008;
    const dy = (e.clientY - lastY) * 0.008;
    rotateWorld(dx, dy);
    const frames = Math.max((now - lastT) / 16.67, 0.25);
    vx = dx / frames; vy = dy / frames;
    lastX = e.clientX; lastY = e.clientY; lastT = now;
  }
  function onUp(e: PointerEvent) {
    if (!dragging) return;
    dragging = false;
    if (performance.now() - lastT > 80) vx = vy = 0; // paused before release
    releasedAt = performance.now();
    canvas.classList.remove('dragging');
    try { canvas.releasePointerCapture(e.pointerId); } catch { /* already released */ }
  }
  canvas.addEventListener('pointerdown', onDown);
  canvas.addEventListener('pointermove', onMove);
  canvas.addEventListener('pointerup', onUp);
  canvas.addEventListener('pointercancel', onUp);

  // ---- loop -------------------------------------------------------------------
  let raf = 0;
  let prev = performance.now();
  let visible = true;

  function frame(now: number) {
    raf = requestAnimationFrame(frame);
    if (!visible) { prev = now; return; }
    const dt = Math.min((now - prev) / 1000, 0.05);
    prev = now;
    const k = dt * 60;

    if (fadeStart >= 0) drawHeadline(now);

    if (!dragging) {
      if (Math.abs(spinRemaining) > 0.0005) {
        const step = spinRemaining * Math.min(1, 0.09 * k);
        rotateWorld(step, 0);
        spinRemaining -= step;
      } else spinRemaining = 0;

      if (vx || vy) {
        rotateWorld(vx * k, vy * k);
        const damp = Math.pow(0.94, k);
        vx *= damp; vy *= damp;
        if (Math.abs(vx) < 1e-5 && Math.abs(vy) < 1e-5) vx = vy = 0;
      }
      if (!opts.reducedMotion && now - releasedAt > 600) {
        idleBlend = Math.min(1, idleBlend + dt);
        rotateWorld(0.0035 * k * idleBlend, 0.0012 * k * idleBlend);
      }
    }

    renderer.autoClear = true;
    renderer.setRenderTarget(rtBack);
    renderer.render(bgScene, bgCam);

    renderer.setRenderTarget(rtFront);
    renderer.render(bgScene, bgCam);
    if (mesh) {
      renderer.autoClear = false;
      mesh.material = backMat;
      renderer.render(scene, camera);
    }

    renderer.autoClear = true;
    renderer.setRenderTarget(null);
    renderer.render(bgScene, bgCam);
    if (mesh) {
      renderer.autoClear = false;
      renderer.clearDepth();
      mesh.material = frontMat;
      renderer.render(scene, camera);
    }
  }

  const onResize = () => layout();
  window.addEventListener('resize', onResize);
  const onFonts = () => drawHeadline(performance.now());
  document.fonts?.addEventListener?.('loadingdone', onFonts);

  const io = new IntersectionObserver(([entry]) => { visible = entry.isIntersecting && !document.hidden; });
  io.observe(canvas);
  const onVis = () => { visible = !document.hidden; };
  document.addEventListener('visibilitychange', onVis);

  const fontsReady = Promise.race([
    Promise.all([document.fonts.load('800 100px Poppins'), document.fonts.ready]),
    new Promise((r) => setTimeout(r, 2500)),
  ]);
  fontsReady.then(() => {
    if (disposed) return;
    layout();
    raf = requestAnimationFrame(frame);
  });

  return {
    setLines(lines) {
      fromLines = toLines;
      toLines = lines;
      fadeStart = performance.now();
      drawHeadline(fadeStart);
    },
    spin(direction, quarterTurns = 1) {
      vx = vy = 0;
      spinRemaining += direction * (Math.PI / 2) * quarterTurns;
    },
    dispose() {
      disposed = true;
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', onResize);
      document.fonts?.removeEventListener?.('loadingdone', onFonts);
      document.removeEventListener('visibilitychange', onVis);
      io.disconnect();
      canvas.removeEventListener('pointerdown', onDown);
      canvas.removeEventListener('pointermove', onMove);
      canvas.removeEventListener('pointerup', onUp);
      canvas.removeEventListener('pointercancel', onUp);
      geometry?.dispose();
      frontMat.dispose(); backMat.dispose(); bgMat.dispose(); bgQuad.geometry.dispose();
      textTex.dispose(); rtBack.dispose(); rtFront.dispose();
      renderer.dispose();
    },
  };
}
