'use client';

import Link from 'next/link';
import { useCallback, useEffect, useRef, useState } from 'react';
import type { HeroScene } from './heroScene';
import { SLIDES } from './slides';
import './hero.css';

const AUTO_ADVANCE_MS = 7000;
const IDLE_BEFORE_AUTO_MS = 10_000;

export default function GlassHero() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sceneRef = useRef<HeroScene | null>(null);
  const lastInteraction = useRef(0);
  const [slide, setSlide] = useState(0);
  const [textSlide, setTextSlide] = useState(0);
  const [loaded, setLoaded] = useState(false);
  const [fallback, setFallback] = useState(false);
  const [fading, setFading] = useState(false);
  const reduced = useRef(false);

  useEffect(() => {
    reduced.current = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let cancelled = false;
    let scene: HeroScene | null = null;
    import('./heroScene').then(({ createHeroScene, webglAvailable }) => {
      if (cancelled || !canvasRef.current) return;
      if (!webglAvailable()) {
        setFallback(true);
        setLoaded(true);
        return;
      }
      scene = createHeroScene(canvasRef.current, {
        lines: SLIDES[0].lines,
        reducedMotion: reduced.current,
        onLoaded: () => setLoaded(true),
      });
      sceneRef.current = scene;
    });
    return () => {
      cancelled = true;
      scene?.dispose();
      sceneRef.current = null;
    };
  }, []);

  const slideRef = useRef(0);
  const goTo = useCallback((next: number, direction: -1 | 1, turns = 1, user = true) => {
    if (user) lastInteraction.current = Date.now();
    const target = (next + SLIDES.length) % SLIDES.length;
    if (target === slideRef.current) return;
    slideRef.current = target;
    sceneRef.current?.setLines(SLIDES[target].lines);
    sceneRef.current?.spin(direction, turns);
    setSlide(target);
    setFading(true);
    window.setTimeout(() => {
      setTextSlide(target);
      setFading(false);
    }, 220);
  }, []);

  const prev = () => goTo(slide - 1, -1);
  const next = useCallback(() => goTo(slide + 1, 1), [goTo, slide]);

  // Auto-advance after a period without interaction.
  useEffect(() => {
    if (reduced.current) return;
    const id = window.setInterval(() => {
      if (document.hidden || Date.now() - lastInteraction.current < IDLE_BEFORE_AUTO_MS) return;
      goTo(slide + 1, 1, 1, false);
    }, AUTO_ADVANCE_MS);
    return () => window.clearInterval(id);
  }, [goTo, slide]);

  const s = SLIDES[textSlide];

  return (
    <section
      className="hero"
      id="hero"
      aria-roledescription="carousel"
      onKeyDown={(e) => {
        if (e.key === 'ArrowLeft') prev();
        if (e.key === 'ArrowRight') next();
      }}
    >
      <canvas
        id="scene"
        ref={canvasRef}
        tabIndex={0}
        aria-label="Rotatable glass cube. Drag to rotate, use the arrow keys to change slides."
        onPointerDown={() => { lastInteraction.current = Date.now(); }}
      />
      {fallback && (
        <div className="hero-fallback" aria-hidden="true">
          <div className="hero-fallback-text">{s.lines.map((l) => <span key={l}>{l}</span>)}</div>
          <div className="hero-fallback-glass" />
        </div>
      )}
      <div className="ui">
        <h1 className="sr-only">{s.sr}</h1>
        <header className="nav">
          <Link href="/" className="logo" aria-label="COLLATERA home"><i className="logo-mark" /><span><b>COLL</b>ATERA</span></Link>
          <ul className="nav-links">
            <li><Link href="/dashboard">Dashboard</Link></li>
            <li><Link href="/pricing">Pricing</Link></li>
            <li><Link href="/docs">Docs</Link></li>
          </ul>
        </header>
        <div className="arrows">
          <button className="arrow" id="prev" aria-label="Previous slide" onClick={prev}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round"><path d="M19 12H5M11 6l-6 6 6 6" /></svg>
          </button>
          <button className="arrow" id="next" aria-label="Next slide" onClick={next}>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
          </button>
        </div>
        <nav className="dots" aria-label="Hero slides">
          {SLIDES.map((_, i) => (
            <button
              key={i}
              className={`dot${i === slide ? ' active' : ''}`}
              aria-label={`Slide ${i + 1}`}
              aria-current={i === slide ? 'true' : undefined}
              onClick={() => goTo(i, i > slide ? 1 : -1, Math.abs(i - slide))}
            />
          ))}
        </nav>
        <p className={`tagline${fading ? ' fading' : ''}`} aria-live="polite">
          {s.tagline[0]}<br />{s.tagline[1]}<strong>{s.tagline[2]}</strong>
        </p>
        <div className="cta-row">
          <a href="#check" className="cta">Check a wallet</a>
          <span className="cta-line" />
          <span className={`count${fading ? ' fading' : ''}`} aria-hidden="true">{s.count}</span>
        </div>
        <div className={`loader${loaded ? ' done' : ''}`} id="loader">Loading model</div>
      </div>
    </section>
  );
}
