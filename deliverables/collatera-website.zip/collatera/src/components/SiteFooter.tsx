import Link from 'next/link';

export default function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="container">
        <div className="cols">
          <div className="stack" style={{ gap: 10 }}>
            <Link href="/" style={{ color: '#fff', fontSize: 15 }}><b>COLL</b>ATERA</Link>
            <span>Know your collateral’s risk before the market does.</span>
          </div>
          <div>
            <div className="eyebrow" style={{ marginBottom: 8 }}>Product</div>
            <Link href="/dashboard">Dashboard</Link>
            <Link href="/stress">Stress test</Link>
            <Link href="/alerts">Alerts</Link>
            <Link href="/pricing">Pricing &amp; B2B</Link>
          </div>
          <div>
            <div className="eyebrow" style={{ marginBottom: 8 }}>Learn</div>
            <Link href="/docs">Docs</Link>
            <Link href="/docs#risk-score">How scoring works</Link>
            <Link href="/docs#limits">Risk notes &amp; limits</Link>
            <Link href="/docs#roadmap">Roadmap</Link>
          </div>
          <div>
            <div className="eyebrow" style={{ marginBottom: 8 }}>Legal</div>
            <Link href="/legal/terms">Terms</Link>
            <Link href="/legal/privacy">Privacy</Link>
            <Link href="/legal/risk">Risk disclosure</Link>
          </div>
        </div>
        <p className="disclaimer">
          COLLATERA is read-only: it never holds funds or keys and never executes transactions on its own. Version one covers one lending
          market. Data can lag or fail, so COLLATERA improves risk awareness but does not guarantee protection from liquidation. Not
          financial advice. © {new Date().getFullYear()} COLLATERA.
        </p>
      </div>
    </footer>
  );
}
