'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { api } from '@/lib/client/api';
import { DEMO_ADDRESS } from '@/lib/chain/demo';

export default function WalletCheck({ compact = false }: { compact?: boolean }) {
  const router = useRouter();
  const [value, setValue] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    setBusy(true);
    try {
      const r = await api<{ address: string }>('/api/resolve', { method: 'POST', json: { query: value } });
      router.push(`/dashboard?address=${r.address}`);
    } catch (e2) {
      setErr((e2 as Error).message);
      setBusy(false);
    }
  }

  return (
    <form onSubmit={submit} className="stack" style={{ gap: 12 }} aria-label="Check a wallet">
      <div className="big-input">
        <label htmlFor="wallet" className="sr-only">Wallet address or ENS name</label>
        <input
          id="wallet"
          className="input"
          placeholder="Paste a wallet address or ENS name"
          value={value}
          onChange={(e) => setValue(e.target.value)}
          autoComplete="off"
          spellCheck={false}
          required
        />
        <button className="btn btn-solid" disabled={busy || !value.trim()}>{busy ? 'Scanning…' : 'Scan'}</button>
      </div>
      {err && <p className="notice err" role="alert">{err}</p>}
      {!compact && (
        <div className="spread small">
          <span className="muted">View-only. We never ask for keys or move funds.</span>
          <button type="button" className="link" style={{ background: 'none', border: 0, padding: 0, cursor: 'pointer' }} onClick={() => router.push(`/dashboard?address=${DEMO_ADDRESS}`)}>
            Try the demo wallet →
          </button>
        </div>
      )}
    </form>
  );
}
