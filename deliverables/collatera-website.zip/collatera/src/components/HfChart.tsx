'use client';

import { useState } from 'react';

interface Point { createdAt: string; healthFactor: number; buffer: number }

/** Health-factor history with the liquidation line (1.0) and the planner target. */
export default function HfChart({ points, target = 1.5 }: { points: Point[]; target?: number }) {
  const [hover, setHover] = useState<number | null>(null);
  const W = 800, H = 240, P = { l: 44, r: 12, t: 12, b: 28 };
  const real = points.filter((p) => p.healthFactor < 1e6);
  if (real.length < 2) return <p className="muted small">Not enough history yet — the worker adds a snapshot every minute or hour depending on your plan.</p>;
  const max = Math.max(target + 0.5, Math.min(4, Math.max(...real.map((p) => p.healthFactor)) * 1.08));
  const min = 0.8;
  const t0 = new Date(real[0].createdAt).getTime();
  const t1 = new Date(real[real.length - 1].createdAt).getTime();
  const x = (t: number) => P.l + ((t - t0) / Math.max(1, t1 - t0)) * (W - P.l - P.r);
  const y = (v: number) => P.t + (1 - (Math.min(max, Math.max(min, v)) - min) / (max - min)) * (H - P.t - P.b);
  const d = real.map((p, i) => `${i ? 'L' : 'M'}${x(new Date(p.createdAt).getTime()).toFixed(1)},${y(p.healthFactor).toFixed(1)}`).join('');
  const ticks = [1, target, Math.round(max * 2) / 2].filter((v, i, a) => a.indexOf(v) === i && v <= max);
  const h = hover != null ? real[hover] : null;

  return (
    <div style={{ position: 'relative' }}>
      <svg className="chart" viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Health factor over the last 7 days"
        onMouseLeave={() => setHover(null)}
        onMouseMove={(e) => {
          const r = (e.currentTarget as SVGSVGElement).getBoundingClientRect();
          const px = ((e.clientX - r.left) / r.width) * W;
          const t = t0 + ((px - P.l) / (W - P.l - P.r)) * (t1 - t0);
          let best = 0;
          real.forEach((p, i) => { if (Math.abs(new Date(p.createdAt).getTime() - t) < Math.abs(new Date(real[best].createdAt).getTime() - t)) best = i; });
          setHover(best);
        }}>
        {ticks.map((v) => (
          <g key={v}>
            <line x1={P.l} x2={W - P.r} y1={y(v)} y2={y(v)} stroke={v === 1 ? 'var(--risk)' : v === target ? 'rgba(255,255,255,.35)' : 'rgba(255,255,255,.08)'} strokeDasharray={v === 1 ? '0' : '4 4'} />
            <text x={P.l - 8} y={y(v) + 4} textAnchor="end" fill="rgba(255,255,255,.55)" fontSize="11">{v.toFixed(1)}</text>
          </g>
        ))}
        <text x={P.l} y={H - 6} fill="rgba(255,255,255,.55)" fontSize="11">{new Date(t0).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</text>
        <text x={W - P.r} y={H - 6} textAnchor="end" fill="rgba(255,255,255,.55)" fontSize="11">now</text>
        <path d={d} fill="none" stroke="#fff" strokeWidth="1.8" strokeLinejoin="round" />
        {h && (
          <g>
            <line x1={x(new Date(h.createdAt).getTime())} x2={x(new Date(h.createdAt).getTime())} y1={P.t} y2={H - P.b} stroke="rgba(255,255,255,.3)" />
            <circle cx={x(new Date(h.createdAt).getTime())} cy={y(h.healthFactor)} r="4" fill="#fff" />
          </g>
        )}
      </svg>
      <div className="small muted num" style={{ minHeight: 20 }}>
        {h ? `${new Date(h.createdAt).toLocaleString()} · HF ${h.healthFactor.toFixed(2)} · buffer ${(h.buffer * 100).toFixed(1)}%` : 'Red line = liquidation (1.0). Dashed = planner target.'}
      </div>
    </div>
  );
}
