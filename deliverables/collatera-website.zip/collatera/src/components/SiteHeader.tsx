'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useApi, type Me } from '@/lib/client/api';

const LINKS = [
  { href: '/dashboard', label: 'Dashboard' },
  { href: '/stress', label: 'Stress test' },
  { href: '/alerts', label: 'Alerts' },
  { href: '/pricing', label: 'Pricing' },
  { href: '/docs', label: 'Docs' },
];

export default function SiteHeader() {
  const path = usePathname();
  const { data } = useApi<Me>('/api/me');
  return (
    <header className="site-header">
      <div className="container inner">
        <Link href="/" className="logo" aria-label="COLLATERA home"><i className="logo-mark" /><span><b>COLL</b>ATERA</span></Link>
        <nav aria-label="Main">
          {LINKS.map((l) => (
            <Link key={l.href} href={l.href} className="navlink" aria-current={path?.startsWith(l.href) ? 'page' : undefined}>{l.label}</Link>
          ))}
          {data?.user ? (
            <Link href="/account" className="btn btn-sm btn-ghost" aria-current={path === '/account' ? 'page' : undefined}>{data.user.email.split('@')[0]}</Link>
          ) : (
            <Link href={`/login?next=${encodeURIComponent(path ?? '/dashboard')}`} className="btn btn-sm">Sign in</Link>
          )}
        </nav>
      </div>
    </header>
  );
}
