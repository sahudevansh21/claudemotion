import type { Badge as BadgeT, FeedState } from '@/lib/risk/types';
import { pct } from '@/lib/risk/engine';

const BADGE_LABEL: Record<BadgeT, string> = { safe: 'Safe', watch: 'Watch', risk: 'At Risk' };

export function Badge({ badge }: { badge: BadgeT }) {
  return <span className={`badge ${badge}`}>{BADGE_LABEL[badge]}</span>;
}

export function FeedChip({ state, ageSec }: { state: FeedState; ageSec?: number | null }) {
  const label = state === 'fresh' ? 'Fresh' : state === 'stale' ? 'Stale' : 'Critical';
  const age = ageSec == null ? 'no data' : ageSec < 3600 ? `${Math.round(ageSec / 60)}m` : `${(ageSec / 3600).toFixed(1)}h`;
  return <span className={`chip ${state}`} title={`Oracle age ${age}`}>{label} · {age}</span>;
}

/** Buffer bar: 0–50% scale, colour by zone, tick at the user's threshold. */
export function BufferBar({ buffer, effective, threshold = 0.15 }: { buffer: number; effective?: number; threshold?: number }) {
  const scale = (x: number) => `${Math.max(0, Math.min(1, x / 0.5)) * 100}%`;
  const v = effective ?? buffer;
  const color = v < 0.1 ? 'var(--risk)' : v < 0.25 ? 'var(--watch)' : 'var(--safe)';
  return (
    <div className="stack" style={{ gap: 6 }}>
      <div className="bufferbar" role="meter" aria-valuemin={0} aria-valuemax={50} aria-valuenow={Math.round(v * 100)} aria-label="Buffer to liquidation">
        {effective != null && effective < buffer && <span style={{ width: scale(buffer), background: 'rgba(255,255,255,.18)' }} />}
        <span style={{ width: scale(v), background: color }} />
        <i style={{ left: scale(threshold) }} />
      </div>
      <div className="spread small muted num">
        <span>{pct(Math.max(v, 0))} buffer{effective != null && effective < buffer ? ` (raw ${pct(buffer)})` : ''}</span>
        <span>50%+</span>
      </div>
    </div>
  );
}

export function Stat({ label, value, sub, tone }: { label: string; value: React.ReactNode; sub?: React.ReactNode; tone?: string }) {
  return (
    <div className="stat">
      <span className="label">{label}</span>
      <span className={`value ${tone ? `c-${tone}` : ''}`}>{value}</span>
      {sub && <span className="small muted">{sub}</span>}
    </div>
  );
}

export function Skeleton({ h = 120, style }: { h?: number; style?: React.CSSProperties }) {
  return <div className="skeleton" style={{ height: h, ...style }} aria-hidden="true" />;
}

export function Arrow({ dir = 'right' }: { dir?: 'left' | 'right' }) {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={dir === 'right' ? 'M5 12h14M13 6l6 6-6 6' : 'M19 12H5M11 6l-6 6 6 6'} />
    </svg>
  );
}

export function DataNote({ at }: { at?: string | null }) {
  return (
    <p className="small faint">
      {at ? `Data as of ${new Date(at).toLocaleString()}. ` : ''}Data can lag or fail. COLLATERA improves risk awareness but does not guarantee protection from liquidation.
    </p>
  );
}
