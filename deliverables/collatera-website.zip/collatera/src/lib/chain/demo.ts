// Demo market: deterministic mock positions so the whole product works offline.
// Prices drift slowly with time so monitoring looks alive, but every value is a
// pure function of the clock (no randomness), which keeps tests reproducible.

import type { CollateralLeg, DebtLeg, RawPosition } from '@/lib/risk/types';
import { findAsset } from '@/config/assets';
import type { Address, LendingMarketAdapter, TxRequest } from './types';

export const DEMO_ADDRESS = '0xc011a7e2a0000000000000000000000000000001' as const;
export const DEMO_MARKET_ID = 'demo';
const DEMO_POOL = '0x00000000000000000000000000000000000d3e70' as Address;

const USDC = { symbol: 'USDC', token: '0x00000000000000000000000000000000000c0de1', decimals: 6 };

function token(symbol: string): string {
  return '0x' + Array.from(symbol).map((c) => c.charCodeAt(0).toString(16)).join('').padEnd(40, '0').slice(0, 40);
}

function wiggle(base: number, seed: number, nowSec: number): number {
  return base * (1 + 0.012 * Math.sin(nowSec / 900 + seed) + 0.006 * Math.sin(nowSec / 211 + seed * 2));
}

function tokenized(symbol: string, amount: number, basePrice: number, lt: number, seed: number, nowSec: number, oracleAgeSec: number): CollateralLeg {
  const a = findAsset('', symbol);
  return {
    symbol,
    token: token(symbol),
    decimals: 18,
    amount,
    price: wiggle(basePrice, seed, nowSec),
    liquidationThreshold: lt,
    tokenized: true,
    underlying: a?.underlying,
    exchange: a?.exchange ?? 'XNAS',
    issuer: a?.issuer,
    gapHaircut: a?.gapHaircut,
    oracle: { feed: token(symbol + 'feed'), updatedAt: nowSec - oracleAgeSec, heartbeatSec: a?.heartbeatSec ?? 3600 },
  };
}

function usdcDebt(amount: number): DebtLeg {
  return { ...USDC, amount, price: 1 };
}

export function demoPositions(owner: string, now: Date = new Date()): RawPosition[] {
  const t = Math.floor(now.getTime() / 1000);
  const base = { marketId: DEMO_MARKET_ID, marketName: 'Demo market', chainId: 0, owner: owner.toLowerCase(), unsupported: [], demo: true };
  return [
    // Safe: HF ≈ 2.0
    { ...base, id: `${DEMO_MARKET_ID}~${owner.toLowerCase()}~0`, collateral: [tokenized('TSLAx', 40, 250, 0.7, 1, t, 600)], debt: [usdcDebt(3500)] },
    // Watch: stale oracle (1.5× its heartbeat)
    { ...base, id: `${DEMO_MARKET_ID}~${owner.toLowerCase()}~1`, collateral: [tokenized('NVDAx', 60, 140, 0.7, 2, t, 5400)], debt: [usdcDebt(3900)] },
    // At risk: thin buffer, mixed collateral
    {
      ...base, id: `${DEMO_MARKET_ID}~${owner.toLowerCase()}~2`,
      collateral: [
        tokenized('SPYx', 10, 580, 0.75, 3, t, 900),
        { ...USDC, amount: 500, price: 1, liquidationThreshold: 0.78, tokenized: false, oracle: { feed: null, updatedAt: t - 60, heartbeatSec: 86400 } },
      ],
      debt: [usdcDebt(4400)],
    },
    // Watch: recent issuer corporate action (seeded in the DB)
    { ...base, id: `${DEMO_MARKET_ID}~${owner.toLowerCase()}~3`, collateral: [tokenized('QQQx', 12, 500, 0.7, 4, t, 1200)], debt: [usdcDebt(2000)] },
  ];
}

function fakeTx(description: string, functionName: string, args: string[]): TxRequest {
  return { to: DEMO_POOL, data: '0x', value: '0', description, functionName, args };
}

export const demoAdapter: LendingMarketAdapter = {
  id: DEMO_MARKET_ID,
  name: 'Demo market',
  chainId: 0,
  async findPositions(owner) {
    return owner.toLowerCase() === DEMO_ADDRESS ? demoPositions(owner) : [];
  },
  async buildRepayTx({ owner, token, amount, symbol }) {
    return [
      fakeTx(`Approve ${amount} ${symbol} for the demo pool`, 'approve', [DEMO_POOL, String(amount)]),
      fakeTx(`Repay ${amount} ${symbol}`, 'repay', [token, String(amount), '2', owner]),
    ];
  },
  async buildSupplyTx({ owner, token, amount, symbol }) {
    return [
      fakeTx(`Approve ${amount} ${symbol} for the demo pool`, 'approve', [DEMO_POOL, String(amount)]),
      fakeTx(`Supply ${amount} ${symbol} as collateral`, 'supply', [token, String(amount), owner, '0']),
    ];
  },
  async simulate() {
    return { ok: true, balance: null, allowance: null, message: 'Demo position — transactions are illustrative and cannot be signed.' };
  },
};
