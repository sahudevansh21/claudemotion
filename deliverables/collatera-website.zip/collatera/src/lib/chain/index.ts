import { env } from '@/lib/server/env';
import { aaveAdapter } from './aave';
import { DEMO_ADDRESS, DEMO_MARKET_ID, demoAdapter } from './demo';
import type { LendingMarketAdapter } from './types';

export { DEMO_ADDRESS };

/** The demo wallet always uses the demo market; everything else uses MARKET_MODE. */
export function adapterFor(owner: string): LendingMarketAdapter {
  if (owner.toLowerCase() === DEMO_ADDRESS || env().MARKET_MODE === 'demo') return demoAdapter;
  return aaveAdapter();
}

export function adapterForPositionId(positionId: string): LendingMarketAdapter {
  return positionId.startsWith(`${DEMO_MARKET_ID}~`) ? demoAdapter : aaveAdapter();
}

export function parsePositionId(id: string): { marketId: string; owner: string; index: number } | null {
  const [marketId, owner, index] = id.split('~');
  if (!marketId || !owner || index == null || !/^0x[0-9a-f]{40}$/.test(owner)) return null;
  return { marketId, owner, index: Number(index) };
}
