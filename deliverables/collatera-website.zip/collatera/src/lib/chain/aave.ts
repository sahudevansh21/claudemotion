// Aave v3-compatible lending market adapter (read-only + unsigned tx building).
// Works with any fork exposing Pool, PoolDataProvider and AaveOracle.

import {
  createPublicClient, encodeFunctionData, formatUnits, http, parseAbi, parseUnits,
  type PublicClient,
} from 'viem';
import * as chains from 'viem/chains';
import { findAsset } from '@/config/assets';
import { env } from '@/lib/server/env';
import type { CollateralLeg, DebtLeg, RawPosition } from '@/lib/risk/types';
import type { Address, LendingMarketAdapter, Simulation, TxRequest } from './types';

const poolAbi = parseAbi([
  'function getUserAccountData(address user) view returns (uint256 totalCollateralBase, uint256 totalDebtBase, uint256 availableBorrowsBase, uint256 currentLiquidationThreshold, uint256 ltv, uint256 healthFactor)',
  'function repay(address asset, uint256 amount, uint256 interestRateMode, address onBehalfOf) returns (uint256)',
  'function supply(address asset, uint256 amount, address onBehalfOf, uint16 referralCode)',
]);
const dataProviderAbi = parseAbi([
  'struct TokenData { string symbol; address tokenAddress; }',
  'function getAllReservesTokens() view returns (TokenData[])',
  'function getUserReserveData(address asset, address user) view returns (uint256 currentATokenBalance, uint256 currentStableDebt, uint256 currentVariableDebt, uint256 principalStableDebt, uint256 scaledVariableDebt, uint256 stableBorrowRate, uint256 liquidityRate, uint40 stableRateLastUpdated, bool usageAsCollateralEnabled)',
  'function getReserveConfigurationData(address asset) view returns (uint256 decimals, uint256 ltv, uint256 liquidationThreshold, uint256 liquidationBonus, uint256 reserveFactor, bool usageAsCollateralEnabled, bool borrowingEnabled, bool stableBorrowRateEnabled, bool isActive, bool isFrozen)',
]);
const oracleAbi = parseAbi([
  'function getAssetPrice(address asset) view returns (uint256)',
  'function getSourceOfAsset(address asset) view returns (address)',
  'function BASE_CURRENCY_UNIT() view returns (uint256)',
]);
const aggregatorAbi = parseAbi([
  'function latestRoundData() view returns (uint80 roundId, int256 answer, uint256 startedAt, uint256 updatedAt, uint80 answeredInRound)',
]);
export const erc20Abi = parseAbi([
  'function approve(address spender, uint256 amount) returns (bool)',
  'function allowance(address owner, address spender) view returns (uint256)',
  'function balanceOf(address owner) view returns (uint256)',
]);

let client: PublicClient | null = null;
export function publicClient(): PublicClient {
  if (client) return client;
  const e = env();
  const chain = Object.values(chains).find((c) => typeof c === 'object' && c && 'id' in c && c.id === e.CHAIN_ID) as chains.Chain | undefined;
  client = createPublicClient({ chain, transport: http(e.RPC_URL, { timeout: 15_000 }), batch: { multicall: true } }) as PublicClient;
  return client;
}

interface ReserveMeta { symbol: string; token: Address; decimals: number; lt: number }
let reservesCache: { at: number; list: ReserveMeta[] } | null = null;

async function reserves(): Promise<ReserveMeta[]> {
  if (reservesCache && Date.now() - reservesCache.at < 10 * 60_000) return reservesCache.list;
  const e = env();
  const c = publicClient();
  const tokens = await c.readContract({ address: e.AAVE_DATA_PROVIDER as Address, abi: dataProviderAbi, functionName: 'getAllReservesTokens' });
  const configs = await c.multicall({
    contracts: tokens.map((t) => ({ address: e.AAVE_DATA_PROVIDER as Address, abi: dataProviderAbi, functionName: 'getReserveConfigurationData' as const, args: [t.tokenAddress] as const })),
    allowFailure: false,
  });
  const list = tokens.map((t, i) => ({
    symbol: t.symbol,
    token: t.tokenAddress.toLowerCase() as Address,
    decimals: Number(configs[i][0]),
    lt: Number(configs[i][2]) / 10_000,
  }));
  reservesCache = { at: Date.now(), list };
  return list;
}

function assertConfigured() {
  const e = env();
  if (!e.RPC_URL || !e.AAVE_POOL || !e.AAVE_DATA_PROVIDER || !e.AAVE_ORACLE) {
    throw new Error('Live market is not configured: set RPC_URL, AAVE_POOL, AAVE_DATA_PROVIDER and AAVE_ORACLE.');
  }
}

export function aaveAdapter(): LendingMarketAdapter {
  const e = env();
  const id = `aave-${e.CHAIN_ID}`;
  return {
    id,
    name: e.AAVE_MARKET_NAME,
    chainId: e.CHAIN_ID,

    async findPositions(owner) {
      assertConfigured();
      const c = publicClient();
      const pool = e.AAVE_POOL as Address;
      const account = await c.readContract({ address: pool, abi: poolAbi, functionName: 'getUserAccountData', args: [owner] });
      if (account[0] === 0n && account[1] === 0n) return [];

      const list = await reserves();
      const userData = await c.multicall({
        contracts: list.map((r) => ({ address: e.AAVE_DATA_PROVIDER as Address, abi: dataProviderAbi, functionName: 'getUserReserveData' as const, args: [r.token, owner] as const })),
        allowFailure: false,
      });
      const held = list
        .map((r, i) => ({ r, d: userData[i] }))
        .filter(({ d }) => (d[0] > 0n && d[8]) || d[1] > 0n || d[2] > 0n);
      if (!held.length) return [];

      const oracle = e.AAVE_ORACLE as Address;
      const unit = await c.readContract({ address: oracle, abi: oracleAbi, functionName: 'BASE_CURRENCY_UNIT' });
      const prices = await c.multicall({
        contracts: held.map(({ r }) => ({ address: oracle, abi: oracleAbi, functionName: 'getAssetPrice' as const, args: [r.token] as const })),
        allowFailure: false,
      });
      const sources = await c.multicall({
        contracts: held.map(({ r }) => ({ address: oracle, abi: oracleAbi, functionName: 'getSourceOfAsset' as const, args: [r.token] as const })),
        allowFailure: true,
      });
      const rounds = await c.multicall({
        contracts: sources.map((s) => ({ address: (s.status === 'success' ? s.result : '0x0000000000000000000000000000000000000000') as Address, abi: aggregatorAbi, functionName: 'latestRoundData' as const })),
        allowFailure: true,
      });

      const unitDecimals = unit.toString().length - 1;
      const collateral: CollateralLeg[] = [];
      const debt: DebtLeg[] = [];
      const unsupported: string[] = [];

      held.forEach(({ r, d }, i) => {
        const price = Number(formatUnits(prices[i], unitDecimals));
        if (d[0] > 0n && d[8]) {
          const asset = findAsset(r.token, r.symbol);
          const round = rounds[i];
          const feed = sources[i].status === 'success' ? (sources[i].result as string) : null;
          collateral.push({
            symbol: r.symbol,
            token: r.token,
            decimals: r.decimals,
            amount: Number(formatUnits(d[0], r.decimals)),
            price,
            liquidationThreshold: r.lt,
            tokenized: !!asset,
            underlying: asset?.underlying,
            exchange: asset?.exchange,
            issuer: asset?.issuer,
            gapHaircut: asset?.gapHaircut,
            oracle: {
              feed,
              updatedAt: round.status === 'success' ? Number((round.result as readonly bigint[])[3]) : null,
              heartbeatSec: asset?.heartbeatSec ?? 86_400,
              failed: !!asset && round.status !== 'success',
            },
          });
          if (!asset) unsupported.push(r.symbol);
        }
        const owed = d[1] + d[2];
        if (owed > 0n) debt.push({ symbol: r.symbol, token: r.token, decimals: r.decimals, amount: Number(formatUnits(owed, r.decimals)), price });
      });

      const position: RawPosition = {
        id: `${id}~${owner.toLowerCase()}~0`,
        marketId: id,
        marketName: e.AAVE_MARKET_NAME,
        chainId: e.CHAIN_ID,
        owner: owner.toLowerCase(),
        collateral,
        debt,
        unsupported,
        demo: false,
        protocolHealthFactor: account[1] === 0n ? undefined : Number(formatUnits(account[5], 18)),
      };
      return [position];
    },

    async buildRepayTx({ owner, token, amount, decimals, symbol }) {
      const pool = e.AAVE_POOL as Address;
      const wei = parseUnits(amount.toFixed(Math.min(decimals, 12)), decimals);
      return [
        {
          to: token, value: '0', functionName: 'approve', args: [pool, wei.toString()],
          description: `Approve ${amount} ${symbol} for the lending pool`,
          data: encodeFunctionData({ abi: erc20Abi, functionName: 'approve', args: [pool, wei] }),
        },
        {
          to: pool, value: '0', functionName: 'repay', args: [token, wei.toString(), '2', owner],
          description: `Repay ${amount} ${symbol} of variable-rate debt`,
          data: encodeFunctionData({ abi: poolAbi, functionName: 'repay', args: [token, wei, 2n, owner] }),
        },
      ];
    },

    async buildSupplyTx({ owner, token, amount, decimals, symbol }) {
      const pool = e.AAVE_POOL as Address;
      const wei = parseUnits(amount.toFixed(Math.min(decimals, 12)), decimals);
      return [
        {
          to: token, value: '0', functionName: 'approve', args: [pool, wei.toString()],
          description: `Approve ${amount} ${symbol} for the lending pool`,
          data: encodeFunctionData({ abi: erc20Abi, functionName: 'approve', args: [pool, wei] }),
        },
        {
          to: pool, value: '0', functionName: 'supply', args: [token, wei.toString(), owner, '0'],
          description: `Supply ${amount} ${symbol} as collateral`,
          data: encodeFunctionData({ abi: poolAbi, functionName: 'supply', args: [token, wei, owner, 0] }),
        },
      ];
    },

    async simulate({ owner, token, amount, decimals, txs }): Promise<Simulation> {
      const c = publicClient();
      const pool = e.AAVE_POOL as Address;
      const [bal, allow] = await c.multicall({
        contracts: [
          { address: token, abi: erc20Abi, functionName: 'balanceOf', args: [owner] },
          { address: token, abi: erc20Abi, functionName: 'allowance', args: [owner, pool] },
        ],
        allowFailure: false,
      });
      const need = parseUnits(amount.toFixed(Math.min(decimals, 12)), decimals);
      const balance = Number(formatUnits(bal, decimals));
      const allowance = Number(formatUnits(allow, decimals));
      if (bal < need) return { ok: false, balance, allowance, message: `Wallet holds ${balance} — not enough to cover ${amount}.` };
      try {
        if (allow >= need) {
          await c.call({ account: owner, to: txs[1].to, data: txs[1].data });
          return { ok: true, balance, allowance, message: 'Simulation passed: allowance is already sufficient, the approve step can be skipped.' };
        }
        await c.call({ account: owner, to: txs[0].to, data: txs[0].data });
        return { ok: true, balance, allowance, message: 'Approve simulates cleanly. The second step is simulated by your wallet after the approval lands.' };
      } catch (err) {
        return { ok: false, balance, allowance, message: `Simulation reverted: ${(err as Error).message.split('\n')[0]}` };
      }
    },
  };
}
