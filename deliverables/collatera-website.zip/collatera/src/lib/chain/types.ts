import type { RawPosition } from '@/lib/risk/types';

export type Address = `0x${string}`;

export interface TxRequest {
  to: Address;
  data: `0x${string}`;
  value: string;
  /** Human description, e.g. "Approve 820 USDC for the Pool" */
  description: string;
  functionName: string;
  args: string[];
}

export interface Simulation {
  ok: boolean;
  balance: number | null;
  allowance: number | null;
  message: string;
}

export interface LendingMarketAdapter {
  id: string;
  name: string;
  chainId: number;
  /** All open positions for an owner (Aave v3 has at most one per market). */
  findPositions(owner: Address): Promise<RawPosition[]>;
  buildRepayTx(p: { owner: Address; token: Address; amount: number; decimals: number; symbol: string }): Promise<TxRequest[]>;
  buildSupplyTx(p: { owner: Address; token: Address; amount: number; decimals: number; symbol: string }): Promise<TxRequest[]>;
  simulate(p: { owner: Address; token: Address; amount: number; decimals: number; txs: TxRequest[] }): Promise<Simulation>;
}
