'use client';

import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useState } from 'react';
import { createConfig, http, WagmiProvider } from 'wagmi';
import { arbitrum, base, mainnet, optimism, polygon, sepolia } from 'wagmi/chains';
import { injected } from 'wagmi/connectors';

// Signing only: COLLATERA never needs a wallet to read data. Injected wallets
// (MetaMask, Rabby, Coinbase extension, …) cover the v1 use case without a
// WalletConnect project id.
export const wagmiConfig = createConfig({
  chains: [mainnet, base, arbitrum, optimism, polygon, sepolia],
  connectors: [injected()],
  transports: {
    [mainnet.id]: http(), [base.id]: http(), [arbitrum.id]: http(),
    [optimism.id]: http(), [polygon.id]: http(), [sepolia.id]: http(),
  },
  ssr: true,
});

export function WalletProviders({ children }: { children: React.ReactNode }) {
  const [client] = useState(() => new QueryClient());
  return (
    <WagmiProvider config={wagmiConfig}>
      <QueryClientProvider client={client}>{children}</QueryClientProvider>
    </WagmiProvider>
  );
}
