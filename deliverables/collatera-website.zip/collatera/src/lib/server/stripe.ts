// Minimal Stripe integration over the REST API (no SDK): Checkout, Portal, webhook.
import { createHmac } from 'node:crypto';
import { env } from './env';
import { safeEqual } from './crypto';
import { HttpError } from './http';

async function stripe(path: string, params: Record<string, string>) {
  const key = env().STRIPE_SECRET_KEY;
  if (!key) throw new HttpError('Billing is not configured on this server (set STRIPE_SECRET_KEY).', 501);
  const res = await fetch(`https://api.stripe.com/v1/${path}`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams(params),
  });
  const data = await res.json();
  if (!res.ok) throw new HttpError(data?.error?.message ?? 'Stripe error', 502);
  return data;
}

export async function createCheckout(user: { id: string; email: string }, customerId?: string | null) {
  const e = env();
  if (!e.STRIPE_PRICE_PRO) throw new HttpError('Set STRIPE_PRICE_PRO to enable checkout.', 501);
  const params: Record<string, string> = {
    mode: 'subscription',
    'line_items[0][price]': e.STRIPE_PRICE_PRO,
    'line_items[0][quantity]': '1',
    success_url: `${e.APP_URL}/account?billing=success`,
    cancel_url: `${e.APP_URL}/pricing`,
    client_reference_id: user.id,
  };
  if (customerId) params.customer = customerId;
  else params.customer_email = user.email;
  return stripe('checkout/sessions', params) as Promise<{ url: string }>;
}

export async function createPortal(customerId: string) {
  return stripe('billing_portal/sessions', { customer: customerId, return_url: `${env().APP_URL}/account` }) as Promise<{ url: string }>;
}

/** Verifies the Stripe-Signature header (v1 scheme, 5-minute tolerance). */
export function verifyWebhook(payload: string, header: string | null): boolean {
  const secret = env().STRIPE_WEBHOOK_SECRET;
  if (!secret || !header) return false;
  const parts = Object.fromEntries(header.split(',').map((kv) => kv.split('=') as [string, string]));
  const t = Number(parts.t);
  if (!t || Math.abs(Date.now() / 1000 - t) > 300) return false;
  const expected = createHmac('sha256', secret).update(`${t}.${payload}`).digest('hex');
  return header.split(',').filter((kv) => kv.startsWith('v1=')).some((kv) => safeEqual(kv.slice(3), expected));
}
