import { z } from 'zod';

const opt = z.string().optional().transform((v) => (v && v.trim() ? v.trim() : undefined));

const schema = z.object({
  DATABASE_URL: z.string().default('file:./dev.db'),
  APP_URL: z.string().default('http://localhost:3000'),
  SESSION_SECRET: z.string().default('dev-only-secret-change-me'),
  MARKET_MODE: z.enum(['demo', 'aave']).default('demo'),
  CHAIN_ID: z.coerce.number().int().default(1),
  RPC_URL: opt,
  AAVE_POOL: opt,
  AAVE_DATA_PROVIDER: opt,
  AAVE_ORACLE: opt,
  AAVE_MARKET_NAME: z.string().default('Aave v3'),
  RESEND_API_KEY: opt,
  EMAIL_FROM: z.string().default('COLLATERA <alerts@example.com>'),
  TELEGRAM_BOT_TOKEN: opt,
  TELEGRAM_BOT_USERNAME: opt,
  TELEGRAM_MODE: z.enum(['poll', 'webhook']).default('poll'),
  TELEGRAM_WEBHOOK_SECRET: opt,
  NEXT_PUBLIC_VAPID_PUBLIC_KEY: opt,
  VAPID_PRIVATE_KEY: opt,
  VAPID_SUBJECT: z.string().default('mailto:alerts@example.com'),
  STRIPE_SECRET_KEY: opt,
  STRIPE_WEBHOOK_SECRET: opt,
  STRIPE_PRICE_PRO: opt,
  ADMIN_EMAILS: z.string().default(''),
});

export type Env = z.infer<typeof schema>;

let cached: Env | null = null;
export function env(): Env {
  if (!cached) cached = schema.parse(process.env);
  return cached;
}

export function isAdmin(email: string): boolean {
  return env().ADMIN_EMAILS.split(',').map((s) => s.trim().toLowerCase()).filter(Boolean).includes(email.toLowerCase());
}
