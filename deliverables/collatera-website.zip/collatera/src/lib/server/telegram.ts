import { db } from './db';
import { sendTelegram } from './notify';

interface TgUpdate { update_id: number; message?: { chat: { id: number }; text?: string } }

/** Handles `/start <code>` deep links that connect a chat to a COLLATERA account. */
export async function handleTelegramUpdate(u: TgUpdate): Promise<void> {
  const text = u.message?.text?.trim();
  const chatId = u.message?.chat.id;
  if (!text || chatId == null) return;
  const m = text.match(/^\/start\s+([A-Za-z0-9_-]{6,64})$/);
  if (m) {
    const user = await db.user.findUnique({ where: { telegramCode: m[1] } });
    if (!user) {
      await sendTelegram(String(chatId), 'That link has expired. Open COLLATERA → Alerts and press "Connect Telegram" again.');
      return;
    }
    await db.user.update({ where: { id: user.id }, data: { telegramChatId: String(chatId), telegramCode: null } });
    await sendTelegram(String(chatId), `Connected to COLLATERA as ${user.email}. You'll get position alerts here. Send /stop to disconnect.`);
    return;
  }
  if (text === '/stop') {
    await db.user.updateMany({ where: { telegramChatId: String(chatId) }, data: { telegramChatId: null } });
    await sendTelegram(String(chatId), 'Disconnected. You will no longer receive COLLATERA alerts here.');
  }
}
