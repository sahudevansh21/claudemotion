// Turns scored positions into alert events for a user's rules, with
// de-duplication (6h per rule+position+reason unless severity worsens) and quiet hours.
import type { AlertRule, User } from '@prisma/client';
import { fmtAmount, fmtHf, pct } from '@/lib/risk/engine';
import type { ScoredPosition } from '@/lib/risk/types';
import { db } from './db';
import { deliverAlert } from './notify';

const DEDUPE_MS = 6 * 3600_000;
const SEV_RANK = { info: 0, watch: 1, risk: 2 } as const;
type Severity = keyof typeof SEV_RANK;

export interface Candidate {
  rule: AlertRule;
  positionId: string;
  dedupeKey: string;
  severity: Severity;
  title: string;
  whatChanged: string;
  whyItMatters: string;
  whatToDo: string;
  /** once-only alerts (issuer events) never repeat */
  once?: boolean;
}

function todo(p: ScoredPosition): string {
  if (p.plan.repay) return `Repay about ${fmtAmount(p.plan.repay.amount, p.plan.repay.symbol)} or add collateral to get back to HF ${p.plan.targetHf}. Open the planner to preview — nothing runs until you sign.`;
  return 'Review the position and consider whether to reduce debt.';
}

export function evaluate(rules: AlertRule[], p: ScoredPosition, prevJson: string | null, now = new Date()): Candidate[] {
  const out: Candidate[] = [];
  const hasDebt = p.debtUsd > 0;
  const prev = prevJson ? (JSON.parse(prevJson) as ScoredPosition) : null;
  const label = `${p.collateral.map((c) => c.symbol).join(' + ')} position`;

  for (const rule of rules) {
    if (!rule.enabled) continue;
    if (rule.address && rule.address.toLowerCase() !== p.owner) continue;
    const base = { rule, positionId: p.id };

    if (rule.kind === 'buffer_below' && hasDebt) {
      const t = rule.threshold ?? 0.15;
      if (p.effectiveBuffer < t) {
        out.push({
          ...base,
          dedupeKey: `${rule.id}:${p.id}:buffer`,
          severity: p.badge === 'risk' ? 'risk' : 'watch',
          title: `${label}: buffer down to ${pct(Math.max(p.effectiveBuffer, 0), 0)}`,
          whatChanged: `Effective buffer is ${pct(p.effectiveBuffer)} (your alert is ${pct(t, 0)}); health factor ${fmtHf(p.healthFactor)}.`,
          whyItMatters: p.explanation.whyItMatters,
          whatToDo: todo(p),
        });
      }
    }

    if (rule.kind === 'feed_stale') {
      for (const f of p.feeds.filter((x) => x.state !== 'fresh')) {
        out.push({
          ...base,
          dedupeKey: `${rule.id}:${p.id}:feed:${f.symbol}`,
          severity: f.state === 'critical' ? 'risk' : 'watch',
          title: `${f.symbol} price feed is ${f.state}`,
          whatChanged: f.ageSec == null ? `The ${f.symbol} oracle did not respond.` : `Last update ${Math.round(f.ageSec / 60)} min ago; expected every ${Math.round(f.heartbeatSec / 60)} min.`,
          whyItMatters: 'The on-chain price may not match the real market, so your true buffer may be smaller than shown.',
          whatToDo: hasDebt ? 'Treat the buffer as thinner than displayed until the feed updates. ' + todo(p) : 'No debt on this position, so no action is required.',
        });
      }
    }

    if (rule.kind === 'issuer_event') {
      const fresh = now.getTime() - 72 * 3600_000;
      for (const e of p.issuerEvents.filter((x) => (x.kind === 'pause' && x.active) || new Date(x.occurredAt).getTime() >= fresh)) {
        out.push({
          ...base,
          once: true,
          dedupeKey: `${rule.id}:${p.id}:issuer:${e.asset}:${e.kind}:${e.occurredAt}`,
          severity: e.kind === 'pause' && e.active ? 'risk' : 'watch',
          title: `Issuer event on ${e.asset}: ${e.kind.replace('_', ' ')}`,
          whatChanged: e.description,
          whyItMatters: e.kind === 'pause' ? 'A paused token may not be transferable or redeemable.' : 'Corporate actions and redemption changes can move the token price or its liquidity.',
          whatToDo: hasDebt ? todo(p) : 'Keep an eye on the position.',
        });
      }
    }

    if (rule.kind === 'market_transition' && hasDebt) {
      const t = rule.threshold ?? 0.25;
      if (p.buffer < t) {
        for (const m of p.markets) {
          if (m.open && m.minutesToClose != null && m.minutesToClose <= 60) {
            out.push({
              ...base,
              dedupeKey: `${rule.id}:${p.id}:close:${m.exchange}:${m.nextClose}`,
              severity: 'watch',
              title: `${m.name} closes in ${m.minutesToClose} min — buffer ${pct(p.buffer, 0)}`,
              whatChanged: `${m.name} closes soon and your buffer is below ${pct(t, 0)}.`,
              whyItMatters: 'Overnight and weekend, tokenized shares trade thinly and the price can gap at the next open.',
              whatToDo: todo(p),
            });
          }
          const wasClosed = prev?.markets?.find((x) => x.exchange === m.exchange && !x.open);
          if (m.open && wasClosed) {
            out.push({
              ...base,
              dedupeKey: `${rule.id}:${p.id}:open:${m.exchange}:${m.nextClose}`,
              severity: p.badge === 'risk' ? 'risk' : 'watch',
              title: `${m.name} just opened — buffer ${pct(p.buffer, 0)}`,
              whatChanged: `The underlying market reopened. Health factor is now ${fmtHf(p.healthFactor)}.`,
              whyItMatters: 'Opening prices can gap; check the position now that liquidity is back.',
              whatToDo: todo(p),
            });
          }
        }
      }
    }
  }
  return out;
}

function inQuietHours(user: User, now: Date): boolean {
  if (user.quietStart == null || user.quietEnd == null) return false;
  const h = (((now.getUTCHours() * 60 + now.getUTCMinutes() + user.tzOffsetMin) / 60) % 24 + 24) % 24;
  const s = user.quietStart;
  const e = user.quietEnd;
  return s <= e ? h >= s && h < e : h >= s || h < e;
}

/** Persist and deliver the candidates that pass de-duplication. Returns how many fired. */
export async function fire(user: User, candidates: Candidate[], now = new Date()): Promise<number> {
  let fired = 0;
  for (const c of candidates) {
    if (c.severity !== 'risk' && inQuietHours(user, now)) continue;
    const last = await db.alertEvent.findFirst({ where: { dedupeKey: c.dedupeKey }, orderBy: { createdAt: 'desc' } });
    if (last) {
      if (c.once) continue;
      const recent = now.getTime() - last.createdAt.getTime() < DEDUPE_MS;
      const worse = SEV_RANK[c.severity] > SEV_RANK[last.severity as Severity];
      if (recent && !worse) continue;
    }
    const ev = await db.alertEvent.create({
      data: {
        ruleId: c.rule.id, positionId: c.positionId, dedupeKey: c.dedupeKey, severity: c.severity,
        title: c.title, whatChanged: c.whatChanged, whyItMatters: c.whyItMatters, whatToDo: c.whatToDo,
      },
    });
    await deliverAlert(ev.id);
    fired++;
  }
  return fired;
}
