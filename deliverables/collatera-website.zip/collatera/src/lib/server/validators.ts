import { isAddress } from 'viem';
import { z } from 'zod';

export const addressSchema = z
  .string()
  .trim()
  .refine((v) => isAddress(v, { strict: false }), 'Not a valid 0x wallet address')
  .transform((v) => v.toLowerCase());

export const targetHfSchema = z.coerce.number().min(1.05).max(5).default(1.5);
