// Notification channels. Every channel degrades to a console log when its keys
// are missing, so local development never needs third-party accounts.
import webpush from 'web-push';
import { db } from './db';
import { env } from './env';

export type DeliveryResult = { status: 'sent' | 'logged' | 'failed'; error?: string };

export async function sendEmail(to: string, subject: string, text: string, html?: string): Promise<DeliveryResult> {
  const e = env();
  if (!e.RESEND_API_KEY) {
    console.log(`\n[email:dev] to=${to}\nsubject: ${subject}\n${text}\n`);
    return { status: 'logged' };
  }
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${e.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: e.EMAIL_FROM, to, subject, text, html }),
  });
  if (!res.ok) return { status: 'failed', error: `Resend ${res.status}: ${await res.text()}` };
  return { status: 'sent' };
}

export async function sendTelegram(chatId: string, text: string): Promise<DeliveryResult> {
  const token = env().TELEGRAM_BOT_TOKEN;
  if (!token) {
    console.log(`[telegram:dev] chat=${chatId}\n${text}`);
    return { status: 'logged' };
  }
  const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ chat_id: chatId, text, disable_web_page_preview: true }),
  });
  if (!res.ok) return { status: 'failed', error: `Telegram ${res.status}: ${await res.text()}` };
  return { status: 'sent' };
}

let vapidReady = false;
function vapid(): boolean {
  const e = env();
  if (!e.NEXT_PUBLIC_VAPID_PUBLIC_KEY || !e.VAPID_PRIVATE_KEY) return false;
  if (!vapidReady) {
    webpush.setVapidDetails(e.VAPID_SUBJECT, e.NEXT_PUBLIC_VAPID_PUBLIC_KEY, e.VAPID_PRIVATE_KEY);
    vapidReady = true;
  }
  return true;
}

export async function sendPush(userId: string, payload: { title: string; body: string; url: string }): Promise<DeliveryResult> {
  const subs = await db.pushSubscription.findMany({ where: { userId } });
  if (!subs.length) return { status: 'failed', error: 'No push subscription' };
  if (!vapid()) {
    console.log(`[push:dev] user=${userId} ${payload.title} — ${payload.body}`);
    return { status: 'logged' };
  }
  const errors: string[] = [];
  for (const s of subs) {
    try {
      await webpush.sendNotification({ endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } }, JSON.stringify(payload));
    } catch (err) {
      const code = (err as { statusCode?: number }).statusCode;
      if (code === 404 || code === 410) await db.pushSubscription.delete({ where: { id: s.id } }).catch(() => {});
      errors.push(String(code ?? (err as Error).message));
    }
  }
  return errors.length === subs.length ? { status: 'failed', error: errors.join(', ') } : { status: 'sent' };
}

/** Retry with exponential backoff (1s, 2s, 4s, 8s) — 5 attempts total. */
export async function withRetry(fn: () => Promise<DeliveryResult>, attempts = 5): Promise<DeliveryResult & { attempts: number }> {
  let last: DeliveryResult = { status: 'failed', error: 'not attempted' };
  for (let i = 0; i < attempts; i++) {
    try {
      last = await fn();
    } catch (err) {
      last = { status: 'failed', error: (err as Error).message };
    }
    if (last.status !== 'failed') return { ...last, attempts: i + 1 };
    if (last.error === 'No push subscription') return { ...last, attempts: i + 1 };
    await new Promise((r) => setTimeout(r, 1000 * 2 ** i));
  }
  return { ...last, attempts };
}

/** Fan an alert out to every channel the user has set up and record each delivery. */
export async function deliverAlert(alertEventId: string): Promise<void> {
  const ev = await db.alertEvent.findUnique({ where: { id: alertEventId }, include: { rule: { include: { user: true } } } });
  if (!ev) return;
  const user = ev.rule.user;
  const url = `${env().APP_URL}${ev.positionId ? `/positions/${encodeURIComponent(ev.positionId)}` : '/alerts'}`;
  const text = `${ev.title}\n\nWhat changed: ${ev.whatChanged}\nWhy it matters: ${ev.whyItMatters}\nWhat to do: ${ev.whatToDo}\n\n${url}\n\nCOLLATERA is read-only and never moves funds. Data can lag or fail.`;

  const jobs: [string, () => Promise<DeliveryResult>][] = [
    ['email', () => sendEmail(user.email, `[COLLATERA] ${ev.title}`, text)],
  ];
  if (user.telegramChatId) jobs.push(['telegram', () => sendTelegram(user.telegramChatId!, text)]);
  jobs.push(['push', () => sendPush(user.id, { title: ev.title, body: ev.whatChanged, url })]);

  for (const [channel, fn] of jobs) {
    const r = await withRetry(fn);
    if (channel === 'push' && r.error === 'No push subscription') continue;
    await db.notificationDelivery.create({
      data: { alertEventId: ev.id, channel, status: r.status, error: r.error, attempts: r.attempts },
    });
  }
}
