import { scorePosition } from '@/lib/risk/engine';
import type { IssuerEventLite, ScoredPosition } from '@/lib/risk/types';
import { adapterFor, parsePositionId } from '@/lib/chain';
import type { Address } from '@/lib/chain/types';
import { db } from './db';

/** JSON can't carry Infinity; "no debt" health factors travel as 1e9. */
export const INF = 1e9;
export function serialize<T>(x: T): T {
  return JSON.parse(JSON.stringify(x, (_k, v) => (v === Infinity ? INF : v)));
}

const cache = new Map<string, { at: number; data: ScoredPosition[] }>();
const TTL = 15_000;

export async function issuerEventsLite(): Promise<IssuerEventLite[]> {
  const since = new Date(Date.now() - 30 * 86_400_000);
  const rows = await db.issuerEvent.findMany({
    where: { OR: [{ active: true, kind: 'pause' }, { occurredAt: { gte: since } }] },
    orderBy: { occurredAt: 'desc' },
    take: 200,
  });
  return rows.map((r) => ({ asset: r.asset, kind: r.kind, description: r.description, active: r.active, occurredAt: r.occurredAt.toISOString() }));
}

export async function scanAddress(address: string, opts: { fresh?: boolean; targetHf?: number } = {}): Promise<ScoredPosition[]> {
  const key = `${address.toLowerCase()}:${opts.targetHf ?? ''}`;
  const hit = cache.get(key);
  if (!opts.fresh && hit && Date.now() - hit.at < TTL) return hit.data;
  const adapter = adapterFor(address);
  const [raw, events] = await Promise.all([adapter.findPositions(address.toLowerCase() as Address), issuerEventsLite()]);
  const data = raw.map((r) => scorePosition(r, { issuerEvents: events, targetHf: opts.targetHf }));
  cache.set(key, { at: Date.now(), data });
  if (cache.size > 5000) cache.clear();
  return data;
}

export async function getPosition(id: string, opts: { fresh?: boolean; targetHf?: number } = {}): Promise<ScoredPosition | null> {
  const parsed = parsePositionId(id);
  if (!parsed) return null;
  const list = await scanAddress(parsed.owner, opts);
  return list.find((p) => p.id === id) ?? null;
}

export async function persistSnapshot(p: ScoredPosition) {
  await db.position.upsert({ where: { id: p.id }, update: {}, create: { id: p.id, marketId: p.marketId, owner: p.owner } });
  return db.positionSnapshot.create({
    data: {
      positionId: p.id,
      healthFactor: Number.isFinite(p.healthFactor) ? p.healthFactor : INF,
      buffer: p.buffer,
      effectiveBuffer: p.effectiveBuffer,
      badge: p.badge,
      collateralUsd: p.collateralUsd,
      debtUsd: p.debtUsd,
      json: JSON.stringify(serialize(p)),
    },
  });
}

export async function previousSnapshot(positionId: string) {
  return db.positionSnapshot.findFirst({ where: { positionId }, orderBy: { createdAt: 'desc' } });
}

export async function history(positionId: string, days = 7) {
  const rows = await db.positionSnapshot.findMany({
    where: { positionId, createdAt: { gte: new Date(Date.now() - days * 86_400_000) } },
    orderBy: { createdAt: 'asc' },
    select: { createdAt: true, healthFactor: true, buffer: true, effectiveBuffer: true, badge: true },
  });
  // Thin to ≤ 300 points for the chart.
  const step = Math.max(1, Math.ceil(rows.length / 300));
  return rows.filter((_, i) => i % step === 0 || i === rows.length - 1).map((r) => ({ ...r, createdAt: r.createdAt.toISOString() }));
}
