import { NextResponse } from 'next/server';
import { ZodError, type z, type ZodTypeAny } from 'zod';
import { clientIp, rateLimit } from './rateLimit';

export function json(data: unknown, init?: number | ResponseInit) {
  return NextResponse.json(data, typeof init === 'number' ? { status: init } : init);
}

export function error(message: string, status = 400) {
  return NextResponse.json({ error: message }, { status });
}

export async function parseBody<S extends ZodTypeAny>(req: Request, schema: S): Promise<z.output<S>> {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    throw new HttpError('Request body must be JSON', 400);
  }
  return schema.parse(body);
}

export class HttpError extends Error {
  constructor(message: string, public status = 400) {
    super(message);
  }
}

/** Wraps a route handler: rate limit, zod + HttpError → JSON errors. */
export function route<A extends unknown[]>(
  handler: (req: Request, ...rest: A) => Promise<Response>,
  opts: { limit?: number } = {},
) {
  return async (req: Request, ...rest: A): Promise<Response> => {
    if (opts.limit && !rateLimit(`${new URL(req.url).pathname}:${clientIp(req)}`, opts.limit)) {
      return error('Too many requests — slow down a little.', 429);
    }
    try {
      return await handler(req, ...rest);
    } catch (e) {
      if (e instanceof HttpError) return error(e.message, e.status);
      if (e instanceof ZodError) return error(e.issues.map((i) => `${i.path.join('.') || 'input'}: ${i.message}`).join('; '), 422);
      console.error('[api]', e);
      return error((e as Error).message || 'Unexpected error', 500);
    }
  };
}

/** Never accept anything that looks like a private key or seed phrase. */
export function rejectSecrets(value: string) {
  const v = value.trim();
  if (/^(0x)?[0-9a-fA-F]{64}$/.test(v) || v.split(/\s+/).length >= 12) {
    throw new HttpError('That looks like a private key or seed phrase. Never paste those anywhere — COLLATERA only needs a public wallet address.', 400);
  }
}
