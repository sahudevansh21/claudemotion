import { cookies } from 'next/headers';
import { db } from './db';
import { env } from './env';
import { HttpError } from './http';
import { randomToken, sha256 } from './crypto';
import { sendEmail } from './notify';

export const SESSION_COOKIE = 'coll_session';
const SESSION_DAYS = 30;

export async function requestLogin(email: string, next = '/dashboard'): Promise<{ devLink?: string }> {
  const token = randomToken();
  await db.loginToken.create({ data: { id: sha256(token), email: email.toLowerCase(), expiresAt: new Date(Date.now() + 15 * 60_000) } });
  const safeNext = next.startsWith('/') && !next.startsWith('//') ? next : '/dashboard';
  const link = `${env().APP_URL}/api/auth/verify?token=${token}&next=${encodeURIComponent(safeNext)}`;
  const r = await sendEmail(
    email,
    'Your COLLATERA sign-in link',
    `Sign in to COLLATERA:\n\n${link}\n\nThe link works once and expires in 15 minutes. If you didn't ask for it, ignore this email.`,
  );
  // Without an email provider on a local URL, hand the link back so the flow is testable.
  const local = /^http:\/\/(localhost|127\.0\.0\.1)(:|\/|$)/.test(env().APP_URL);
  return r.status === 'logged' && (local || process.env.NODE_ENV !== 'production') ? { devLink: link } : {};
}

export async function verifyLogin(token: string): Promise<string> {
  const row = await db.loginToken.findUnique({ where: { id: sha256(token) } });
  if (!row || row.usedAt || row.expiresAt < new Date()) throw new HttpError('This sign-in link is invalid or has expired.', 400);
  await db.loginToken.update({ where: { id: row.id }, data: { usedAt: new Date() } });
  const user = await db.user.upsert({ where: { email: row.email }, update: {}, create: { email: row.email } });
  // Default alert rules for new users.
  const count = await db.alertRule.count({ where: { userId: user.id } });
  if (!count) {
    await db.alertRule.createMany({
      data: [
        { userId: user.id, kind: 'buffer_below', threshold: 0.15 },
        { userId: user.id, kind: 'feed_stale' },
        { userId: user.id, kind: 'issuer_event' },
        { userId: user.id, kind: 'market_transition', threshold: 0.25 },
      ],
    });
  }
  const sessionToken = randomToken();
  await db.session.create({ data: { id: sha256(sessionToken), userId: user.id, expiresAt: new Date(Date.now() + SESSION_DAYS * 86_400_000) } });
  return sessionToken;
}

export function sessionCookie(token: string) {
  return {
    name: SESSION_COOKIE,
    value: token,
    httpOnly: true,
    sameSite: 'lax' as const,
    secure: env().APP_URL.startsWith('https://'),
    path: '/',
    maxAge: SESSION_DAYS * 86_400,
  };
}

export async function currentUser() {
  const token = cookies().get(SESSION_COOKIE)?.value;
  if (!token) return null;
  const session = await db.session.findUnique({ where: { id: sha256(token) }, include: { user: true } });
  if (!session || session.expiresAt < new Date()) return null;
  return session.user;
}

export async function requireUser() {
  const user = await currentUser();
  if (!user) throw new HttpError('Sign in to use this feature.', 401);
  return user;
}

export async function logout() {
  const token = cookies().get(SESSION_COOKIE)?.value;
  if (token) await db.session.deleteMany({ where: { id: sha256(token) } });
}

/** CSRF guard for cookie-authenticated mutations: the Origin must be our own. */
export function requireSameOrigin(req: Request) {
  const origin = req.headers.get('origin');
  if (!origin) return; // non-browser clients (curl, server-to-server) carry no cookies by default
  const host = req.headers.get('x-forwarded-host') ?? req.headers.get('host');
  if (new URL(origin).host !== host) throw new HttpError('Cross-site request blocked.', 403);
}
