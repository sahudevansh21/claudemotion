import type { ExchangeId, MarketStatus } from './calendar';

export type Badge = 'safe' | 'watch' | 'risk';
export type FeedState = 'fresh' | 'stale' | 'critical';

export interface OracleInfo {
  feed: string | null;
  /** unix seconds of the last oracle update; null if unknown */
  updatedAt: number | null;
  heartbeatSec: number;
  /** true when the feed call reverted */
  failed?: boolean;
}

export interface CollateralLeg {
  symbol: string;
  token: string;
  decimals: number;
  /** token units (human, not wei) */
  amount: number;
  /** USD per token, from the market oracle */
  price: number;
  /** liquidation threshold as a fraction, e.g. 0.75 */
  liquidationThreshold: number;
  /** true for tokenized stocks / ETFs in the registry */
  tokenized: boolean;
  underlying?: string;
  exchange?: ExchangeId;
  issuer?: string;
  /** extra buffer haircut while the underlying exchange is closed (fraction) */
  gapHaircut?: number;
  oracle: OracleInfo;
}

export interface DebtLeg {
  symbol: string;
  token: string;
  decimals: number;
  amount: number;
  price: number;
}

export interface RawPosition {
  id: string;
  marketId: string;
  marketName: string;
  chainId: number;
  owner: string;
  collateral: CollateralLeg[];
  debt: DebtLeg[];
  /** collateral symbols that are not tokenized assets COLLATERA supports */
  unsupported: string[];
  demo: boolean;
  /** health factor reported by the protocol itself, when available (cross-check) */
  protocolHealthFactor?: number;
}

export interface IssuerEventLite {
  asset: string;
  kind: string;
  description: string;
  active: boolean;
  occurredAt: string;
}

export interface FeedCheck {
  symbol: string;
  feed: string | null;
  ageSec: number | null;
  heartbeatSec: number;
  state: FeedState;
}

export interface Explanation {
  headline: string;
  whatChanged: string;
  whyItMatters: string;
  whatToDo: string;
}

export interface TargetPlan {
  targetHf: number;
  repay: { symbol: string; token: string; amount: number; usd: number; capped: boolean } | null;
  add: { symbol: string; token: string; amount: number; usd: number }[];
}

export interface ScoredPosition extends RawPosition {
  collateralUsd: number;
  weightedCollateralUsd: number;
  debtUsd: number;
  healthFactor: number;
  buffer: number;
  effectiveBuffer: number;
  liquidationPrices: Record<string, number | null>;
  feeds: FeedCheck[];
  worstFeed: FeedState;
  markets: MarketStatus[];
  marketClosed: boolean;
  issuerEvents: IssuerEventLite[];
  badge: Badge;
  reasons: string[];
  explanation: Explanation;
  plan: TargetPlan;
  scoredAt: string;
}
