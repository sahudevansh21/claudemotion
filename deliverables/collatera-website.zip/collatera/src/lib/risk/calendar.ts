// Exchange calendar for the US equity venues that tokenized stocks/ETFs track.
// Regular session 09:30–16:00 America/New_York, 13:00 close on early-close days.
// Holiday lists must be re-checked against the official NYSE calendar each year.

export type ExchangeId = 'XNYS' | 'XNAS';

export const EXCHANGE_NAMES: Record<ExchangeId, string> = {
  XNYS: 'NYSE',
  XNAS: 'Nasdaq',
};

const TZ = 'America/New_York';

/** Full-day closures (NYSE and Nasdaq share them). */
export const HOLIDAYS = new Set<string>([
  // 2025
  '2025-01-01', '2025-01-09', '2025-01-20', '2025-02-17', '2025-04-18', '2025-05-26',
  '2025-06-19', '2025-07-04', '2025-09-01', '2025-11-27', '2025-12-25',
  // 2026
  '2026-01-01', '2026-01-19', '2026-02-16', '2026-04-03', '2026-05-25', '2026-06-19',
  '2026-07-03', '2026-09-07', '2026-11-26', '2026-12-25',
  // 2027
  '2027-01-01', '2027-01-18', '2027-02-15', '2027-03-26', '2027-05-31', '2027-06-18',
  '2027-07-05', '2027-09-06', '2027-11-25', '2027-12-24',
]);

/** 13:00 ET closes. */
export const EARLY_CLOSES = new Set<string>([
  '2025-07-03', '2025-11-28', '2025-12-24',
  '2026-11-27', '2026-12-24',
  '2027-11-26',
]);

const OPEN_MIN = 9 * 60 + 30;
const CLOSE_MIN = 16 * 60;
const EARLY_CLOSE_MIN = 13 * 60;

interface NyParts { date: string; weekday: number; minutes: number }

const partsFmt = new Intl.DateTimeFormat('en-US', {
  timeZone: TZ, year: 'numeric', month: '2-digit', day: '2-digit',
  hour: '2-digit', minute: '2-digit', hourCycle: 'h23', weekday: 'short',
});
const WEEKDAYS: Record<string, number> = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };

export function nyParts(at: Date): NyParts {
  const p: Record<string, string> = {};
  for (const { type, value } of partsFmt.formatToParts(at)) p[type] = value;
  return {
    date: `${p.year}-${p.month}-${p.day}`,
    weekday: WEEKDAYS[p.weekday],
    minutes: Number(p.hour) * 60 + Number(p.minute),
  };
}

/** UTC instant for a New York wall-clock time (DST-safe: converges in 2 steps). */
export function nyToUtc(date: string, minutes: number): Date {
  const [y, m, d] = date.split('-').map(Number);
  const wall = Date.UTC(y, m - 1, d, Math.floor(minutes / 60), minutes % 60);
  let guess = wall;
  for (let i = 0; i < 3; i++) {
    const p = nyParts(new Date(guess));
    const [py, pm, pd] = p.date.split('-').map(Number);
    const seen = Date.UTC(py, pm - 1, pd, Math.floor(p.minutes / 60), p.minutes % 60);
    const diff = wall - seen;
    if (diff === 0) break;
    guess += diff;
  }
  return new Date(guess);
}

function addDays(date: string, n: number): string {
  const [y, m, d] = date.split('-').map(Number);
  const t = new Date(Date.UTC(y, m - 1, d + n));
  return t.toISOString().slice(0, 10);
}

function weekdayOf(date: string): number {
  const [y, m, d] = date.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d)).getUTCDay();
}

export function sessionFor(date: string): { open: number; close: number } | null {
  const wd = weekdayOf(date);
  if (wd === 0 || wd === 6 || HOLIDAYS.has(date)) return null;
  return { open: OPEN_MIN, close: EARLY_CLOSES.has(date) ? EARLY_CLOSE_MIN : CLOSE_MIN };
}

export interface MarketStatus {
  exchange: ExchangeId;
  name: string;
  open: boolean;
  /** Next session open (when closed) */
  nextOpen: string;
  /** Close of the current session (when open) or of the next session (when closed) */
  nextClose: string;
  minutesToClose: number | null;
  minutesToOpen: number | null;
  earlyClose: boolean;
  label: string;
}

export function marketStatus(exchange: ExchangeId, now: Date = new Date()): MarketStatus {
  const p = nyParts(now);
  const today = sessionFor(p.date);
  const name = EXCHANGE_NAMES[exchange];

  if (today && p.minutes >= today.open && p.minutes < today.close) {
    const close = nyToUtc(p.date, today.close);
    const mins = Math.round((close.getTime() - now.getTime()) / 60000);
    let date = addDays(p.date, 1);
    let s = sessionFor(date);
    while (!s) { date = addDays(date, 1); s = sessionFor(date); }
    return {
      exchange, name, open: true,
      nextOpen: nyToUtc(date, s.open).toISOString(),
      nextClose: close.toISOString(),
      minutesToClose: mins, minutesToOpen: null,
      earlyClose: today.close === EARLY_CLOSE_MIN,
      label: `${name} open — closes in ${fmtDuration(mins)}`,
    };
  }

  // Closed: find the next session start (today if before the open).
  let date = p.date;
  let s = today && p.minutes < today.open ? today : null;
  if (!s) {
    date = addDays(p.date, 1);
    s = sessionFor(date);
    while (!s) { date = addDays(date, 1); s = sessionFor(date); }
  }
  const open = nyToUtc(date, s.open);
  const mins = Math.round((open.getTime() - now.getTime()) / 60000);
  return {
    exchange, name, open: false,
    nextOpen: open.toISOString(),
    nextClose: nyToUtc(date, s.close).toISOString(),
    minutesToClose: null, minutesToOpen: mins,
    earlyClose: s.close === EARLY_CLOSE_MIN,
    label: `${name} closed — opens ${fmtOpen(open)}`,
  };
}

export function fmtDuration(mins: number): string {
  if (mins < 60) return `${mins}m`;
  const h = Math.floor(mins / 60);
  if (h < 48) return `${h}h ${mins % 60}m`;
  return `${Math.floor(h / 24)}d ${h % 24}h`;
}

const openFmt = new Intl.DateTimeFormat('en-US', {
  timeZone: TZ, weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
});
export function fmtOpen(d: Date): string {
  return `${openFmt.format(d)} ET`;
}
