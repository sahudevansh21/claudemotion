// COLLATERA risk engine — pure functions, no I/O. Every number shown in the UI
// comes from here, and tests/engine.test.ts pins the maths down.

import { marketStatus, fmtDuration, type ExchangeId, type MarketStatus } from './calendar';
import type {
  Badge, CollateralLeg, DebtLeg, Explanation, FeedCheck, FeedState, IssuerEventLite,
  RawPosition, ScoredPosition, TargetPlan,
} from './types';

export const DEFAULTS = {
  targetHf: 1.5,
  /** fraction of the expected oracle interval tolerated before "stale" */
  staleTolerance: 1.1,
  /** multiple of the expected interval after which a feed is "critical" */
  criticalMultiple: 2,
  /** default extra haircut applied to the buffer while the underlying market is closed */
  gapHaircut: 0.08,
  riskHf: 1.1,
  riskBuffer: 0.1,
  watchBuffer: 0.25,
  closingSoonMin: 60,
  closingSoonBuffer: 0.3,
  issuerEventFreshHours: 72,
} as const;

export const NO_DEBT_HF = Number.POSITIVE_INFINITY;

const sum = (xs: number[]) => xs.reduce((a, b) => a + b, 0);

export function collateralUsd(c: CollateralLeg[]): number {
  return sum(c.map((l) => l.amount * l.price));
}
export function weightedCollateralUsd(c: CollateralLeg[]): number {
  return sum(c.map((l) => l.amount * l.price * l.liquidationThreshold));
}
export function debtUsd(d: DebtLeg[]): number {
  return sum(d.map((l) => l.amount * l.price));
}

/** HF = Σ(collateral × price × LT) ÷ debt. Infinity when there is no debt. */
export function healthFactor(weighted: number, debt: number): number {
  if (debt <= 0) return NO_DEBT_HF;
  return weighted / debt;
}

/** Fraction all collateral prices can fall before HF reaches 1: 1 − 1/HF. */
export function bufferFromHf(hf: number): number {
  if (!Number.isFinite(hf)) return 1;
  return 1 - 1 / hf; // negative when already below 1
}

/**
 * Price of one collateral asset at which HF = 1, holding everything else fixed.
 * null when that asset alone cannot trigger liquidation.
 */
export function liquidationPrice(c: CollateralLeg[], index: number, debt: number): number | null {
  if (debt <= 0) return null;
  const leg = c[index];
  const others = weightedCollateralUsd(c) - leg.amount * leg.price * leg.liquidationThreshold;
  const denom = leg.amount * leg.liquidationThreshold;
  if (denom <= 0) return null;
  const p = (debt - others) / denom;
  return p > 0 ? p : null;
}

export function feedState(o: CollateralLeg['oracle'], nowSec: number): FeedCheck['state'] {
  if (o.failed || o.updatedAt == null) return 'critical';
  const age = nowSec - o.updatedAt;
  if (age > o.heartbeatSec * DEFAULTS.criticalMultiple) return 'critical';
  if (age > o.heartbeatSec * DEFAULTS.staleTolerance) return 'stale';
  return 'fresh';
}

const FEED_RANK: Record<FeedState, number> = { fresh: 0, stale: 1, critical: 2 };

/** Amount to repay / collateral to add so HF reaches `target`. */
export function planToTarget(c: CollateralLeg[], d: DebtLeg[], target: number = DEFAULTS.targetHf): TargetPlan {
  const weighted = weightedCollateralUsd(c);
  const debt = debtUsd(d);
  const plan: TargetPlan = { targetHf: target, repay: null, add: [] };
  if (debt <= 0 || weighted / debt >= target) return plan;

  const repayUsd = Math.max(0, debt - weighted / target);
  const main = [...d].sort((a, b) => b.amount * b.price - a.amount * a.price)[0];
  if (main && main.price > 0) {
    const want = roundUp(repayUsd / main.price, main.decimals);
    const capped = want > main.amount;
    const amount = capped ? main.amount : want;
    plan.repay = { symbol: main.symbol, token: main.token, amount, usd: amount * main.price, capped };
  }
  const shortfall = target * debt - weighted;
  for (const leg of c) {
    if (leg.price <= 0 || leg.liquidationThreshold <= 0) continue;
    const amount = roundUp(shortfall / (leg.price * leg.liquidationThreshold), leg.decimals);
    plan.add.push({ symbol: leg.symbol, token: leg.token, amount, usd: amount * leg.price });
  }
  return plan;
}

/** Round up to at most 6 display decimals (never below the token's precision). */
export function roundUp(x: number, decimals: number): number {
  const dp = Math.min(decimals, 6);
  const f = 10 ** dp;
  return Math.ceil(x * f - 1e-9) / f;
}

export interface ScoreContext {
  now?: Date;
  issuerEvents?: IssuerEventLite[];
  targetHf?: number;
}

export function scorePosition(raw: RawPosition, ctx: ScoreContext = {}): ScoredPosition {
  const now = ctx.now ?? new Date();
  const nowSec = Math.floor(now.getTime() / 1000);
  const targetHf = ctx.targetHf ?? DEFAULTS.targetHf;

  const cUsd = collateralUsd(raw.collateral);
  const wUsd = weightedCollateralUsd(raw.collateral);
  const dUsd = debtUsd(raw.debt);
  const hf = healthFactor(wUsd, dUsd);
  const buffer = bufferFromHf(hf);

  const liquidationPrices: Record<string, number | null> = {};
  raw.collateral.forEach((leg, i) => {
    liquidationPrices[leg.symbol] = liquidationPrice(raw.collateral, i, dUsd);
  });

  // Freshness is tracked for tokenized collateral: those feeds follow an off-chain
  // market and are the ones that lag when the exchange is shut.
  const feeds: FeedCheck[] = raw.collateral.filter((leg) => leg.tokenized).map((leg) => ({
    symbol: leg.symbol,
    feed: leg.oracle.feed,
    ageSec: leg.oracle.updatedAt == null ? null : nowSec - leg.oracle.updatedAt,
    heartbeatSec: leg.oracle.heartbeatSec,
    state: feedState(leg.oracle, nowSec),
  }));
  const worstFeed = feeds.reduce<FeedState>((w, f) => (FEED_RANK[f.state] > FEED_RANK[w] ? f.state : w), 'fresh');

  const exchanges = Array.from(new Set(raw.collateral.filter((l) => l.tokenized && l.exchange).map((l) => l.exchange as ExchangeId)));
  const markets: MarketStatus[] = exchanges.map((x) => marketStatus(x, now));
  const marketClosed = markets.some((m) => !m.open);

  // Closed market: the largest haircut among tokenized legs, weighted by their share.
  let haircut = 0;
  if (marketClosed && cUsd > 0) {
    const closed = new Set(markets.filter((m) => !m.open).map((m) => m.exchange));
    for (const leg of raw.collateral) {
      if (leg.tokenized && leg.exchange && closed.has(leg.exchange)) {
        haircut += (leg.gapHaircut ?? DEFAULTS.gapHaircut) * ((leg.amount * leg.price) / cUsd);
      }
    }
  }
  const effectiveBuffer = Number.isFinite(hf) ? buffer - haircut : 1;

  const symbols = new Set(raw.collateral.map((l) => l.symbol));
  const issuerEvents = (ctx.issuerEvents ?? []).filter((e) => symbols.has(e.asset));
  const pauseActive = issuerEvents.some((e) => e.kind === 'pause' && e.active);
  const freshCutoff = now.getTime() - DEFAULTS.issuerEventFreshHours * 3600_000;
  const recentEvent = issuerEvents.some((e) => new Date(e.occurredAt).getTime() >= freshCutoff);
  const closingSoon = markets.some((m) => m.open && m.minutesToClose != null && m.minutesToClose <= DEFAULTS.closingSoonMin);

  const reasons: string[] = [];
  let badge: Badge = 'safe';
  if (Number.isFinite(hf)) {
    if (hf < DEFAULTS.riskHf) reasons.push(`Health factor ${hf.toFixed(2)} is below ${DEFAULTS.riskHf}`);
    else if (effectiveBuffer < DEFAULTS.riskBuffer) reasons.push(`Effective buffer ${pct(effectiveBuffer)} is below ${pct(DEFAULTS.riskBuffer)}`);
  }
  if (pauseActive) reasons.push('Issuer has paused a collateral token');
  if (reasons.length) badge = 'risk';
  else {
    if (Number.isFinite(hf) && effectiveBuffer < DEFAULTS.watchBuffer) reasons.push(`Effective buffer ${pct(effectiveBuffer)} is below ${pct(DEFAULTS.watchBuffer)}`);
    if (worstFeed !== 'fresh') reasons.push(`A price feed is ${worstFeed}`);
    if (recentEvent) reasons.push('Recent issuer event');
    if (closingSoon && Number.isFinite(hf) && buffer < DEFAULTS.closingSoonBuffer) reasons.push('Market closes soon while the buffer is thin');
    if (reasons.length) badge = 'watch';
  }

  const plan = planToTarget(raw.collateral, raw.debt, targetHf);
  const scored: ScoredPosition = {
    ...raw,
    collateralUsd: cUsd,
    weightedCollateralUsd: wUsd,
    debtUsd: dUsd,
    healthFactor: hf,
    buffer,
    effectiveBuffer,
    liquidationPrices,
    feeds,
    worstFeed,
    markets,
    marketClosed,
    issuerEvents,
    badge,
    reasons,
    explanation: { headline: '', whatChanged: '', whyItMatters: '', whatToDo: '' },
    plan,
    scoredAt: now.toISOString(),
  };
  scored.explanation = explain(scored);
  return scored;
}

// ---------------------------------------------------------------- stress

export type StressScenario =
  | { kind: 'drop'; shock: number }
  | { kind: 'gap'; shock: number }
  | { kind: 'oracle_delay'; shock: number; delayMin: number };

export interface StressResult {
  scenario: StressScenario;
  label: string;
  note: string;
  before: { healthFactor: number; buffer: number };
  after: { healthFactor: number; buffer: number; badge: Badge };
  liquidationPrices: Record<string, number | null>;
  stressedPrices: Record<string, number>;
  plan: TargetPlan;
}

/** Shock applies to tokenized (registry) collateral only; stablecoins etc. are held fixed. */
export function stress(raw: RawPosition, scenario: StressScenario, targetHf: number = DEFAULTS.targetHf): StressResult {
  const d = Math.min(Math.max(scenario.shock, 0), 0.99);
  const shocked: CollateralLeg[] = raw.collateral.map((l) => (l.tokenized ? { ...l, price: l.price * (1 - d) } : l));
  const dUsd = debtUsd(raw.debt);
  const hf0 = healthFactor(weightedCollateralUsd(raw.collateral), dUsd);
  const hf1 = healthFactor(weightedCollateralUsd(shocked), dUsd);
  const b1 = bufferFromHf(hf1);

  const liquidationPrices: Record<string, number | null> = {};
  const stressedPrices: Record<string, number> = {};
  shocked.forEach((leg, i) => {
    liquidationPrices[leg.symbol] = liquidationPrice(shocked, i, dUsd);
    stressedPrices[leg.symbol] = leg.price;
  });

  const labels = {
    drop: `Prices fall ${pct(d, 0)}`,
    gap: `Overnight gap-down of ${pct(d, 0)}`,
    oracle_delay: `Oracle delay: real price moves ${pct(d, 0)}`,
  } as const;
  const notes = {
    drop: 'Tokenized collateral reprices immediately; debt is held constant.',
    gap: 'The underlying opens lower after a close. Tokenized prices jump straight to the new level, so there may be no time to react.',
    oracle_delay:
      scenario.kind === 'oracle_delay'
        ? `The oracle lags for ${scenario.delayMin} minutes. On-chain HF still shows ${fmtHf(hf0)} until the feed updates, then drops to ${fmtHf(hf1)} at once.`
        : '',
  } as const;

  return {
    scenario,
    label: labels[scenario.kind],
    note: notes[scenario.kind],
    before: { healthFactor: hf0, buffer: bufferFromHf(hf0) },
    after: { healthFactor: hf1, buffer: b1, badge: !Number.isFinite(hf1) ? 'safe' : hf1 < DEFAULTS.riskHf || b1 < DEFAULTS.riskBuffer ? 'risk' : b1 < DEFAULTS.watchBuffer ? 'watch' : 'safe' },
    liquidationPrices,
    stressedPrices,
    plan: planToTarget(shocked, raw.debt, targetHf),
  };
}

// ---------------------------------------------------------------- language

export function pct(x: number, dp = 1): string {
  return `${(x * 100).toFixed(dp)}%`;
}
export function fmtHf(hf: number): string {
  return Number.isFinite(hf) && hf < 1e6 ? hf.toFixed(2) : "∞";
}
export function fmtUsd(x: number): string {
  return x.toLocaleString('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: x >= 1000 ? 0 : 2 });
}
export function fmtAmount(x: number, symbol: string): string {
  const dp = x >= 1000 ? 2 : x >= 1 ? 4 : 6;
  return `${x.toLocaleString('en-US', { maximumFractionDigits: dp })} ${symbol}`;
}

export function explain(p: ScoredPosition): Explanation {
  if (!Number.isFinite(p.healthFactor)) {
    return {
      headline: 'No debt — this position cannot be liquidated.',
      whatChanged: 'There is collateral but no borrowed amount.',
      whyItMatters: 'Liquidation only happens when debt exceeds the weighted value of collateral.',
      whatToDo: 'Nothing to do. If you borrow later, COLLATERA will start tracking the buffer.',
    };
  }
  const main = [...p.collateral].sort((a, b) => b.amount * b.price - a.amount * a.price)[0];
  const asset = main?.symbol ?? 'collateral';
  const closed = p.markets.filter((m) => !m.open);
  const stale = p.feeds.filter((f) => f.state !== 'fresh');
  const pause = p.issuerEvents.find((e) => e.kind === 'pause' && e.active);
  const cutoff = new Date(p.scoredAt).getTime() - DEFAULTS.issuerEventFreshHours * 3600_000;
  const recent = p.issuerEvents.find((e) => new Date(e.occurredAt).getTime() >= cutoff);

  let headline: string;
  if (p.healthFactor < 1) headline = `This position is below a 1.0 health factor and can be liquidated now.`;
  else headline = `Your ${asset} collateral can fall about ${pct(Math.max(p.buffer, 0), 0)} before liquidation.`;

  const changed: string[] = [];
  if (closed.length) {
    const m = closed[0];
    changed.push(`${m.name} is closed until ${new Date(m.nextOpen).toLocaleString('en-US', { timeZone: 'America/New_York', weekday: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' })} ET, so we treat your buffer as about ${pct(Math.max(p.effectiveBuffer, 0), 0)}.`);
  }
  for (const f of stale) {
    changed.push(f.ageSec == null
      ? `The ${f.symbol} price feed did not respond.`
      : `The ${f.symbol} price was last updated ${fmtDuration(Math.round(f.ageSec / 60))} ago (expected every ${fmtDuration(Math.round(f.heartbeatSec / 60))}).`);
  }
  if (pause) changed.push(`${pause.asset}: ${pause.description}`);
  else if (recent) changed.push(`Issuer event on ${recent.asset}: ${recent.description}`);
  if (!changed.length) changed.push(`Health factor is ${fmtHf(p.healthFactor)} and all price feeds are fresh.`);

  const why: string[] = [];
  if (p.badge === 'risk') why.push('A small move can trigger liquidation, which sells your collateral at a penalty.');
  if (closed.length) why.push('While the stock market is shut, tokenized shares trade thinly and the price can gap when it reopens.');
  if (stale.length) why.push('A stale feed means the on-chain price may not reflect the real market; your true buffer could be smaller.');
  if (pause) why.push('A paused token may not be transferable or redeemable, which can block repayment paths that rely on it.');
  if (!why.length) why.push('Your buffer is comfortable for normal daily moves.');

  let todo: string;
  if (p.plan.repay) {
    todo = `Repaying ${fmtAmount(p.plan.repay.amount, p.plan.repay.symbol)} brings you back to a ${p.plan.targetHf} health factor`;
    if (p.plan.add[0]) todo += `, or add ${fmtAmount(p.plan.add[0].amount, p.plan.add[0].symbol)} as collateral`;
    todo += '. Preview it in the repayment planner — nothing runs until you sign.';
  } else if (p.badge !== 'safe') {
    todo = 'Keep an eye on alerts; your health factor is above the planner target but other risks are present.';
  } else {
    todo = 'No action needed. Set an alert so you hear about it if this changes.';
  }

  return { headline, whatChanged: changed.join(' '), whyItMatters: why.join(' '), whatToDo: todo };
}
