// Registry of tokenized stocks / ETFs COLLATERA understands.
//
// A reserve on the configured lending market is treated as "tokenized collateral"
// when its token address (preferred) or symbol matches an entry here. Add the real
// token addresses for the market you point COLLATERA at, or override the whole list
// with the ASSET_REGISTRY_JSON env var (same shape, JSON array).

import type { ExchangeId } from '@/lib/risk/calendar';

export interface RegistryAsset {
  symbol: string;
  /** ERC-20 address on the configured chain (lowercase); empty = match by symbol */
  token: string;
  name: string;
  underlying: string;
  exchange: ExchangeId;
  issuer: string;
  /** Expected oracle update interval in seconds */
  heartbeatSec: number;
  /** Extra buffer haircut while the exchange is closed (default 0.08) */
  gapHaircut?: number;
  /** Issuer token contract to watch for Paused/Unpaused/allowlist events */
  issuerContract?: string;
}

const BUILT_IN: RegistryAsset[] = [
  { symbol: 'TSLAx', token: '', name: 'Tesla tokenized share', underlying: 'TSLA', exchange: 'XNAS', issuer: 'Example Issuer', heartbeatSec: 3600, gapHaircut: 0.1 },
  { symbol: 'NVDAx', token: '', name: 'NVIDIA tokenized share', underlying: 'NVDA', exchange: 'XNAS', issuer: 'Example Issuer', heartbeatSec: 3600, gapHaircut: 0.1 },
  { symbol: 'AAPLx', token: '', name: 'Apple tokenized share', underlying: 'AAPL', exchange: 'XNAS', issuer: 'Example Issuer', heartbeatSec: 3600 },
  { symbol: 'SPYx', token: '', name: 'S&P 500 ETF tokenized share', underlying: 'SPY', exchange: 'XNYS', issuer: 'Example Issuer', heartbeatSec: 3600, gapHaircut: 0.06 },
  { symbol: 'QQQx', token: '', name: 'Nasdaq-100 ETF tokenized share', underlying: 'QQQ', exchange: 'XNAS', issuer: 'Example Issuer', heartbeatSec: 3600, gapHaircut: 0.07 },
];

let cached: RegistryAsset[] | null = null;

export function registry(): RegistryAsset[] {
  if (cached) return cached;
  const raw = typeof process !== 'undefined' ? process.env.ASSET_REGISTRY_JSON : '';
  if (raw && raw.trim()) {
    try {
      const parsed = JSON.parse(raw) as RegistryAsset[];
      cached = parsed.map((a) => ({ ...a, token: (a.token || '').toLowerCase() }));
      return cached;
    } catch (e) {
      console.error('[registry] ASSET_REGISTRY_JSON is not valid JSON, using built-in list', e);
    }
  }
  cached = BUILT_IN;
  return cached;
}

export function findAsset(token: string, symbol: string): RegistryAsset | undefined {
  const t = token.toLowerCase();
  return registry().find((a) => (a.token && a.token === t) || (!a.token && a.symbol === symbol));
}
