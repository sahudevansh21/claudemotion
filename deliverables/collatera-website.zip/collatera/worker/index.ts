// COLLATERA background worker: re-scores watched positions, records snapshots,
// fires alerts, ingests issuer contract events and (in dev) polls Telegram.
// Run with `npm run worker` (or `npm run dev`, which starts it next to the web app).

import { parseAbiItem } from 'viem';
import { registry } from '@/config/assets';
import { DEMO_ADDRESS } from '@/lib/chain';
import { publicClient } from '@/lib/chain/aave';
import { evaluate, fire } from '@/lib/server/alerts';
import { db } from '@/lib/server/db';
import { env } from '@/lib/server/env';
import { persistSnapshot, previousSnapshot, scanAddress } from '@/lib/server/positions';
import { handleTelegramUpdate } from '@/lib/server/telegram';

const log = (...a: unknown[]) => console.log(new Date().toISOString(), '[worker]', ...a);
const CADENCE_MS: Record<string, number> = { free: 60 * 60_000, pro: 60_000, team: 60_000, demo: 60_000 };
const lastScan = new Map<string, number>();
let stopping = false;

async function scanTick() {
  const watched = await db.watchedAddress.findMany({ include: { user: { include: { rules: true } } } });
  const byAddress = new Map<string, typeof watched>();
  for (const w of watched) byAddress.set(w.address, [...(byAddress.get(w.address) ?? []), w]);
  if (!byAddress.has(DEMO_ADDRESS)) byAddress.set(DEMO_ADDRESS, []); // keeps demo history alive

  for (const [address, watchers] of byAddress) {
    if (stopping) return;
    const plans = watchers.map((w) => w.user.plan);
    const cadence = Math.min(...(address === DEMO_ADDRESS ? [CADENCE_MS.demo] : []), ...plans.map((p) => CADENCE_MS[p] ?? CADENCE_MS.free));
    if (Date.now() - (lastScan.get(address) ?? 0) < cadence) continue;
    lastScan.set(address, Date.now());

    try {
      const positions = await scanAddress(address, { fresh: true });
      for (const p of positions) {
        const prev = await previousSnapshot(p.id);
        await persistSnapshot(p);
        for (const f of p.feeds) {
          if (!f.feed) continue;
          const leg = p.collateral.find((c) => c.symbol === f.symbol)!;
          await db.feedStatus.upsert({
            where: { id: f.feed.toLowerCase() },
            update: { asset: f.symbol, price: leg.price, updatedAt: new Date((leg.oracle.updatedAt ?? 0) * 1000), ageSec: f.ageSec ?? -1, state: f.state, checkedAt: new Date() },
            create: { id: f.feed.toLowerCase(), asset: f.symbol, price: leg.price, updatedAt: new Date((leg.oracle.updatedAt ?? 0) * 1000), ageSec: f.ageSec ?? -1, state: f.state },
          });
        }
        for (const w of watchers) {
          const n = await fire(w.user, evaluate(w.user.rules, p, prev?.json ?? null));
          if (n) log(`fired ${n} alert(s) for ${w.user.email} on ${p.id}`);
        }
      }
      log(`scanned ${address} → ${positions.length} position(s)`);
    } catch (e) {
      log(`scan failed for ${address}:`, (e as Error).message);
    }
  }
}

const pausedEvent = parseAbiItem('event Paused(address account)');
const unpausedEvent = parseAbiItem('event Unpaused(address account)');

async function issuerTick() {
  if (env().MARKET_MODE !== 'aave' || !env().RPC_URL) return;
  const assets = registry().filter((a) => a.issuerContract);
  if (!assets.length) return;
  const c = publicClient();
  const head = await c.getBlockNumber();
  for (const a of assets) {
    const key = `issuer:${a.issuerContract!.toLowerCase()}`;
    const cursor = await db.workerCursor.findUnique({ where: { id: key } });
    const from = cursor ? BigInt(cursor.value) + 1n : head - 5_000n;
    if (from > head) continue;
    const to = from + 10_000n < head ? from + 10_000n : head;
    const logs = await c.getLogs({ address: a.issuerContract as `0x${string}`, events: [pausedEvent, unpausedEvent], fromBlock: from, toBlock: to });
    for (const l of logs) {
      const block = await c.getBlock({ blockNumber: l.blockNumber! });
      const paused = l.eventName === 'Paused';
      if (!paused) await db.issuerEvent.updateMany({ where: { asset: a.symbol, kind: 'pause', active: true }, data: { active: false } });
      await db.issuerEvent.upsert({
        where: { txHash: `${l.transactionHash}:${l.logIndex}` },
        update: {},
        create: {
          asset: a.symbol, kind: paused ? 'pause' : 'unpause', active: paused,
          description: paused ? `${a.issuer} paused the ${a.symbol} token contract.` : `${a.issuer} unpaused the ${a.symbol} token contract.`,
          txHash: `${l.transactionHash}:${l.logIndex}`, occurredAt: new Date(Number(block.timestamp) * 1000),
        },
      });
      log(`issuer event ${l.eventName} on ${a.symbol}`);
    }
    await db.workerCursor.upsert({ where: { id: key }, update: { value: to.toString() }, create: { id: key, value: to.toString() } });
  }
}

async function telegramPollLoop() {
  const e = env();
  if (!e.TELEGRAM_BOT_TOKEN || e.TELEGRAM_MODE !== 'poll') return;
  log('telegram: long-polling getUpdates');
  while (!stopping) {
    try {
      const cur = await db.workerCursor.findUnique({ where: { id: 'telegram:offset' } });
      const offset = cur ? Number(cur.value) : 0;
      const res = await fetch(`https://api.telegram.org/bot${e.TELEGRAM_BOT_TOKEN}/getUpdates?timeout=25&offset=${offset}`);
      const data = (await res.json()) as { ok: boolean; result: { update_id: number }[] };
      for (const u of data.result ?? []) {
        await handleTelegramUpdate(u as Parameters<typeof handleTelegramUpdate>[0]);
        await db.workerCursor.upsert({ where: { id: 'telegram:offset' }, update: { value: String(u.update_id + 1) }, create: { id: 'telegram:offset', value: String(u.update_id + 1) } });
      }
    } catch (err) {
      log('telegram poll error', (err as Error).message);
      await new Promise((r) => setTimeout(r, 5000));
    }
  }
}

function every(ms: number, name: string, fn: () => Promise<void>) {
  let running = false;
  const run = async () => {
    if (running || stopping) return;
    running = true;
    try { await fn(); } catch (e) { log(`${name} failed:`, (e as Error).message); } finally { running = false; }
  };
  void run();
  return setInterval(run, ms);
}

log(`starting (market mode: ${env().MARKET_MODE})`);
const timers = [every(30_000, 'scan', scanTick), every(120_000, 'issuer-events', issuerTick)];
void telegramPollLoop();

async function shutdown() {
  stopping = true;
  timers.forEach(clearInterval);
  await db.$disconnect();
  log('stopped');
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
